(function(){"use strict";function cr(e){return e}const K=globalThis.browser?.runtime?.id?globalThis.browser:globalThis.chrome,Fe={x:1,y:0},se=e=>Math.min(1,Math.max(0,e)),Ge=(e,t)=>({x:se(e),y:se(t)}),Ue=e=>{if(typeof e!="object"||e===null)return!1;const t=e;return typeof t.x=="number"&&Number.isFinite(t.x)&&typeof t.y=="number"&&Number.isFinite(t.y)},qe=(e,t,r,a=16)=>{const n=Math.max(a,r.width-t.width-a),l=Math.max(a,r.height-t.height-a);return{left:Math.round(a+e.x*(n-a)),top:Math.round(a+e.y*(l-a))}},Ve=(e,t,r,a,n=16)=>{const l=Math.max(n,a.width-r.width-n),p=Math.max(n,a.height-r.height-n),m=Math.max(1,l-n),d=Math.max(1,p-n);return Ge((e-n)/m,(t-n)/d)},Ye="parle-pill",He=e=>({_tag:"Watch",tabId:e}),je=(e,t,r)=>({_tag:"Sighted",address:e,title:t,referrer:r}),Be=e=>({_tag:"OpenOut",address:e}),Xe=()=>({_tag:"LookAnyway"}),Ke=()=>({_tag:"Summarise"}),pe=(e=Date.now())=>({_tag:"PanelOpened",openedAt:e}),de=()=>({_tag:"PanelClosed"}),Qe=e=>({_tag:"ReadDiscussion",key:e}),Ze=e=>({_tag:"Decide",automatic:e}),Je=()=>({_tag:"OpenDisclosure"}),et=e=>({_tag:"PauseSite",host:e}),tt=e=>({_tag:"ResumeSite",host:e}),rt=()=>({_tag:"OpenSettings"}),at=e=>({_tag:"ParkMark",park:e}),nt=(e,t,r)=>({_tag:"Standing",tabId:e,panel:t,markPark:r}),ot=e=>({_tag:"Told",decision:e}),it=(e,t,r)=>({_tag:"Forgot",scope:e,requestId:t,ok:r}),lt=e=>typeof e=="object"&&e!==null&&"_tag"in e&&typeof e._tag=="string"?e._tag:null,ce=(e,t)=>{const r=e[t];return typeof r=="string"?r:null},st=e=>e==="undecided"||e==="automatic"||e==="manual",pt=e=>{switch(lt(e)){case"Standing":{const t=e;if(typeof t.tabId!="number")return null;const r=t.panel;if(typeof r!="object"||r===null||!Array.isArray(r.linked)||!Array.isArray(r.accounts))return null;const a=Ue(t.markPark)?t.markPark:{x:1,y:0};return nt(t.tabId,r,a)}case"Told":{const t=e.decision;return st(t)?ot(t):null}case"Forgot":{const t=ce(e,"scope"),r=ce(e,"requestId"),a=e.ok;return(t==="everything"||t==="lookup-record")&&r!==null&&r!==""&&r.length<=128&&typeof a=="boolean"?it(t,r,a):null}default:return null}},dt=400,ct=(e,t,r)=>{let a=null,n=!1;const l=[],p=d=>{if(a===null)return!1;try{return a.postMessage(d),!0}catch{return!1}},m=(d=!1)=>{if(!n){a=K.runtime.connect({name:e}),a.onMessage.addListener(v=>{const x=pt(v);x!==null&&t(x)}),a.onDisconnect.addListener(()=>{a=null,n||setTimeout(()=>m(!0),dt)});for(const v of l)p(v);d&&r?.()}};return m(),{say:(d,v=!1)=>(v&&l.push(d),p(d)),close:()=>{n=!0;try{a?.disconnect()}catch{}a=null}}},ue=32,ut=(e,t,r)=>{if(r<=t)return null;const a=e.slice(t,r);return a.trim()===""?null:{exact:a,prefix:e.slice(Math.max(0,t-ue),t),suffix:e.slice(r,r+ue),wasAt:t}},ht=e=>{const t=()=>{const r=document.getSelection();if(r===null||r.isCollapsed||r.rangeCount===0)return;const a=r.toString(),n=document.body.textContent??"",l=n.indexOf(a);e(l===-1?{exact:a,prefix:"",suffix:"",wasAt:0}:ut(n,l,l+a.length))};return document.addEventListener("selectionchange",t,{passive:!0}),()=>document.removeEventListener("selectionchange",t)},F="http://www.w3.org/2000/svg",M=e=>{const t=document.createElementNS(F,"svg");return t.setAttribute("viewBox",e),t.setAttribute("aria-hidden","true"),t},$=(e,t)=>{const r=document.createElementNS(F,"path");return r.setAttribute("d",e),t!==void 0&&r.setAttribute("fill",t),r},he=(e,t,r,a,n,l)=>{const p=document.createElementNS(F,"rect");return p.setAttribute("x",String(e)),p.setAttribute("y",String(t)),p.setAttribute("width",String(r)),p.setAttribute("height",String(a)),p.setAttribute("rx",String(n)),p.setAttribute("fill",l),p},D=(e,t,r,a)=>{const n=document.createElementNS(F,"circle");return n.setAttribute("cx",String(e)),n.setAttribute("cy",String(t)),n.setAttribute("r",String(r)),n.setAttribute("fill",a),n},mt=()=>{const e=M("0 0 16 16");return e.appendChild($("M8 1.6c-3.6 0-6.5 2.3-6.5 5.2 0 1.7 1 3.2 2.5 4.1L3.3 14l3.2-1.7c.5.1 1 .1 1.5.1 3.6 0 6.5-2.3 6.5-5.2S11.6 1.6 8 1.6z")),e},ft=()=>{const e=M("0 0 16 16");return e.appendChild(he(0,0,16,16,2.5,"#ff6600")),e.appendChild($("M4.2 3.2h1.7l2.1 4.1 2.1-4.1h1.7L8.9 8.6V12.8H7.1V8.6L4.2 3.2z","#ffffff")),e},gt=()=>{const e=M("0 0 16 16");e.appendChild(D(8,8,8,"#ff4500"));const t=document.createElementNS(F,"text");return t.setAttribute("x","8"),t.setAttribute("y","11.2"),t.setAttribute("text-anchor","middle"),t.setAttribute("fill","#ffffff"),t.setAttribute("font-size","7.5"),t.setAttribute("font-weight","700"),t.setAttribute("font-family","Verdana, Geneva, sans-serif"),t.textContent="r/",e.appendChild(t),e},vt=()=>{const e=M("0 0 16 16");return e.appendChild(D(8,8,8,"#0f1419")),e.appendChild($("M4.1 4.1h2.05l1.7 2.35L10.05 4.1H12l-2.85 3.55L12.2 11.9h-2.05l-1.95-2.6-2.2 2.6H4l3.1-3.7L4.1 4.1z","#ffffff")),e},me=(e,t,r)=>{const a=document.createElementNS(F,"text");return a.setAttribute("x","8"),a.setAttribute("y",String(t)),a.setAttribute("text-anchor","middle"),a.setAttribute("fill","#ffffff"),a.setAttribute("font-size",String(r)),a.setAttribute("font-weight","700"),a.setAttribute("font-family","Verdana, Geneva, sans-serif"),a.textContent=e,a},bt=()=>{const e=M("0 0 16 16");return e.appendChild(D(8,8,8,"#0085ff")),e.appendChild($("M8 6.5C6.9 4.7 5.3 3.3 4.1 3.3c-1 0-1.6.6-1.6 1.8 0 1.4 1 3 2.2 3.9-.9.2-1.4.7-1.4 1.4 0 1.3 1.4 2.4 2.8 2.4 1 0 1.6-.8 1.9-1.9.3 1.1.9 1.9 1.9 1.9 1.4 0 2.8-1.1 2.8-2.4 0-.7-.5-1.2-1.4-1.4 1.2-.9 2.2-2.5 2.2-3.9 0-1.2-.6-1.8-1.6-1.8-1.2 0-2.8 1.4-3.9 3.2z","#ffffff")),e},xt=()=>{const e=M("0 0 16 16");return e.appendChild(D(8,8,8,"#00bc8c")),e.appendChild(me("!",11.6,9.5)),e},wt=()=>{const e=M("0 0 16 16");return e.appendChild(he(0,0,16,16,2.5,"#ac130d")),e.appendChild(me("L",11.6,9.5)),e},fe=e=>{switch(e){case"hackernews":return ft();case"reddit":return gt();case"x":return vt();case"bluesky":return bt();case"lemmy":return xt();case"lobsters":return wt()}},ge={hackernews:"HN",reddit:"Reddit",x:"X",bluesky:"Bluesky",lemmy:"Lemmy",lobsters:"Lobsters"},kt=["hackernews","reddit","x","bluesky","lemmy","lobsters"],Q=e=>{const t=new Set;for(const r of e)t.add(r.network);return kt.filter(r=>t.has(r))},ve=e=>{const t=document.createElement("span");if(t.className="parle-stack",t.dataset.count=String(Math.max(e.length,1)),e.length===0){const r=document.createElement("span");return r.className="parle-stack-disc parle-stack-parle",r.appendChild(mt()),t.appendChild(r),t}for(const r of[...e].reverse()){const a=document.createElement("span");a.className=`parle-stack-disc parle-stack-${r}`,a.appendChild(fe(r)),t.appendChild(a)}return t},yt=e=>{const t=document.createElement("span");return t.className=`parle-tab-mark parle-tab-mark-${e}`,t.appendChild(fe(e)),t},Ct=()=>{const e=M("0 0 16 16");return e.appendChild($("M8 1.2c.35 3.75 2.05 5.45 5.8 5.8-3.75.35-5.45 2.05-5.8 5.8C7.65 9.05 5.95 7.35 2.2 7 5.95 6.65 7.65 4.95 8 1.2z","currentColor")),e.appendChild($("M13 10.4c.12 1.35.75 1.98 2.1 2.1-1.35.12-1.98.75-2.1 2.1-.12-1.35-.75-1.98-2.1-2.1 1.35-.12 1.98-.75 2.1-2.1z","currentColor")),e},At=()=>{const e=M("0 0 16 16"),t=$("M6.4 1.8h3.2l.4 1.5 1.4-.5 1.6 1.6-.5 1.4 1.5.4v3.2l-1.5.4.5 1.4-1.6 1.6-1.4-.5-.4 1.5H6.4l-.4-1.5-1.4.5-1.6-1.6.5-1.4L1.8 9.6V6.4l1.5-.4-.5-1.4 1.6-1.6 1.4.5.4-1.5z");t.setAttribute("fill","none"),t.setAttribute("stroke","currentColor"),t.setAttribute("stroke-width","1.2"),t.setAttribute("stroke-linejoin","round"),e.appendChild(t);const r=D(8,8,2,"none");return r.setAttribute("stroke","currentColor"),r.setAttribute("stroke-width","1.2"),e.appendChild(r),e},St=()=>{const e=M("0 0 16 16"),t=$("M6.2 3.2H3.8a1 1 0 0 0-1 1v8a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V9.8");t.setAttribute("fill","none"),t.setAttribute("stroke","currentColor"),t.setAttribute("stroke-width","1.3"),t.setAttribute("stroke-linecap","round"),t.setAttribute("stroke-linejoin","round"),e.appendChild(t);const r=$("M8.2 2.8h5v5M13.1 2.9 7.4 8.6");return r.setAttribute("fill","none"),r.setAttribute("stroke","currentColor"),r.setAttribute("stroke-width","1.3"),r.setAttribute("stroke-linecap","round"),r.setAttribute("stroke-linejoin","round"),e.appendChild(r),e},Et=()=>{const e=M("0 0 16 16"),t=$("M2.5 4h8M2.5 7h10.5M5.5 10h7.5M5.5 13h5");return t.setAttribute("fill","none"),t.setAttribute("stroke","currentColor"),t.setAttribute("stroke-width","1.3"),t.setAttribute("stroke-linecap","round"),e.appendChild(t),e},Lt=()=>{const e=M("0 0 16 16");return e.appendChild(D(3.5,8,1,"currentColor")),e.appendChild(D(8,8,1,"currentColor")),e.appendChild(D(12.5,8,1,"currentColor")),e},Mt=e=>e.archive.length+e.standing.length>0,Z=e=>e.linked.length+e.passing.length,Nt=e=>{try{const t=new URL(e);return t.protocol!=="http:"&&t.protocol!=="https:"?null:t.hostname.replace(/^www\./,"")}catch{return null}},$t=e=>e.length<=1?e[0]??"Nowhere":`${e.slice(0,-1).join(", ")} and ${e[e.length-1]}`,i=(e,t,r)=>{const a=document.createElement(e);return t!==""&&(a.className=t),r!==void 0&&(a.textContent=r),a},P=(e,t,r)=>{const a=i("button",e,t);return a.addEventListener("click",n=>{n.preventDefault(),r()}),a},J=(e,t,r,a)=>{const n=i("button",e);return n.type="button",n.setAttribute("aria-label",t),n.title=t,n.appendChild(r),n.addEventListener("click",l=>{l.preventDefault(),a()}),n},be=e=>e===1?"also submitted once":`also submitted ${e} times`,Tt=8,Pt=40,_t=3,Y=new Set,G=new Set,zt=(e,t)=>`${e.key}\0${t.id}`,xe=(e,t,r)=>{const a=i("div","parle-comments"),n=s=>{s.appendChild(i("span","parle-comments-spacer")),s.appendChild(J("parle-comments-open","Open discussion",St(),()=>t.openOut(e.permalink)));const h=i("span","parle-comments-menu-wrap"),c=i("span","parle-comments-menu");c.hidden=!0;const g=r===void 0?null:Nt(r.address);if(g!==null&&r!==void 0){const O=r.restraint!==null&&r.restraint.kind==="site-paused";c.appendChild(P("parle-comments-menu-item",O?`Resume on ${g}`:`Pause on ${g}`,()=>O?t.resumeSite(g):t.pauseSite(g)))}c.appendChild(P("parle-comments-menu-item","What Parle sends",t.openDisclosure));const S=J("parle-comments-more-actions","More actions",Lt(),()=>{c.hidden=!c.hidden,S.setAttribute("aria-expanded",c.hidden?"false":"true")});S.setAttribute("aria-haspopup","menu"),S.setAttribute("aria-expanded","false"),h.appendChild(S),h.appendChild(c),s.appendChild(h)},l=()=>{const s=i("div","parle-comments-tools");return n(s),s};if(e.comments===null&&e.commentCount===0)return a.appendChild(l()),a.appendChild(i("p","parle-comments-note","No comments yet.")),a;if(e.comments===null||e.comments._tag==="Reading")return a.appendChild(l()),a.appendChild(i("p","parle-comments-note","Loading comments\u2026")),a;if(e.comments._tag==="Unreadable")return a.appendChild(l()),a.appendChild(i("p","parle-comments-note","Could not read this one.")),a;const p=e.comments,m=new Map(p.comments.map(s=>[s.id,s])),d=new Map;for(const s of p.comments){const h=s.parentId!==null&&s.parentId!==s.id&&m.has(s.parentId)?s.parentId:null,c=d.get(h);c===void 0?d.set(h,[s]):c.push(s)}const v=s=>{let h=0;const c=[...d.get(s.id)??[]];for(;c.length>0;){const g=c.shift();g!==void 0&&(h+=1,c.push(...d.get(g.id)??[]))}return h},x=s=>e.network!=="x"||s.startsWith("@")?s:`@${s}`,u=(s,h,c=!0)=>{const g=i("article","parle-comment"),S=i("div","parle-comment-who",x(s.author));s.age!==""&&S.appendChild(i("span","parle-comment-age",s.age)),g.appendChild(S),g.appendChild(i("p","parle-comment-text",s.text));const O=d.get(s.id)??[];if(O.length===0||!c)return g;const _=v(s);if(h>=_t)return g.appendChild(P("parle-comment-more",`Continue ${_===1?"this reply":`these ${_} replies`} on the discussion`,()=>t.openOut(e.permalink))),g;const k=zt(e,s),z=G.has(k);if(g.appendChild(P("parle-comment-more",z?"Hide replies":`${_} ${_===1?"reply":"replies"}`,()=>{G.has(k)?G.delete(k):G.add(k),w()})),z){const U=i("div","parle-replies");for(const q of O)U.appendChild(u(q,h+1));g.appendChild(U)}return g},w=()=>{a.replaceChildren();const s=i("div","parle-comments-tools"),h=Y.has(e.key),c=i("button","parle-comments-mode");if(c.type="button",c.setAttribute("aria-label",h?"Flat":"Nested"),c.appendChild(Et()),c.appendChild(i("span","",h?"Flat":"Nested")),c.appendChild(i("span","parle-comments-chevron","\u2304")),c.addEventListener("click",k=>{k.preventDefault(),Y.has(e.key)?Y.delete(e.key):Y.add(e.key),w()}),c.setAttribute("aria-pressed",h?"false":"true"),s.appendChild(c),s.appendChild(P("parle-comments-collapse","Collapse all",()=>{for(const k of[...G])k.startsWith(`${e.key}\0`)&&G.delete(k);w()})),n(s),a.appendChild(s),h){const k=p.comments.slice(0,Pt);for(const U of k)a.appendChild(u(U,0,!1));const z=Math.max(0,p.comments.length-k.length)+p.beyond;z>0&&a.appendChild(P("parle-comments-more",`Open ${z} more on the discussion`,()=>t.openOut(e.permalink)));return}const g=d.get(null)??[],S=g.slice(0,Tt);for(const k of S)a.appendChild(u(k,0));const _=g.slice(S.length).reduce((k,z)=>k+1+v(z),0)+p.beyond;_>0&&a.appendChild(P("parle-comments-more",`Open ${_} more on the discussion`,()=>t.openOut(e.permalink)))};return w(),a},Dt=e=>e.network==="reddit"?`r/${e.place}`:`${e.place}`,Ot=e=>{switch(e.network){case"hackernews":return{score:`${e.score} points`,comments:`${e.commentCount} ${e.commentCount===1?"comment":"comments"}`};case"reddit":return{score:`${e.score} upvotes`,comments:`${e.commentCount} ${e.commentCount===1?"comment":"comments"}`};case"x":return{score:`${e.score} likes`,comments:`${e.commentCount} ${e.commentCount===1?"reply":"replies"}`};case"bluesky":return{score:`${e.score} likes`,comments:`${e.commentCount} ${e.commentCount===1?"reply":"replies"}`};case"lemmy":return{score:`${e.score} upvotes`,comments:`${e.commentCount} ${e.commentCount===1?"comment":"comments"}`};case"lobsters":return{score:`${e.score} points`,comments:`${e.commentCount} ${e.commentCount===1?"comment":"comments"}`}}},we=(e,t)=>{const r=i("div","parle-row-holder"),a=i("div","parle-row"),n=i("a","parle-title");n.textContent=e.title,n.href=e.permalink,n.target="_blank",n.rel="noreferrer noopener",n.addEventListener("click",d=>{d.preventDefault(),t.openOut(e.permalink)}),a.appendChild(n);const l=i("div","parle-facts"),p=Ot(e);l.appendChild(i("span","parle-network",e.networkName)),l.appendChild(i("span","",p.score)),l.appendChild(i("span","",p.comments)),e.age!==""&&l.appendChild(i("span","",e.age)),e.alsoSubmitted>0&&l.appendChild(i("span","parle-repeat",be(e.alsoSubmitted))),a.appendChild(l),r.appendChild(a);const m=xe(e,t);return m!==null&&r.appendChild(m),r},Rt=(e,t,r)=>{const a=i("div","parle-row-holder parle-home");a.dataset.network=e.network;const n=i("a","parle-room-title");n.textContent=e.title,n.href=e.permalink,n.target="_blank",n.rel="noreferrer noopener",n.addEventListener("click",p=>{p.preventDefault(),t.openOut(e.permalink)}),a.appendChild(n),e.alsoSubmitted>0&&a.appendChild(i("div","parle-repeat parle-room-repeat",be(e.alsoSubmitted)));const l=xe(e,t,r);return l!==null?a.appendChild(l):e.commentCount===0&&a.appendChild(i("p","parle-comments-note","No comments yet.")),a},ee=new Map,ke=new Map,te=new Set,re=()=>{te.clear()},It=e=>e.reduce((t,r)=>t+r.commentCount,0),ae=e=>[...e].sort((t,r)=>r.commentCount-t.commentCount)[0],Wt=(e,t,r,a,n,l)=>{const p=i("section","parle-group parle-group-linked parle-room");p.dataset.network=t,p.setAttribute("role","tabpanel");const m=r.filter(x=>x.network===t),d=ee.get(e),v=m.find(x=>x.key===d)??ae(m);if(v===void 0)return p.appendChild(i("p","parle-comments-note","Nothing here yet.")),p;if(m.length>1){const x=i("div","parle-thread-picks");x.setAttribute("role","tablist"),x.setAttribute("aria-label","Threads");for(const u of[...m].sort((w,s)=>s.commentCount-w.commentCount)){const w=i("button",u.key===v.key?"parle-thread-pick parle-thread-pick-on":"parle-thread-pick");w.type="button",w.setAttribute("role","tab"),w.setAttribute("aria-selected",u.key===v.key?"true":"false");const s=u.place!==null&&u.place!==""?Dt(u):u.title.length>28?`${u.title.slice(0,27)}\u2026`:u.title;w.textContent=s,w.title=u.title,w.addEventListener("click",()=>{ee.set(e,u.key),l()}),x.appendChild(w)}p.appendChild(x)}return p.appendChild(Rt(v,n,a)),v.comments===null&&v.commentCount>0&&!te.has(v.key)&&(te.add(v.key),n.readDiscussion(v.key)),p},Ft=(e,t,r,a,n)=>{const l=i("nav","parle-nav");l.setAttribute("aria-label","Discussions");const p=i("div","parle-nav-strip");p.setAttribute("role","tablist");const m=i("button",r==="summary"?"parle-nav-item parle-nav-on":"parle-nav-item");m.type="button",m.dataset.dock="summary",m.setAttribute("role","tab"),m.setAttribute("aria-selected",r==="summary"?"true":"false"),m.setAttribute("aria-label","Digest"),m.title="Digest";const d=i("span","parle-nav-mark");d.appendChild(Ct());const v=i("span","parle-nav-icon");v.appendChild(d),t.digest.findings.length===0&&v.appendChild(i("span","parle-nav-soon")),m.appendChild(v),m.addEventListener("click",()=>n("summary")),p.appendChild(m);for(const u of Q(t.linked)){const w=t.linked.filter(g=>g.network===u),s=It(w),h=i("button",r===u?"parle-nav-item parle-nav-on":"parle-nav-item");h.type="button",h.dataset.network=u,h.setAttribute("role","tab"),h.setAttribute("aria-selected",r===u?"true":"false"),h.setAttribute("aria-label",`${ge[u]}, ${s} ${s===1?"comment":"comments"}`),h.title=`${ge[u]} \xB7 ${s}`;const c=i("span","parle-nav-icon");if(c.appendChild(yt(u)),s>0){const g=i("span","parle-nav-badge",s>999?"999+":String(s));g.setAttribute("aria-hidden","true"),c.appendChild(g)}h.appendChild(c),h.addEventListener("click",()=>{const g=ae(w);g!==void 0&&ee.set(e,g.key),n(u)}),p.appendChild(h)}l.appendChild(p);const x=i("div","parle-nav-utilities");return x.appendChild(J("parle-nav-item parle-nav-settings","Settings",At(),a.openSettings)),l.appendChild(x),l},Gt=(e,t,r,a,n)=>{if(a.length===0)return null;const l=i("section",`parle-group parle-group-${e}`),p=i("h2","parle-group-name",`${t} `);p.appendChild(i("span","parle-group-note",r)),l.appendChild(p);for(const m of a)l.appendChild(we(m,n));return l},Ut=(e,t)=>{const r=i("section","parle-folded");r.appendChild(i("p","parle-folded-says",e.says));const a=i("div","parle-folded-rows");a.hidden=!0;for(const l of e.rows)a.appendChild(we(l,t));const n=P("parle-act parle-act-folded",e.label,()=>{a.hidden=!1,n.remove()});return r.appendChild(n),r.appendChild(a),r},qt=(e,t)=>{const r=i("a","parle-source");return r.href=e.permalink,r.target="_blank",r.rel="noreferrer noopener",r.addEventListener("click",a=>{a.preventDefault(),t.openOut(e.permalink)}),r.appendChild(i("span","parle-source-label",e.comment?`${e.label} \u2014 the comment`:e.label)),r},Vt=(e,t)=>{const r=i("div",e.contested?"parle-finding parle-finding-disputed":"parle-finding");e.contested&&r.appendChild(i("span","parle-disputed","Someone there disagreed")),r.appendChild(i("p","parle-finding-says",e.statement));const a=i("div","parle-sources");for(const n of e.sources)a.appendChild(qt(n,t));return r.appendChild(a),r},Yt=(e,t)=>{if(e.says.text===""&&e.findings.length===0&&e.offer===null)return null;const r=i("section",`parle-digest parle-tone-${e.says.tone}`);e.says.text!==""&&r.appendChild(i("h2","parle-digest-title",e.says.text));for(const n of e.findings)r.appendChild(Vt(n,t));e.partial&&r.appendChild(i("p","parle-digest-partial","This is part of an answer \u2014 some of it could not be traced to a comment."));const a=e.offer;return a!==null&&(a.says!==""&&r.appendChild(i("p","parle-digest-says",a.says)),r.appendChild(P("parle-act parle-act-digest",a.label,a.kind==="connect"?t.openSettings:t.summarise))),e.wrote!==null&&r.appendChild(i("p","parle-digest-wrote",e.wrote)),r},Ht=e=>{const t=i("div",`parle-context-line parle-tone-${e.tone}`);if(e.href!==null){const r=i("a",`parle-context-line parle-context-link parle-tone-${e.tone}`);return r.textContent=e.text,r.href=e.href,r.target="_blank",r.rel="noreferrer noopener",r}t.appendChild(i("span","parle-context-says",e.text));for(const r of e.links){const a=i("a","parle-context-cite");a.textContent=r.label,a.href=r.href,a.target="_blank",a.rel="noreferrer noopener",t.appendChild(a)}return t},jt=e=>{if(!Mt(e))return null;const t=i("section","parle-context"),r=(a,n)=>{if(n.length===0)return;const l=i("div","parle-context-group");l.appendChild(i("h2","parle-context-name",a));for(const p of n)l.appendChild(Ht(p));t.appendChild(l)};return r("Archive",e.archive),r("Standing",e.standing),t},ye=e=>e.waitingOn.length===0?"Still looking.":`Still looking \u2014 ${e.waitingOn.join(", ")}`,Bt=e=>{const t=Z(e);return t>0?`${t} discussion${t===1?"":"s"} on this page.`:e.stillLooking?ye(e):e.folded!==null?e.folded.says:e.foundNothing?`Nobody has discussed this page. ${$t(e.answeredBy)} answered, with nothing.`:e.couldNotAsk?"Parle could not find out. Nowhere answered \u2014 which is not the same as nobody discussing it.":"Nothing has been asked about this page yet."},Xt=(e,t)=>i("div",`${t} parle-tone-${e.tone}`,e.text),Ce=(e,t,r)=>{e.textContent="",e.className="parle parle-compact";const a=i("div","parle-body"),n=t.address,l=ae(t.linked),p=ke.get(n)??(l!==void 0?l.network:"summary"),m=i("div","parle-main"),d=i("div","parle-extras"),v=jt(t.context);v!==null&&d.appendChild(v);const x=Gt("passing","Came up elsewhere","linked inside a conversation about something else",t.passing,r);if(x!==null&&d.appendChild(x),t.folded!==null&&d.appendChild(Ut(t.folded,r)),t.windowed!==null&&d.appendChild(Xt(t.windowed,"parle-note")),Z(t)===0&&t.folded===null)d.appendChild(i("p","parle-said",t.restraint===null?Bt(t):t.restraint.says));else if(t.stillLooking){const h=i("div","parle-notice parle-tone-waiting"),c=i("span","");c.appendChild(i("span","parle-spinner")),c.appendChild(document.createTextNode(ye(t))),h.appendChild(c),d.appendChild(h)}const u=h=>{if(ke.set(n,h),m.replaceChildren(),h==="summary"){const c=Yt(t.digest,r);c!==null?m.appendChild(c):m.appendChild(i("p","parle-comments-note","A Digest of these discussions will live here."));return}t.linked.some(c=>c.network===h)&&m.appendChild(Wt(n,h,t.linked,t,r,()=>u(h)))},w=i("div","parle-nav-slot"),s=h=>{w.replaceChildren(Ft(n,t,h,r,c=>{u(c),s(c)}))};u(p),a.appendChild(m),a.appendChild(d),e.appendChild(a),e.appendChild(w),s(p)},Kt=`
:host,
.parle, .parle-pill, .parle-dock {
  --parle-font: -apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif;
  --parle-mono: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  --parle-t-meta: 11px;
  --parle-t-body: 13px;
  --parle-t-lead: 15px;
  --parle-t-head: 18px;
  --parle-1: 4px;
  --parle-2: 8px;
  --parle-3: 12px;
  --parle-4: 16px;
  --parle-5: 24px;
  --parle-r: 10px;
  --parle-r-sm: 6px;
  --parle-r-full: 999px;
  --parle-bg: #ffffff;
  --parle-raise: #f6f4ef;
  --parle-ink: #15130f;
  --parle-mid: #5c574e;
  --parle-faint: #726c62;
  --parle-line: rgba(21, 19, 15, 0.1);
  --parle-rule: rgba(21, 19, 15, 0.2);
  --parle-accent: #15130f;
  --parle-on-accent: #faf8f4;
  --parle-warn: #7a5200;
  --parle-stop: #99291c;
  --parle-lift: 0 1px 2px rgba(21, 19, 15, 0.06), 0 10px 32px rgba(21, 19, 15, 0.14);
  --parle-motion: cubic-bezier(0.2, 0.75, 0.3, 1);
}
@media (prefers-color-scheme: dark) {
  :host,
  .parle, .parle-pill, .parle-dock {
    --parle-bg: #0d0e11;
    --parle-raise: #16181d;
    --parle-ink: #edeef2;
    --parle-mid: #9aa0ad;
    --parle-faint: #8b93a1;
    --parle-line: rgba(237, 238, 242, 0.1);
    --parle-rule: rgba(237, 238, 242, 0.24);
    --parle-accent: #edeef2;
    --parle-on-accent: #0d0e11;
    --parle-warn: #e0bd76;
    --parle-stop: #f0a396;
    --parle-lift: 0 1px 2px rgba(0, 0, 0, 0.4), 0 10px 32px rgba(0, 0, 0, 0.5);
  }
}

/* the phone scale */
@media (max-width: 639px) {
  :host,
  .parle, .parle-pill, .parle-dock {
    --parle-t-meta: 12px;
    --parle-t-body: 15px;
    --parle-t-lead: 17px;
  }
}

/* reset \u2014 nothing inherits from the page this is drawn on */
.parle, .parle-pill, .parle-dock {
  all: initial;
  color-scheme: light dark;
  font-family: var(--parle-font);
  font-size: var(--parle-t-body);
  line-height: 1.5;
  color: var(--parle-ink);
  -webkit-font-smoothing: antialiased;
  box-sizing: border-box;
}
.parle *, .parle *::before, .parle *::after,
.parle-pill *, .parle-pill::before, .parle-pill::after,
.parle-dock * { box-sizing: border-box; }
.parle a { color: inherit; text-decoration: none; }
.parle :focus-visible,
.parle-pill:focus-visible, .parle-close:focus-visible, .parle-pin:focus-visible {
  outline: 2px solid var(--parle-accent);
  outline-offset: 2px;
  border-radius: var(--parle-r-sm);
}

/* the panel */
.parle { display: flex; flex-direction: column; background: var(--parle-bg); }
.parle-head { flex: none; padding: var(--parle-4) var(--parle-4) var(--parle-2); }
.parle-heading {
  margin: 0 0 2px;
  font-size: var(--parle-t-lead);
  font-weight: 600;
  letter-spacing: -0.01em;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.parle-address {
  font-family: var(--parle-mono);
  font-size: var(--parle-t-meta);
  color: var(--parle-faint);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.parle-body {
  padding: 0 var(--parle-3) var(--parle-3);
  max-height: 420px;
  overflow-y: auto;
  overscroll-behavior: contain;
}
.parle-compact { min-height: 0; }
.parle-compact .parle-body {
  padding: 10px 16px 8px;
  flex: 1 1 auto;
  min-height: 0;
  max-height: none;
}
.parle-dock .parle { flex: 1 1 auto; min-height: 0; }
.parle-dock .parle-body {
  max-height: none;
  flex: 1 1 auto;
  min-height: 0;
  /*
   * A thin scrollbar, and its gutter reserved whether or not it is showing.
   *
   * The dock is a fixed 320-420px column, and Chrome's classic scrollbar takes
   * about 15px of it. Without a stable gutter it appears only once the content
   * overflows, so the whole column shifts left the moment a discussion is long
   * enough \u2014 and the close button, which is positioned against the dock rather
   * than against the scrolling content, does not shift with it. The result is
   * the header's controls sitting flush to the panel edge while every line
   * beneath them stops 15px short, which is exactly the misalignment visible in
   * store screenshot 01.
   */
  scrollbar-width: thin;
  scrollbar-gutter: stable;
}
.parle-dock .parle-compact { height: 100%; }
.parle-main { min-width: 0; }
.parle-extras { margin-top: var(--parle-3); }

/* discussions \u2014 Linked room vs Passing list, never blended */
.parle-group { margin: var(--parle-4) 0 0; }
.parle-group:first-child { margin-top: 0; }
.parle-group-name {
  margin: 0 0 var(--parle-2);
  font-size: var(--parle-t-meta);
  letter-spacing: 0.07em;
  text-transform: uppercase;
  font-weight: 700;
  color: var(--parle-mid);
}
.parle-group-note {
  display: block;
  margin-top: 2px;
  font-size: var(--parle-t-meta);
  color: var(--parle-faint);
  font-weight: 400;
  text-transform: none;
  letter-spacing: 0;
}
.parle-group-linked .parle-group-name { color: var(--parle-accent); }
.parle-row {
  display: block;
  padding: var(--parle-2) var(--parle-3);
  margin: 0 0 var(--parle-1);
  border-radius: var(--parle-r-sm);
  background: var(--parle-raise);
  transition: background 160ms var(--parle-motion);
}
.parle-row:hover { background: var(--parle-line); }
.parle-group-passing .parle-row { box-shadow: inset 2px 0 0 var(--parle-rule); }
.parle-title { display: block; font-weight: 500; margin-bottom: 2px; }
.parle a:hover .parle-title { text-decoration: underline; }
.parle-facts {
  display: flex;
  gap: var(--parle-2);
  flex-wrap: wrap;
  font-family: var(--parle-mono);
  font-size: var(--parle-t-meta);
  color: var(--parle-faint);
}
.parle-network { font-weight: 600; color: var(--parle-mid); }
.parle-repeat { font-style: italic; }

/*
 * Compact open room \u2014 comments first. Network identity lives on the bottom
 * nav icon; Parle's shell stays neutral. Subtle guides only.
 */
.parle-room { margin: 0; }
.parle-room-title {
  display: -webkit-box;
  margin: 0;
  padding: 2px 0 8px;
  overflow: hidden;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 2;
  color: var(--parle-ink);
  font-size: var(--parle-t-body);
  font-weight: 650;
  line-height: 1.35;
}
.parle-room-title:hover { text-decoration: underline; }
.parle-room-repeat {
  padding: 3px 0 5px;
  border-bottom: 1px solid var(--parle-line);
  color: var(--parle-faint);
  font-size: var(--parle-t-meta);
}
.parle-thread-picks {
  display: flex;
  gap: 6px;
  overflow-x: auto;
  margin: 0 0 8px;
  scrollbar-width: none;
}
.parle-thread-picks::-webkit-scrollbar { display: none; }
.parle-thread-pick {
  flex: none;
  max-width: 10em;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  border: 0;
  border-radius: 999px;
  padding: 4px 10px;
  background: var(--parle-raise);
  color: var(--parle-mid);
  font: 600 11px/1 var(--parle-font);
  cursor: pointer;
}
.parle-thread-pick-on {
  background: var(--parle-accent);
  color: var(--parle-on-accent);
}

.parle-home .parle-comments {
  margin: 0;
  padding: 0;
  border-left: 0;
}
.parle-home .parle-comment {
  margin: 0;
  padding: 9px 0;
  border-bottom: 1px solid var(--parle-line);
  border-left: 0;
}
.parle-home .parle-comment:last-child { border-bottom: 0; }
.parle-home .parle-replies {
  margin: 7px 0 0;
  padding: 0 0 0 12px;
  border-left: 1.5px solid var(--parle-line);
}
.parle-room[data-network="hackernews"] {
  --parle-guide: #ff6600;
}
.parle-room[data-network="reddit"] {
  --parle-guide: #ff4500;
}
.parle-room[data-network="x"] {
  --parle-guide: #536471;
}
.parle-room[data-network="bluesky"] {
  --parle-guide: #0085ff;
}
.parle-room[data-network="lemmy"] {
  --parle-guide: #00795c;
}
.parle-room[data-network="lobsters"] {
  --parle-guide: #ac130d;
}
@media (prefers-color-scheme: dark) {
  .parle-room[data-network="lemmy"] { --parle-guide: #00bc8c; }
  .parle-room[data-network="lobsters"] { --parle-guide: #e8503f; }
}
.parle-room[data-network] .parle-replies {
  border-left-color: color-mix(in srgb, var(--parle-guide) 48%, transparent);
}
.parle-room[data-network] .parle-comment-who { color: var(--parle-guide); font-weight: 700; }
.parle-room[data-network="x"] .parle-comment {
  border-left: 0;
  padding-left: 0;
}
.parle-room[data-network="x"] .parle-comment-who {
  color: var(--parle-ink);
  font-weight: 800;
}

/*
 * Adaptive nav \u2014 ~32px icon row. Counts are iOS-style badges on the icon's
 * top-right and do not add layout height. Settings sits apart on the right.
 *
 * Bottom is the default because the default has to be right on touch devices,
 * including a wide iPad. A desktop page with a precise pointing device moves
 * it above the conversation.
 *
 * There used to be a third case: browser-owned side panels carried a
 * parle-native class, because a ~400px sidebar document is desktop chrome
 * rather than a phone and width alone misclassified it. Chrome no longer has
 * one \u2014 the side panel is gone and the in-page dock is the only surface \u2014 so
 * the class and its rules went with it. The dock IS the surface desktop Safari
 * has, which is why the clearance below is not optional.
 */
.parle-nav-slot { flex: none; }
.parle-nav {
  display: flex;
  align-items: center;
  gap: 4px;
  min-height: calc(34px + env(safe-area-inset-bottom, 0px));
  padding: 3px 12px calc(3px + env(safe-area-inset-bottom, 0px));
  border-top: 1px solid var(--parle-line);
  background: var(--parle-bg);
}
.parle-nav-strip {
  display: flex;
  align-items: center;
  gap: 4px;
  flex: 1 1 auto;
  min-width: 0;
  overflow-x: auto;
  scrollbar-width: none;
}
.parle-nav-strip::-webkit-scrollbar { display: none; }
.parle-nav-item {
  position: relative;
  flex: none;
  width: 40px;
  height: 27px;
  display: inline-grid;
  place-items: center;
  border: 0;
  border-radius: 8px;
  background: transparent;
  color: var(--parle-mid);
  cursor: pointer;
  padding: 0;
}
.parle-nav-item:hover { background: var(--parle-raise); color: var(--parle-ink); }
.parle-nav-on { color: var(--parle-accent); }
.parle-nav-on::after {
  content: "";
  position: absolute;
  left: 12px;
  right: 12px;
  bottom: 0;
  height: 2px;
  border-radius: 999px;
  background: var(--parle-accent);
}
.parle-nav-icon {
  position: relative;
  display: inline-grid;
  place-items: center;
  width: 20px;
  height: 20px;
  overflow: visible;
}
.parle-nav-mark,
.parle-tab-mark {
  display: inline-grid;
  place-items: center;
  width: 20px;
  height: 20px;
  border-radius: 4px;
  overflow: hidden;
  color: inherit;
}
.parle-nav-mark svg,
.parle-tab-mark svg { display: block; width: 20px; height: 20px; }
.parle-nav-badge {
  position: absolute;
  top: -5px;
  right: -9px;
  z-index: 1;
  min-width: 12px;
  height: 12px;
  padding: 0 2.5px;
  border-radius: 999px;
  background: #ff3b30;
  color: #ffffff;
  font: 700 8px/12px var(--parle-font);
  font-variant-numeric: tabular-nums;
  text-align: center;
  box-shadow: 0 0 0 1.5px var(--parle-bg);
  pointer-events: none;
}
.parle-nav-soon {
  position: absolute;
  top: -3px;
  right: -4px;
  width: 6px;
  height: 6px;
  border-radius: 999px;
  background: var(--parle-accent);
  box-shadow: 0 0 0 1.5px var(--parle-bg);
  pointer-events: none;
}
.parle-nav-utilities {
  display: flex;
  align-items: center;
  flex: none;
  margin-left: 4px;
  padding-left: 5px;
  box-shadow: -1px 0 0 var(--parle-line);
}
.parle-nav-settings { width: 32px; color: var(--parle-mid); }
.parle-nav-settings svg { display: block; width: 16px; height: 16px; }
.parle-nav-settings::after { display: none; }

@media (min-width: 640px) and (hover: hover) and (pointer: fine) {
  .parle-compact .parle-nav-slot { order: -1; }
  .parle-compact .parle-nav {
    min-height: var(--parle-nav-h, 34px);
    padding: 3px 12px;
    border-top: 0;
    border-bottom: 1px solid var(--parle-line);
  }
  /*
   * Only inside this query does the navigation sit at the top, so only here can
   * the close button be centred on it. Outside it \u2014 touch, coarse pointer, a
   * narrow window \u2014 the row is the footer at the bottom of the column, and a
   * button positioned against the top of the dock has nothing to align with.
   * Coupling the two unconditionally made the alignment a property of the
   * viewport rather than of the stylesheet: measured on a non-matching display,
   * the same build gave close 1..33 against nav 766..800.
   */
  .parle-dock .parle-close,
  .parle-dock .parle-pin {
    top: calc(
      env(safe-area-inset-top, 0px) + (var(--parle-nav-h) - var(--parle-close-size)) / 2
    );
  }

  /*
   * The in-page dock owns an absolute close button in this corner, and the
   * clearance is derived from where that button actually is rather than from a
   * number that happened to work. When the close button moved left to clear the
   * scroll gutter, a fixed 48px left Settings overlapping it by 2px \u2014 caught by
   * the e2e box assertion, which is why that assertion exists.
   */
  .parle-dock .parle-compact .parle-nav {
    /* Two positioned buttons to clear now \u2014 the pin sits one slot left of the
       close, so the clearance is a close-width and a gap wider than it was. */
    padding-right: calc(86px + var(--parle-scroll-gutter, 0px));
  }
}

/* A Discussion's own words. */
.parle-open {
  border: 0; background: transparent; cursor: pointer; font: inherit;
  color: var(--parle-accent); padding: 0; text-decoration: underline;
}
.parle-comments {
  margin: var(--parle-1) 0 var(--parle-2) var(--parle-2);
  padding-left: var(--parle-2);
  border-left: 2px solid var(--parle-line);
}
.parle-comments-tools {
  display: flex; align-items: center; gap: var(--parle-3);
  min-height: 32px;
  margin-bottom: 0;
  border-bottom: 1px solid var(--parle-line);
}
.parle-comments-mode, .parle-comments-collapse, .parle-comment-more, .parle-comments-more,
.parle-comments-open {
  border: 0; background: transparent; cursor: pointer; font: inherit;
  color: var(--parle-accent); padding: 0; text-decoration: none;
  font-size: var(--parle-t-meta); font-weight: 600;
}
.parle-comments-mode {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  flex: none;
  color: var(--parle-ink);
}
.parle-comments-mode svg { display: block; width: 15px; height: 15px; color: var(--parle-mid); }
.parle-comments-chevron { color: var(--parle-faint); font-size: 10px; transform: translateY(-1px); }
.parle-comments-collapse { color: var(--parle-accent); font-weight: 500; }
.parle-comments-collapse:hover { color: var(--parle-ink); }
.parle-comments-spacer { flex: 1 1 auto; }
.parle-comments-open,
.parle-comments-more-actions {
  display: inline-grid;
  place-items: center;
  width: 24px;
  height: 24px;
  color: var(--parle-mid);
}
.parle-comments-open:hover,
.parle-comments-more-actions:hover { color: var(--parle-ink); }
.parle-comments-open svg,
.parle-comments-more-actions svg { display: block; width: 14px; height: 14px; }
.parle-comments-menu-wrap { position: relative; display: inline-grid; }
.parle-comments-menu {
  position: absolute;
  z-index: 2;
  top: 26px;
  right: 0;
  min-width: 150px;
  padding: 4px;
  border: 1px solid var(--parle-line);
  border-radius: 8px;
  background: var(--parle-bg);
  box-shadow: var(--parle-lift);
}
.parle-comments-menu[hidden] { display: none; }
.parle-comments-menu-item {
  display: block;
  width: 100%;
  border: 0;
  border-radius: 5px;
  padding: 6px 8px;
  background: transparent;
  color: var(--parle-ink);
  font: 500 var(--parle-t-meta)/1.3 var(--parle-font);
  text-align: left;
  cursor: pointer;
}
.parle-comments-menu-item:hover { background: var(--parle-raise); }
.parle-comments-more { margin: var(--parle-1) 0 var(--parle-2); text-decoration: underline; }
.parle-comment { margin-bottom: var(--parle-2); min-width: 0; }
.parle-comment-who { color: var(--parle-mid); font-size: var(--parle-t-meta); }
.parle-comment-age { margin-left: var(--parle-1); color: var(--parle-faint); font-weight: 400; }
.parle-comment-text {
  margin: 2px 0 0; white-space: pre-wrap; overflow-wrap: anywhere;
  line-height: 1.45;
}
.parle-comment-more {
  display: inline-flex;
  align-items: center;
  gap: 3px;
  min-height: 22px;
  margin-top: 2px;
  font-size: var(--parle-t-meta);
  color: var(--parle-mid);
}
.parle-comment-more::before {
  content: "\u203A";
  font-size: 14px;
  line-height: 1;
  color: var(--parle-guide, var(--parle-faint));
}
.parle-replies {
  margin: var(--parle-2) 0 0 var(--parle-2);
  padding-left: var(--parle-2);
  border-left: 2px solid var(--parle-line);
}
.parle-comments-note { color: var(--parle-mid); font-size: var(--parle-t-meta); margin: 0; }

/* a site's front door: what was set aside, and the one click that opens it.
   Quiet rather than warning-coloured \u2014 nothing has gone wrong here, and the
   product's own rule is that a suppression must read as a decision the reader
   can reverse rather than as an error they have to interpret. */
.parle-folded {
  margin: var(--parle-3) 0 0;
  padding: var(--parle-3);
  border-radius: var(--parle-r-sm);
  background: var(--parle-raise);
}
.parle-folded-says {
  margin: 0 0 var(--parle-2);
  font-size: var(--parle-t-meta);
  color: var(--parle-mid);
}
.parle-act-folded { font-size: var(--parle-t-meta); padding: var(--parle-1) var(--parle-3); }
.parle-folded-rows { margin-top: var(--parle-2); }
.parle-folded-rows .parle-row { background: var(--parle-bg); }

/* tones \u2014 six states, six inks, no washes (ADR 0011) */
.parle-tone-refused { color: var(--parle-stop); }
.parle-tone-garbled { color: var(--parle-warn); }
.parle-tone-withheld, .parle-tone-waiting, .parle-tone-quiet { color: var(--parle-mid); }
.parle-tone-found { color: var(--parle-accent); }
.parle-notice {
  display: flex;
  justify-content: space-between;
  gap: var(--parle-2);
  margin: var(--parle-2) 0 0;
  padding: var(--parle-2) var(--parle-3);
  border-radius: var(--parle-r-sm);
  background: var(--parle-raise);
  font-size: var(--parle-t-meta);
}
.parle-said { margin: var(--parle-3) 0; color: var(--parle-mid); }
.parle-restraint { margin: var(--parle-3) 0 var(--parle-4); color: var(--parle-mid); }
.parle-restraint-says { margin: 0 0 var(--parle-3); color: var(--parle-ink); }

/* actions \u2014 outlined, so a button is a button on whatever it sits on */
.parle-act {
  all: unset;
  display: inline-block;
  cursor: pointer;
  font-family: var(--parle-font);
  font-size: var(--parle-t-body);
  font-weight: 550;
  padding: var(--parle-2) var(--parle-4);
  border-radius: var(--parle-r-full);
  color: var(--parle-ink);
  background: var(--parle-bg);
  box-shadow: inset 0 0 0 1px var(--parle-rule);
  transition: background 160ms var(--parle-motion), opacity 160ms var(--parle-motion);
}
.parle-act:hover { background: var(--parle-raise); }
.parle-act-strong {
  background: var(--parle-accent);
  color: var(--parle-on-accent);
  box-shadow: none;
}
.parle-act-strong:hover { background: var(--parle-accent); opacity: 0.88; }
.parle-link {
  all: unset;
  cursor: pointer;
  font-family: var(--parle-font);
  font-size: var(--parle-t-meta);
  color: var(--parle-mid);
  transition: color 160ms var(--parle-motion);
}
.parle-link:hover { color: var(--parle-ink); text-decoration: underline; }
.parle-note { margin: var(--parle-4) 0 0; font-size: var(--parle-t-meta); color: var(--parle-mid); }
/* the footer \u2014 rows declared, never wrapped into */
.parle-footer {
  flex: none;
  display: flex;
  flex-direction: column;
  gap: var(--parle-2);
  border-top: 1px solid var(--parle-line);
  padding: var(--parle-3) var(--parle-4);
  font-size: var(--parle-t-meta);
  color: var(--parle-faint);
}
.parle-footer-row {
  display: flex;
  align-items: center;
  gap: var(--parle-3);
  flex-wrap: wrap;
}
.parle-footer-state { margin-right: auto; color: var(--parle-mid); }

/* what is known about the page itself, and about who publishes it */
.parle-context { margin: var(--parle-4) 0 0; }
.parle-context-group + .parle-context-group { margin-top: var(--parle-3); }
.parle-context-name {
  margin: 0 0 var(--parle-1);
  font-size: var(--parle-t-meta);
  letter-spacing: 0.07em;
  text-transform: uppercase;
  font-weight: 700;
  color: var(--parle-faint);
}
.parle-context-line {
  display: block;
  max-width: 62ch;
  padding: var(--parle-1) 0;
  font-size: var(--parle-t-meta);
  line-height: 1.5;
}
.parle-context-says { margin-right: var(--parle-1); }
.parle-context-link,
.parle-context-cite {
  color: inherit;
  text-decoration: none;
  box-shadow: inset 0 -1px 0 var(--parle-line);
  transition: box-shadow 160ms var(--parle-motion);
}
.parle-context-link:hover,
.parle-context-cite:hover { box-shadow: inset 0 -1px 0 var(--parle-rule); }
.parle-context-cite + .parle-context-cite { margin-left: var(--parle-2); }

/* the account of every place we asked \u2014 the toolbar surface's whole job */
.parle-coverage { margin: var(--parle-4) 0 0; }
.parle-coverage-name {
  margin: 0 0 var(--parle-1);
  font-size: var(--parle-t-meta);
  letter-spacing: 0.07em;
  text-transform: uppercase;
  font-weight: 700;
  color: var(--parle-faint);
}
.parle-account {
  display: flex;
  justify-content: space-between;
  gap: var(--parle-3);
  padding: var(--parle-1) 0;
  font-size: var(--parle-t-meta);
  color: var(--parle-mid);
}
.parle-account-place { color: var(--parle-mid); }
.parle-account-waiting { color: var(--parle-faint); }
.parle-account-refused { color: var(--parle-stop); }
.parle-account-garbled { color: var(--parle-warn); }
.parle-account-found { color: var(--parle-accent); }

/* digest */
.parle-digest {
  margin: var(--parle-4) 0 0;
  padding: var(--parle-3);
  border-radius: var(--parle-r);
  background: var(--parle-raise);
  color: var(--parle-mid);
}
.parle-compact .parle-digest { margin-top: 0; }
.parle-digest-title { margin: 0 0 var(--parle-2); font-size: var(--parle-t-body); font-weight: 600; color: var(--parle-ink); }
.parle-digest-says { margin: 0 0 var(--parle-2); }
.parle-digest-partial { margin: var(--parle-2) 0 0; font-size: var(--parle-t-meta); }
.parle-digest-wrote { margin: var(--parle-2) 0 0; font-size: var(--parle-t-meta); color: var(--parle-faint); }
.parle-act-digest { margin-top: var(--parle-1); }
.parle-finding { margin: 0 0 var(--parle-3); }
.parle-finding:last-of-type { margin-bottom: 0; }
.parle-finding-says { margin: 0 0 var(--parle-1); color: var(--parle-ink); }
/* disputed: the neutral ink, never the accent and never a warning (ADR 0006) */
.parle-finding-disputed { box-shadow: inset 2px 0 0 var(--parle-rule); padding-left: var(--parle-3); }
.parle-disputed {
  display: block;
  margin-bottom: 2px;
  font-size: var(--parle-t-meta);
  text-transform: uppercase;
  letter-spacing: 0.05em;
  color: var(--parle-faint);
}
/* citations: underlined always, because they are meant to be followed (ADR 0006) */
.parle-sources { display: flex; flex-wrap: wrap; gap: var(--parle-1) var(--parle-3); }
.parle a.parle-source {
  font-size: var(--parle-t-meta);
  color: var(--parle-mid);
  text-decoration: underline;
  text-underline-offset: 2px;
  text-decoration-thickness: 1px;
  cursor: pointer;
}
.parle a.parle-source:hover { color: var(--parle-ink); }
.parle-spinner {
  display: inline-block;
  width: 6px;
  height: 6px;
  border-radius: var(--parle-r-full);
  background: currentColor;
  margin-right: var(--parle-2);
  vertical-align: middle;
  animation: parle-pulse 1.4s var(--parle-motion) infinite;
}
@keyframes parle-pulse { 0%, 100% { opacity: 0.25; } 50% { opacity: 1; } }

/* the mark \u2014 parked by the reader, only when there is something, still after it arrives */
.parle-pill {
  position: fixed;
  top: var(--parle-4);
  left: auto;
  right: var(--parle-4);
  bottom: auto;
  margin: 0;
  z-index: 2147483646;
  display: grid;
  place-items: center;
  min-width: 36px;
  height: 36px;
  padding: 4px;
  border: 0;
  border-radius: var(--parle-r-full);
  background: var(--parle-bg);
  color: var(--parle-ink);
  box-shadow: var(--parle-lift), inset 0 0 0 1px var(--parle-line);
  cursor: grab;
  touch-action: none;
  user-select: none;
  font-family: var(--parle-font);
  font-size: var(--parle-t-meta);
  font-weight: 650;
  transition: transform 160ms var(--parle-motion), box-shadow 160ms var(--parle-motion);
  animation: parle-arrive 420ms var(--parle-motion) both;
}
.parle-pill:hover { transform: scale(1.05); }
.parle-pill[data-dragging="1"] {
  cursor: grabbing;
  transform: scale(1.08);
  box-shadow: var(--parle-lift), inset 0 0 0 1px var(--parle-accent);
  transition: none;
}
.parle-pill[hidden], .parle-pill[data-found="0"] { display: none; }
.parle-pill svg, .parle-close svg { display: block; width: 16px; height: 16px; }
.parle-pill svg:not([fill]), .parle-close svg:not([fill]) { fill: currentColor; }
.parle-stack {
  display: flex;
  flex-direction: row;
  align-items: center;
}
.parle-stack-disc {
  display: grid;
  place-items: center;
  width: 28px;
  height: 28px;
  border-radius: var(--parle-r-full);
  background: var(--parle-bg);
  box-shadow: 0 0 0 2px var(--parle-bg);
  overflow: hidden;
}
.parle-stack-disc + .parle-stack-disc { margin-left: -10px; }
.parle-stack-disc svg { width: 28px; height: 28px; }
.parle-stack-parle {
  color: var(--parle-ink);
  background: var(--parle-raise);
}
.parle-stack-parle svg { width: 16px; height: 16px; }
.parle-pill-count {
  position: absolute;
  top: -4px;
  right: -4px;
  min-width: 18px;
  height: 18px;
  padding: 0 5px;
  border-radius: var(--parle-r-full);
  background: var(--parle-accent);
  color: var(--parle-on-accent);
  font-size: 10px;
  font-weight: 700;
  line-height: 18px;
  text-align: center;
  box-shadow: 0 0 0 2px var(--parle-bg);
}
.parle-pill-count:empty { display: none; }
/* the announcement: one ring, outward, once */
.parle-pill::after {
  content: "";
  position: absolute;
  inset: -2px;
  border-radius: var(--parle-r-full);
  border: 2px solid var(--parle-accent);
  pointer-events: none;
  animation: parle-ring 1100ms var(--parle-motion) 1 both;
}
@keyframes parle-arrive {
  from { opacity: 0; transform: translateY(-6px) scale(0.8); }
  to { opacity: 1; transform: none; }
}
@keyframes parle-ring {
  from { opacity: 0.55; transform: scale(1); }
  to { opacity: 0; transform: scale(2.1); }
}

/* the surface \u2014 full screen under 640px, docked right at and above it */
.parle-dock {
  --parle-scroll-gutter: 10px;
  --parle-nav-h: 34px;
  --parle-close-size: 32px;
  position: fixed;
  inset: 0;
  z-index: 2147483647;
  display: flex;
  flex-direction: column;
  background: var(--parle-bg);
  box-shadow: var(--parle-lift);
  overscroll-behavior: contain;
  padding-top: env(safe-area-inset-top, 0px);
  padding-bottom: env(safe-area-inset-bottom, 0px);
  animation: parle-open 180ms var(--parle-motion) both;
}
@keyframes parle-open { from { opacity: 0; } to { opacity: 1; } }
@media (min-width: 640px) {
  .parle-dock { inset: 0 0 0 auto; width: clamp(320px, 30vw, 420px); padding-bottom: 0; }
  /* Dragged to the other edge by its pin; the held room follows it there. */
  .parle-dock[data-side="left"] { inset: 0 auto 0 0; }
  /* Mid-drag the surface rides the pointer as a transform; nothing animates
     against it, and no text on it gets selected along the way. */
  .parle-dock[data-dragging="1"] { animation: none; user-select: none; }
}
/* the way out of the surface, drawn as a button */
.parle-close {
  all: unset;
  position: absolute;
  /*
   * The default: a plain offset from the top of the dock.
   *
   * This button is a child of .parle-dock, not of the row it appears to sit
   * beside, so it is positioned rather than laid out \u2014 and the row it appears
   * to sit beside is not always there. Navigation is only the header inside the
   * pointer-driven desktop query below; on touch and coarse-pointer surfaces it
   * is the footer at the bottom of the column, and a button aligned to it would
   * be aligned to nothing. Centring on the row therefore lives inside that
   * query, not here.
   */
  top: calc(env(safe-area-inset-top, 0px) + var(--parle-2));
  /* Clears the scroll gutter below it so the panel has one right edge. */
  right: calc(var(--parle-2) + var(--parle-scroll-gutter, 0px));
  z-index: 1;
  display: grid;
  place-items: center;
  width: var(--parle-close-size);
  height: var(--parle-close-size);
  border-radius: var(--parle-r-full);
  background: var(--parle-raise);
  cursor: pointer;
  font-family: var(--parle-font);
  font-size: var(--parle-t-head);
  line-height: 1;
  color: var(--parle-mid);
  transition: background 160ms var(--parle-motion), color 160ms var(--parle-motion);
}
.parle-close:hover { background: var(--parle-line); color: var(--parle-ink); }
/*
 * The pin: the close button's twin, one slot to its left. It shares the close
 * button's positioning story completely \u2014 a child of the dock, positioned
 * rather than laid out, centred on the navigation row only inside the query
 * that makes that row the header \u2014 so every rule below mirrors .parle-close
 * with one more button-width of right offset.
 */
.parle-pin {
  all: unset;
  position: absolute;
  top: calc(env(safe-area-inset-top, 0px) + var(--parle-2));
  right: calc(var(--parle-2) + var(--parle-scroll-gutter, 0px) + var(--parle-close-size) + 6px);
  z-index: 1;
  display: grid;
  place-items: center;
  width: var(--parle-close-size);
  height: var(--parle-close-size);
  border-radius: var(--parle-r-full);
  background: var(--parle-raise);
  cursor: pointer;
  color: var(--parle-mid);
  transition: background 160ms var(--parle-motion), color 160ms var(--parle-motion);
}
.parle-pin:hover { background: var(--parle-line); color: var(--parle-ink); }
.parle-pin[aria-pressed="true"] { background: var(--parle-line); color: var(--parle-accent); }
.parle-pin svg { display: block; width: 15px; height: 15px; }
.parle-pin svg:not([fill]) { fill: currentColor; }
/* Two positioned controls to clear now \u2014 the pin sits one slot left of close. */
.parle-dock .parle-head { padding-right: 90px; }
@media (max-width: 639px) {
  /* The surface is the whole screen here \u2014 there is no page beside it to pin. */
  .parle-pin { display: none; }
  .parle-close {
    top: calc(env(safe-area-inset-top, 0px) + var(--parle-3));
    right: var(--parle-3);
    width: 40px;
    height: 40px;
  }
  .parle-dock .parle-head { padding-right: 64px; padding-top: var(--parle-5); }
  .parle-dock .parle-heading {
    white-space: normal;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
  }
}

@media (prefers-reduced-motion: reduce) {
  .parle, .parle *,
  .parle-pill, .parle-pill::after,
  .parle-dock, .parle-close, .parle-pin { animation: none !important; transition: none !important; }
  .parle-pill::after { opacity: 0; }
}
`,Ae="__parle_pill_mounted__",Se=36,Ee=5,ne=()=>({width:document.documentElement.clientWidth,height:document.documentElement.clientHeight}),oe=e=>({width:Math.max(Se,e.offsetWidth),height:Math.max(Se,e.offsetHeight)}),Le=e=>{if("showPopover"in e)try{e.setAttribute("popover","manual"),e.showPopover()}catch{e.removeAttribute("popover")}},H=e=>{try{typeof e.hidePopover=="function"&&e.hidePopover()}catch{}},Qt=e=>`${e} discussion${e===1?"":"s"}`,Zt={matches:["http://*/*","https://*/*"],registration:"runtime",runAt:"document_idle",allFrames:!1,main:()=>{const e=window;if(e[Ae]===!0)return;e[Ae]=!0;let t=null,r=Fe,a=null,n=null,l=null,p=null,m=null,d=null,v=null,x=null,u=!1,w="right",s=null;const h=640,c=()=>{const o=document.documentElement.clientWidth;if(o<h){g();return}if(d===null||!u)return;const b=d.getBoundingClientRect().width;if(b===0||b>=o)return;const f=document.documentElement.style;s===null&&(s={left:f.marginLeft,right:f.marginRight}),w==="right"?(s.left===""?f.removeProperty("margin-left"):f.marginLeft=s.left,f.setProperty("margin-right",`${b}px`,"important")):(s.right===""?f.removeProperty("margin-right"):f.marginRight=s.right,f.setProperty("margin-left",`${b}px`,"important"))},g=()=>{if(s===null)return;const o=document.documentElement.style;s.right===""?o.removeProperty("margin-right"):o.marginRight=s.right,s.left===""?o.removeProperty("margin-left"):o.marginLeft=s.left,s=null},S=()=>{if(l===null)return;const o=oe(l),{left:b,top:f}=qe(r,o,ne());l.style.left=`${b}px`,l.style.top=`${f}px`,l.style.right="auto",l.style.bottom="auto",l.style.margin="0"},O=o=>{let b=0,f=0,y=0,L=0,C=!1,R=!1;const X=E=>{const N=E.clientX-b,T=E.clientY-f;if(!C){if(Math.hypot(N,T)<Ee)return;C=!0,R=!0,o.dataset.dragging="1",o.setPointerCapture(E.pointerId)}const W=ne(),Ie=oe(o),lr=Math.max(16,W.width-Ie.width-16),sr=Math.max(16,W.height-Ie.height-16),pr=Math.min(lr,Math.max(16,y+N)),dr=Math.min(sr,Math.max(16,L+T));o.style.left=`${pr}px`,o.style.top=`${dr}px`,o.style.right="auto",o.style.bottom="auto",o.style.margin="0"},I=E=>{if(window.removeEventListener("pointermove",X,!0),window.removeEventListener("pointerup",I,!0),window.removeEventListener("pointercancel",I,!0),C){o.dataset.dragging="0";try{o.releasePointerCapture(E.pointerId)}catch{}const N=Number.parseFloat(o.style.left||"0"),T=Number.parseFloat(o.style.top||"0"),W=oe(o);r=Ve(N,T,W,ne()),S(),A.say(at(r))}C=!1};o.addEventListener("pointerdown",E=>{if(E.button!==0)return;b=E.clientX,f=E.clientY;const N=o.getBoundingClientRect();y=N.left,L=N.top,R=!1,C=!1,window.addEventListener("pointermove",X,!0),window.addEventListener("pointerup",I,!0),window.addEventListener("pointercancel",I,!0)}),o.addEventListener("click",E=>{if(R){E.preventDefault(),E.stopPropagation(),R=!1;return}z()})},_=()=>{if(a!==null)return;const o=document.createElement("div");o.style.setProperty("all","initial");const b=o.attachShadow({mode:"closed"}),f=document.createElement("style");f.textContent=Kt,b.appendChild(f);const y=document.createElement("button");y.className="parle-pill",y.type="button";const L=ve([]);y.appendChild(L);const C=document.createElement("span");C.className="parle-pill-count",y.appendChild(C),O(y),b.appendChild(y),document.documentElement.appendChild(o),Le(y),a=o,n=b,l=y,p=C,m=L,S()},k=()=>{a!==null&&(d!==null&&A.say(de()),x=null,re(),g(),u=!1,w="right",d!==null&&H(d),l!==null&&H(l),a.remove(),a=null,n=null,l=null,p=null,m=null,d=null,v=null)},z=()=>{d===null?U():q()},U=()=>{if(n===null||d!==null||t===null)return;x=Date.now(),A.say(pe(x));const o=document.createElement("div");o.className="parle-dock",o.dataset.side=w,o.setAttribute("role","dialog"),o.setAttribute("aria-label","Parle");const b=document.createElement("button");b.className="parle-close",b.type="button",b.setAttribute("aria-label","Close"),b.textContent="\xD7",b.addEventListener("click",q),o.appendChild(b);const f=document.createElement("button");f.className="parle-pin",f.type="button",f.setAttribute("aria-label",u?"Unpin":"Pin beside the page"),f.setAttribute("aria-pressed",u?"true":"false"),f.innerHTML='<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M9.5 1.5 14.5 6.5 13 8l-.7-.2-2.6 2.6.3 2.1-1.2 1.2-3-3-3.6 3.6-1-1 3.6-3.6-3-3L3 5.5l2.1.3 2.6-2.6L7.5 2.5z"/></svg>',f.title="Pin beside the page. Drag to either edge.";let y=!1;f.addEventListener("pointerdown",C=>{if(C.button!==0)return;const R=C.clientX,X=C.clientY;let I=!1;y=!1;const E=T=>{const W=T.clientX-R;if(!I){if(Math.hypot(W,T.clientY-X)<Ee)return;I=!0,y=!0,o.dataset.dragging="1",f.setPointerCapture(C.pointerId)}o.style.transform=`translateX(${W}px)`},N=T=>{if(window.removeEventListener("pointermove",E,!0),window.removeEventListener("pointerup",N,!0),window.removeEventListener("pointercancel",N,!0),!!I){delete o.dataset.dragging,o.style.removeProperty("transform");try{f.releasePointerCapture(T.pointerId)}catch{}w=T.clientX<document.documentElement.clientWidth/2?"left":"right",o.dataset.side=w,u&&c()}};window.addEventListener("pointermove",E,!0),window.addEventListener("pointerup",N,!0),window.addEventListener("pointercancel",N,!0)}),f.addEventListener("click",()=>{if(y){y=!1;return}u=!u,f.setAttribute("aria-pressed",u?"true":"false"),f.setAttribute("aria-label",u?"Unpin":"Pin beside the page"),u?c():g()}),o.appendChild(f);const L=document.createElement("div");L.className="parle",o.appendChild(L),n.appendChild(o),d=o,v=L,l!==null&&H(l),c(),Ce(L,t,Ne),b.focus({preventScroll:!0})},q=()=>{d!==null&&(A.say(de()),x=null,re(),g(),H(d),d.remove(),d=null,v=null,l!==null&&(Le(l),S()),l?.focus({preventScroll:!0}))},nr=o=>{if(l===null)return;const b=Q([...o.linked,...o.passing]),f=ve(b);m!==null?m.replaceWith(f):l.insertBefore(f,p),m=f},or=()=>{if(t===null)return;const o=Z(t);if(o===0){k();return}if(_(),nr(t),S(),p!==null&&(p.textContent=String(Math.min(o,99))),l!==null){l.dataset.found=String(o);const b=[...t.linked,...t.passing],f=Q(b),y=f.length===0?"":` on ${f.map(C=>b.find(R=>R.network===C)?.networkName??"").filter(C=>C!=="").join(" \xB7 ")}`,L=`Parle \u2014 ${Qt(o)}${y}`;l.setAttribute("aria-label",L),l.title=`${L}. Drag to move.`}v!==null&&Ce(v,t,Ne)},A=ct(Ye,o=>{o._tag==="Standing"&&(t=o.panel,r=o.markPark,or())},()=>{re(),d!==null&&x!==null&&A.say(pe(x))}),Ne={openOut:o=>A.say(Be(o)),lookAnyway:()=>A.say(Xe()),summarise:()=>A.say(Ke()),readDiscussion:o=>A.say(Qe(o)),decide:o=>A.say(Ze(o)),openDisclosure:()=>A.say(Je()),openSettings:()=>A.say(rt()),pauseSite:o=>A.say(et(o)),resumeSite:o=>A.say(tt(o))},$e=o=>{d===null||o.key!=="Escape"||(o.stopPropagation(),q())};window.addEventListener("keydown",$e,!0);const Te=o=>{d===null||u||a===null||o.button===0&&(o.composedPath().includes(a)||q())};window.addEventListener("pointerdown",Te,!0);const Pe=()=>{S(),u&&d!==null&&c()};window.addEventListener("resize",Pe),A.say(He(null),!0);const _e=()=>{A.say(je(location.href,document.title,document.referrer),!0)};_e();const ze=o=>{const b=o.indexOf("#");return b===-1?o:o.slice(0,b)};let De=ze(location.href);const le=()=>{const o=ze(location.href);o!==De&&(De=o,k(),_e())};window.addEventListener("popstate",le),window.addEventListener("hashchange",le);const Oe=new MutationObserver(le),Re=document.querySelector("title");Re!==null&&Oe.observe(Re,{childList:!0});const ir=ht(()=>{});window.addEventListener("pagehide",()=>{ir(),Oe.disconnect(),window.removeEventListener("keydown",$e,!0),window.removeEventListener("pointerdown",Te,!0),window.removeEventListener("resize",Pe),k(),A.close()})}};function j(e,...t){}const Jt={debug:(...e)=>j(console.debug,...e),log:(...e)=>j(console.log,...e),warn:(...e)=>j(console.warn,...e),error:(...e)=>j(console.error,...e)};var Me=class We extends Event{static EVENT_NAME=ie("wxt:locationchange");constructor(t,r){super(We.EVENT_NAME,{}),this.newUrl=t,this.oldUrl=r}};function ie(e){return`${K?.runtime?.id}:pill:${e}`}const er=typeof globalThis.navigation?.addEventListener=="function";function tr(e){let t,r=!1;return{run(){r||(r=!0,t=new URL(location.href),er?globalThis.navigation.addEventListener("navigate",a=>{const n=new URL(a.destination.url);n.href!==t.href&&(window.dispatchEvent(new Me(n,t)),t=n)},{signal:e.signal}):e.setInterval(()=>{const a=new URL(location.href);a.href!==t.href&&(window.dispatchEvent(new Me(a,t)),t=a)},1e3))}}}var rr=class V{static SCRIPT_STARTED_MESSAGE_TYPE=ie("wxt:content-script-started");id;abortController;locationWatcher=tr(this);constructor(t,r){this.contentScriptName=t,this.options=r,this.id=Math.random().toString(36).slice(2),this.abortController=new AbortController,this.stopOldScripts(),this.listenForNewerScripts()}get signal(){return this.abortController.signal}abort(t){return this.abortController.abort(t)}get isInvalid(){return K.runtime?.id==null&&this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(t){return this.signal.addEventListener("abort",t),()=>this.signal.removeEventListener("abort",t)}block(){return new Promise(()=>{})}setInterval(t,r){const a=setInterval(()=>{this.isValid&&t()},r);return this.onInvalidated(()=>clearInterval(a)),a}setTimeout(t,r){const a=setTimeout(()=>{this.isValid&&t()},r);return this.onInvalidated(()=>clearTimeout(a)),a}requestAnimationFrame(t){const r=requestAnimationFrame((...a)=>{this.isValid&&t(...a)});return this.onInvalidated(()=>cancelAnimationFrame(r)),r}requestIdleCallback(t,r){const a=requestIdleCallback((...n)=>{this.signal.aborted||t(...n)},r);return this.onInvalidated(()=>cancelIdleCallback(a)),a}addEventListener(t,r,a,n){r==="wxt:locationchange"&&this.isValid&&this.locationWatcher.run(),t.addEventListener?.(r.startsWith("wxt:")?ie(r):r,a,{...n,signal:this.signal})}notifyInvalidated(){this.abort("Content script context invalidated"),Jt.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){document.dispatchEvent(new CustomEvent(V.SCRIPT_STARTED_MESSAGE_TYPE,{detail:{contentScriptName:this.contentScriptName,messageId:this.id}})),this.options?.noScriptStartedPostMessage||window.postMessage({type:V.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:this.id},"*")}verifyScriptStartedEvent(t){const r=t.detail?.contentScriptName===this.contentScriptName,a=t.detail?.messageId===this.id;return r&&!a}listenForNewerScripts(){const t=r=>{!(r instanceof CustomEvent)||!this.verifyScriptStartedEvent(r)||this.notifyInvalidated()};document.addEventListener(V.SCRIPT_STARTED_MESSAGE_TYPE,t),this.onInvalidated(()=>document.removeEventListener(V.SCRIPT_STARTED_MESSAGE_TYPE,t))}};function mr(){}function B(e,...t){}const ar={debug:(...e)=>B(console.debug,...e),log:(...e)=>B(console.log,...e),warn:(...e)=>B(console.warn,...e),error:(...e)=>B(console.error,...e)};return(async()=>{try{const{main:e,...t}=Zt;return await e(new rr("pill",t))}catch(e){throw ar.error('The content script "pill" crashed on startup!',e),e}})()})();
