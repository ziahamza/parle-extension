(function(){"use strict";function Yt(e){return e}const j=globalThis.browser?.runtime?.id?globalThis.browser:globalThis.chrome,Te={x:1,y:0},ae=e=>Math.min(1,Math.max(0,e)),$e=(e,t)=>({x:ae(e),y:ae(t)}),_e=e=>{if(typeof e!="object"||e===null)return!1;const t=e;return typeof t.x=="number"&&Number.isFinite(t.x)&&typeof t.y=="number"&&Number.isFinite(t.y)},ze=(e,t,r,a=16)=>{const n=Math.max(a,r.width-t-a),s=Math.max(a,r.height-t-a);return{left:Math.round(a+e.x*(n-a)),top:Math.round(a+e.y*(s-a))}},Pe=(e,t,r,a,n=16)=>{const s=Math.max(n,a.width-r-n),p=Math.max(n,a.height-r-n),d=Math.max(1,s-n),u=Math.max(1,p-n);return $e((e-n)/d,(t-n)/u)},Oe="parle-pill",Re=e=>({_tag:"Watch",tabId:e}),De=(e,t,r)=>({_tag:"Sighted",address:e,title:t,referrer:r}),Ie=e=>({_tag:"OpenOut",address:e}),We=()=>({_tag:"LookAnyway"}),Fe=()=>({_tag:"Summarise"}),Ge=e=>({_tag:"ReadDiscussion",key:e}),Ue=e=>({_tag:"Decide",automatic:e}),Ve=()=>({_tag:"OpenDisclosure"}),He=e=>({_tag:"PauseSite",host:e}),qe=e=>({_tag:"ResumeSite",host:e}),Ye=()=>({_tag:"OpenSettings"}),je=e=>({_tag:"ParkMark",park:e}),Be=(e,t,r)=>({_tag:"Standing",tabId:e,panel:t,markPark:r}),Ke=e=>({_tag:"Told",decision:e}),Xe=e=>typeof e=="object"&&e!==null&&"_tag"in e&&typeof e._tag=="string"?e._tag:null,Qe=e=>e==="undecided"||e==="automatic"||e==="manual",Ze=e=>{switch(Xe(e)){case"Standing":{const t=e;if(typeof t.tabId!="number")return null;const r=t.panel;if(typeof r!="object"||r===null||!Array.isArray(r.linked)||!Array.isArray(r.accounts))return null;const a=_e(t.markPark)?t.markPark:{x:1,y:0};return Be(t.tabId,r,a)}case"Told":{const t=e.decision;return Qe(t)?Ke(t):null}default:return null}},Je=400,et=(e,t)=>{let r=null,a=!1;const n=[],s=d=>{if(r===null)return!1;try{return r.postMessage(d),!0}catch{return!1}},p=()=>{if(!a){r=j.runtime.connect({name:e}),r.onMessage.addListener(d=>{const u=Ze(d);u!==null&&t(u)}),r.onDisconnect.addListener(()=>{r=null,a||setTimeout(p,Je)});for(const d of n)s(d)}};return p(),{say:(d,u=!1)=>(u&&n.push(d),s(d)),close:()=>{a=!0;try{r?.disconnect()}catch{}r=null}}},ne=32,tt=(e,t,r)=>{if(r<=t)return null;const a=e.slice(t,r);return a.trim()===""?null:{exact:a,prefix:e.slice(Math.max(0,t-ne),t),suffix:e.slice(r,r+ne),wasAt:t}},rt=e=>{const t=()=>{const r=document.getSelection();if(r===null||r.isCollapsed||r.rangeCount===0)return;const a=r.toString(),n=document.body.textContent??"",s=n.indexOf(a);e(s===-1?{exact:a,prefix:"",suffix:"",wasAt:0}:tt(n,s,s+a.length))};return document.addEventListener("selectionchange",t,{passive:!0}),()=>document.removeEventListener("selectionchange",t)},I="http://www.w3.org/2000/svg",N=e=>{const t=document.createElementNS(I,"svg");return t.setAttribute("viewBox",e),t.setAttribute("aria-hidden","true"),t},M=(e,t)=>{const r=document.createElementNS(I,"path");return r.setAttribute("d",e),t!==void 0&&r.setAttribute("fill",t),r},at=(e,t,r,a,n,s)=>{const p=document.createElementNS(I,"rect");return p.setAttribute("x",String(e)),p.setAttribute("y",String(t)),p.setAttribute("width",String(r)),p.setAttribute("height",String(a)),p.setAttribute("rx",String(n)),p.setAttribute("fill",s),p},O=(e,t,r,a)=>{const n=document.createElementNS(I,"circle");return n.setAttribute("cx",String(e)),n.setAttribute("cy",String(t)),n.setAttribute("r",String(r)),n.setAttribute("fill",a),n},nt=()=>{const e=N("0 0 16 16");return e.appendChild(M("M8 1.6c-3.6 0-6.5 2.3-6.5 5.2 0 1.7 1 3.2 2.5 4.1L3.3 14l3.2-1.7c.5.1 1 .1 1.5.1 3.6 0 6.5-2.3 6.5-5.2S11.6 1.6 8 1.6z")),e},ot=()=>{const e=N("0 0 16 16");return e.appendChild(at(0,0,16,16,2.5,"#ff6600")),e.appendChild(M("M4.2 3.2h1.7l2.1 4.1 2.1-4.1h1.7L8.9 8.6V12.8H7.1V8.6L4.2 3.2z","#ffffff")),e},it=()=>{const e=N("0 0 16 16");e.appendChild(O(8,8,8,"#ff4500"));const t=document.createElementNS(I,"text");return t.setAttribute("x","8"),t.setAttribute("y","11.2"),t.setAttribute("text-anchor","middle"),t.setAttribute("fill","#ffffff"),t.setAttribute("font-size","7.5"),t.setAttribute("font-weight","700"),t.setAttribute("font-family","Verdana, Geneva, sans-serif"),t.textContent="r/",e.appendChild(t),e},lt=()=>{const e=N("0 0 16 16");return e.appendChild(O(8,8,8,"#0f1419")),e.appendChild(M("M4.1 4.1h2.05l1.7 2.35L10.05 4.1H12l-2.85 3.55L12.2 11.9h-2.05l-1.95-2.6-2.2 2.6H4l3.1-3.7L4.1 4.1z","#ffffff")),e},oe=e=>{switch(e){case"hackernews":return ot();case"reddit":return it();case"x":return lt()}},ie={hackernews:"HN",reddit:"Reddit",x:"X"},B=e=>{const t=new Set;for(const r of e)t.add(r.network);return["hackernews","reddit","x"].filter(r=>t.has(r))},le=e=>{const t=document.createElement("span");if(t.className="parle-stack",t.dataset.count=String(Math.max(e.length,1)),e.length===0){const r=document.createElement("span");return r.className="parle-stack-disc parle-stack-parle",r.appendChild(nt()),t.appendChild(r),t}for(const r of[...e].reverse()){const a=document.createElement("span");a.className=`parle-stack-disc parle-stack-${r}`,a.appendChild(oe(r)),t.appendChild(a)}return t},st=e=>{const t=document.createElement("span");return t.className=`parle-tab-mark parle-tab-mark-${e}`,t.appendChild(oe(e)),t},pt=()=>{const e=N("0 0 16 16");return e.appendChild(M("M8 1.2c.35 3.75 2.05 5.45 5.8 5.8-3.75.35-5.45 2.05-5.8 5.8C7.65 9.05 5.95 7.35 2.2 7 5.95 6.65 7.65 4.95 8 1.2z","currentColor")),e.appendChild(M("M13 10.4c.12 1.35.75 1.98 2.1 2.1-1.35.12-1.98.75-2.1 2.1-.12-1.35-.75-1.98-2.1-2.1 1.35-.12 1.98-.75 2.1-2.1z","currentColor")),e},dt=()=>{const e=N("0 0 16 16"),t=M("M6.4 1.8h3.2l.4 1.5 1.4-.5 1.6 1.6-.5 1.4 1.5.4v3.2l-1.5.4.5 1.4-1.6 1.6-1.4-.5-.4 1.5H6.4l-.4-1.5-1.4.5-1.6-1.6.5-1.4L1.8 9.6V6.4l1.5-.4-.5-1.4 1.6-1.6 1.4.5.4-1.5z");t.setAttribute("fill","none"),t.setAttribute("stroke","currentColor"),t.setAttribute("stroke-width","1.2"),t.setAttribute("stroke-linejoin","round"),e.appendChild(t);const r=O(8,8,2,"none");return r.setAttribute("stroke","currentColor"),r.setAttribute("stroke-width","1.2"),e.appendChild(r),e},ct=()=>{const e=N("0 0 16 16"),t=M("M6.2 3.2H3.8a1 1 0 0 0-1 1v8a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V9.8");t.setAttribute("fill","none"),t.setAttribute("stroke","currentColor"),t.setAttribute("stroke-width","1.3"),t.setAttribute("stroke-linecap","round"),t.setAttribute("stroke-linejoin","round"),e.appendChild(t);const r=M("M8.2 2.8h5v5M13.1 2.9 7.4 8.6");return r.setAttribute("fill","none"),r.setAttribute("stroke","currentColor"),r.setAttribute("stroke-width","1.3"),r.setAttribute("stroke-linecap","round"),r.setAttribute("stroke-linejoin","round"),e.appendChild(r),e},ut=()=>{const e=N("0 0 16 16"),t=M("M2.5 4h8M2.5 7h10.5M5.5 10h7.5M5.5 13h5");return t.setAttribute("fill","none"),t.setAttribute("stroke","currentColor"),t.setAttribute("stroke-width","1.3"),t.setAttribute("stroke-linecap","round"),e.appendChild(t),e},ht=()=>{const e=N("0 0 16 16");return e.appendChild(O(3.5,8,1,"currentColor")),e.appendChild(O(8,8,1,"currentColor")),e.appendChild(O(12.5,8,1,"currentColor")),e},K=e=>e.linked.length+e.passing.length,mt=e=>{try{const t=new URL(e);return t.protocol!=="http:"&&t.protocol!=="https:"?null:t.hostname.replace(/^www\./,"")}catch{return null}},ft=e=>e.length<=1?e[0]??"Nowhere":`${e.slice(0,-1).join(", ")} and ${e[e.length-1]}`,o=(e,t,r)=>{const a=document.createElement(e);return t!==""&&(a.className=t),r!==void 0&&(a.textContent=r),a},T=(e,t,r)=>{const a=o("button",e,t);return a.addEventListener("click",n=>{n.preventDefault(),r()}),a},X=(e,t,r,a)=>{const n=o("button",e);return n.type="button",n.setAttribute("aria-label",t),n.title=t,n.appendChild(r),n.addEventListener("click",s=>{s.preventDefault(),a()}),n},se=e=>e===1?"also submitted once":`also submitted ${e} times`,gt=8,vt=40,bt=3,F=new Set,R=new Set,xt=(e,t)=>`${e.key}\0${t.id}`,pe=(e,t,r)=>{const a=o("div","parle-comments"),n=l=>{l.appendChild(o("span","parle-comments-spacer")),l.appendChild(X("parle-comments-open","Open discussion",ct(),()=>t.openOut(e.permalink)));const c=o("span","parle-comments-menu-wrap"),h=o("span","parle-comments-menu");h.hidden=!0;const f=r===void 0?null:mt(r.address);if(f!==null&&r!==void 0){const L=r.restraint!==null&&r.restraint.kind==="site-paused";h.appendChild(T("parle-comments-menu-item",L?`Resume on ${f}`:`Pause on ${f}`,()=>L?t.resumeSite(f):t.pauseSite(f)))}h.appendChild(T("parle-comments-menu-item","What Parle sends",t.openDisclosure));const S=X("parle-comments-more-actions","More actions",ht(),()=>{h.hidden=!h.hidden,S.setAttribute("aria-expanded",h.hidden?"false":"true")});S.setAttribute("aria-haspopup","menu"),S.setAttribute("aria-expanded","false"),c.appendChild(S),c.appendChild(h),l.appendChild(c)},s=()=>{const l=o("div","parle-comments-tools");return n(l),l};if(e.comments===null&&e.commentCount===0)return a.appendChild(s()),a.appendChild(o("p","parle-comments-note","No comments yet.")),a;if(e.comments===null||e.comments._tag==="Reading")return a.appendChild(s()),a.appendChild(o("p","parle-comments-note","Loading comments\u2026")),a;if(e.comments._tag==="Unreadable")return a.appendChild(s()),a.appendChild(o("p","parle-comments-note","Could not read this one.")),a;const p=e.comments,d=new Map(p.comments.map(l=>[l.id,l])),u=new Map;for(const l of p.comments){const c=l.parentId!==null&&l.parentId!==l.id&&d.has(l.parentId)?l.parentId:null,h=u.get(c);h===void 0?u.set(c,[l]):h.push(l)}const v=l=>{let c=0;const h=[...u.get(l.id)??[]];for(;h.length>0;){const f=h.shift();f!==void 0&&(c+=1,h.push(...u.get(f.id)??[]))}return c},g=l=>e.network!=="x"||l.startsWith("@")?l:`@${l}`,m=(l,c,h=!0)=>{const f=o("article","parle-comment"),S=o("div","parle-comment-who",g(l.author));l.age!==""&&S.appendChild(o("span","parle-comment-age",l.age)),f.appendChild(S),f.appendChild(o("p","parle-comment-text",l.text));const L=u.get(l.id)??[];if(L.length===0||!h)return f;const $=v(l);if(c>=bt)return f.appendChild(T("parle-comment-more",`Continue ${$===1?"this reply":`these ${$} replies`} on the discussion`,()=>t.openOut(e.permalink))),f;const y=xt(e,l),A=R.has(y);if(f.appendChild(T("parle-comment-more",A?"Hide replies":`${$} ${$===1?"reply":"replies"}`,()=>{R.has(y)?R.delete(y):R.add(y),x()})),A){const D=o("div","parle-replies");for(const te of L)D.appendChild(m(te,c+1));f.appendChild(D)}return f},x=()=>{a.replaceChildren();const l=o("div","parle-comments-tools"),c=F.has(e.key),h=o("button","parle-comments-mode");if(h.type="button",h.setAttribute("aria-label",c?"Flat":"Nested"),h.appendChild(ut()),h.appendChild(o("span","",c?"Flat":"Nested")),h.appendChild(o("span","parle-comments-chevron","\u2304")),h.addEventListener("click",y=>{y.preventDefault(),F.has(e.key)?F.delete(e.key):F.add(e.key),x()}),h.setAttribute("aria-pressed",c?"false":"true"),l.appendChild(h),l.appendChild(T("parle-comments-collapse","Collapse all",()=>{for(const y of[...R])y.startsWith(`${e.key}\0`)&&R.delete(y);x()})),n(l),a.appendChild(l),c){const y=p.comments.slice(0,vt);for(const D of y)a.appendChild(m(D,0,!1));const A=Math.max(0,p.comments.length-y.length)+p.beyond;A>0&&a.appendChild(T("parle-comments-more",`Open ${A} more on the discussion`,()=>t.openOut(e.permalink)));return}const f=u.get(null)??[],S=f.slice(0,gt);for(const y of S)a.appendChild(m(y,0));const $=f.slice(S.length).reduce((y,A)=>y+1+v(A),0)+p.beyond;$>0&&a.appendChild(T("parle-comments-more",`Open ${$} more on the discussion`,()=>t.openOut(e.permalink)))};return x(),a},wt=e=>{switch(e.network){case"hackernews":return{score:`${e.score} points`,comments:`${e.commentCount} ${e.commentCount===1?"comment":"comments"}`};case"reddit":return{score:`${e.score} upvotes`,comments:`${e.commentCount} ${e.commentCount===1?"comment":"comments"}`};case"x":return{score:`${e.score} likes`,comments:`${e.commentCount} ${e.commentCount===1?"reply":"replies"}`}}},de=(e,t)=>{const r=o("div","parle-row-holder"),a=o("div","parle-row"),n=o("a","parle-title");n.textContent=e.title,n.href=e.permalink,n.target="_blank",n.rel="noreferrer noopener",n.addEventListener("click",u=>{u.preventDefault(),t.openOut(e.permalink)}),a.appendChild(n);const s=o("div","parle-facts"),p=wt(e);s.appendChild(o("span","parle-network",e.networkName)),s.appendChild(o("span","",p.score)),s.appendChild(o("span","",p.comments)),e.age!==""&&s.appendChild(o("span","",e.age)),e.alsoSubmitted>0&&s.appendChild(o("span","parle-repeat",se(e.alsoSubmitted))),a.appendChild(s),r.appendChild(a);const d=pe(e,t);return d!==null&&r.appendChild(d),r},kt=(e,t,r)=>{const a=o("div","parle-row-holder parle-home");a.dataset.network=e.network;const n=o("a","parle-room-title");n.textContent=e.title,n.href=e.permalink,n.target="_blank",n.rel="noreferrer noopener",n.addEventListener("click",p=>{p.preventDefault(),t.openOut(e.permalink)}),a.appendChild(n),e.alsoSubmitted>0&&a.appendChild(o("div","parle-repeat parle-room-repeat",se(e.alsoSubmitted)));const s=pe(e,t,r);return s!==null?a.appendChild(s):e.commentCount===0&&a.appendChild(o("p","parle-comments-note","No comments yet.")),a},Q=new Map,ce=new Map,ue=new Set,yt=e=>e.reduce((t,r)=>t+r.commentCount,0),Z=e=>[...e].sort((t,r)=>r.commentCount-t.commentCount)[0],Ct=(e,t,r,a,n,s)=>{const p=o("section","parle-group parle-group-linked parle-room");p.dataset.network=t,p.setAttribute("role","tabpanel");const d=r.filter(g=>g.network===t),u=Q.get(e),v=d.find(g=>g.key===u)??Z(d);if(v===void 0)return p.appendChild(o("p","parle-comments-note","Nothing here yet.")),p;if(d.length>1){const g=o("div","parle-thread-picks");g.setAttribute("role","tablist"),g.setAttribute("aria-label","Threads");for(const m of[...d].sort((x,l)=>l.commentCount-x.commentCount)){const x=o("button",m.key===v.key?"parle-thread-pick parle-thread-pick-on":"parle-thread-pick");x.type="button",x.setAttribute("role","tab"),x.setAttribute("aria-selected",m.key===v.key?"true":"false");const l=m.place!==null&&m.place!==""?`r/${m.place}`:m.title.length>28?`${m.title.slice(0,27)}\u2026`:m.title;x.textContent=l,x.title=m.title,x.addEventListener("click",()=>{Q.set(e,m.key),s()}),g.appendChild(x)}p.appendChild(g)}return p.appendChild(kt(v,n,a)),v.comments===null&&v.commentCount>0&&!ue.has(v.key)&&(ue.add(v.key),n.readDiscussion(v.key)),p},St=(e,t,r,a,n)=>{const s=o("nav","parle-nav");s.setAttribute("aria-label","Discussions");const p=o("div","parle-nav-strip");p.setAttribute("role","tablist");const d=o("button",r==="summary"?"parle-nav-item parle-nav-on":"parle-nav-item");d.type="button",d.dataset.dock="summary",d.setAttribute("role","tab"),d.setAttribute("aria-selected",r==="summary"?"true":"false"),d.setAttribute("aria-label","Digest"),d.title="Digest";const u=o("span","parle-nav-mark");u.appendChild(pt());const v=o("span","parle-nav-icon");v.appendChild(u),t.digest.findings.length===0&&v.appendChild(o("span","parle-nav-soon")),d.appendChild(v),d.addEventListener("click",()=>n("summary")),p.appendChild(d);for(const m of B(t.linked)){const x=t.linked.filter(f=>f.network===m),l=yt(x),c=o("button",r===m?"parle-nav-item parle-nav-on":"parle-nav-item");c.type="button",c.dataset.network=m,c.setAttribute("role","tab"),c.setAttribute("aria-selected",r===m?"true":"false"),c.setAttribute("aria-label",`${ie[m]}, ${l} ${l===1?"comment":"comments"}`),c.title=`${ie[m]} \xB7 ${l}`;const h=o("span","parle-nav-icon");if(h.appendChild(st(m)),l>0){const f=o("span","parle-nav-badge",l>999?"999+":String(l));f.setAttribute("aria-hidden","true"),h.appendChild(f)}c.appendChild(h),c.addEventListener("click",()=>{const f=Z(x);f!==void 0&&Q.set(e,f.key),n(m)}),p.appendChild(c)}s.appendChild(p);const g=o("div","parle-nav-utilities");return g.appendChild(X("parle-nav-item parle-nav-settings","Settings",dt(),a.openSettings)),s.appendChild(g),s},At=(e,t,r,a,n)=>{if(a.length===0)return null;const s=o("section",`parle-group parle-group-${e}`),p=o("h2","parle-group-name",`${t} `);p.appendChild(o("span","parle-group-note",r)),s.appendChild(p);for(const d of a)s.appendChild(de(d,n));return s},Et=(e,t)=>{const r=o("section","parle-folded");r.appendChild(o("p","parle-folded-says",e.says));const a=o("div","parle-folded-rows");a.hidden=!0;for(const s of e.rows)a.appendChild(de(s,t));const n=T("parle-act parle-act-folded",e.label,()=>{a.hidden=!1,n.remove()});return r.appendChild(n),r.appendChild(a),r},Lt=(e,t)=>{const r=o("a","parle-source");return r.href=e.permalink,r.target="_blank",r.rel="noreferrer noopener",r.addEventListener("click",a=>{a.preventDefault(),t.openOut(e.permalink)}),r.appendChild(o("span","parle-source-label",e.comment?`${e.label} \u2014 the comment`:e.label)),r},Nt=(e,t)=>{const r=o("div",e.contested?"parle-finding parle-finding-disputed":"parle-finding");e.contested&&r.appendChild(o("span","parle-disputed","Someone there disagreed")),r.appendChild(o("p","parle-finding-says",e.statement));const a=o("div","parle-sources");for(const n of e.sources)a.appendChild(Lt(n,t));return r.appendChild(a),r},Mt=(e,t)=>{if(e.says.text===""&&e.findings.length===0&&e.offer===null)return null;const r=o("section",`parle-digest parle-tone-${e.says.tone}`);e.says.text!==""&&r.appendChild(o("h2","parle-digest-title",e.says.text));for(const n of e.findings)r.appendChild(Nt(n,t));e.partial&&r.appendChild(o("p","parle-digest-partial","This is part of an answer \u2014 some of it could not be traced to a comment."));const a=e.offer;return a!==null&&(a.says!==""&&r.appendChild(o("p","parle-digest-says",a.says)),r.appendChild(T("parle-act parle-act-digest",a.label,a.kind==="connect"?t.openSettings:t.summarise))),e.wrote!==null&&r.appendChild(o("p","parle-digest-wrote",e.wrote)),r},he=e=>e.waitingOn.length===0?"Still looking.":`Still looking \u2014 ${e.waitingOn.join(", ")}`,Tt=e=>{const t=K(e);return t>0?`${t} discussion${t===1?"":"s"} on this page.`:e.stillLooking?he(e):e.folded!==null?e.folded.says:e.foundNothing?`Nobody has discussed this page. ${ft(e.answeredBy)} answered, with nothing.`:e.couldNotAsk?"Parle could not find out. Nowhere answered \u2014 which is not the same as nobody discussing it.":"Nothing has been asked about this page yet."},$t=(e,t)=>o("div",`${t} parle-tone-${e.tone}`,e.text),me=(e,t,r)=>{e.textContent="",e.className="parle parle-compact";const a=o("div","parle-body"),n=t.address,s=Z(t.linked),p=ce.get(n)??(s!==void 0?s.network:"summary"),d=o("div","parle-main"),u=o("div","parle-extras"),v=At("passing","Came up elsewhere","linked inside a conversation about something else",t.passing,r);if(v!==null&&u.appendChild(v),t.folded!==null&&u.appendChild(Et(t.folded,r)),t.windowed!==null&&u.appendChild($t(t.windowed,"parle-note")),K(t)===0&&t.folded===null)u.appendChild(o("p","parle-said",t.restraint===null?Tt(t):t.restraint.says));else if(t.stillLooking){const l=o("div","parle-notice parle-tone-waiting"),c=o("span","");c.appendChild(o("span","parle-spinner")),c.appendChild(document.createTextNode(he(t))),l.appendChild(c),u.appendChild(l)}const g=l=>{if(ce.set(n,l),d.replaceChildren(),l==="summary"){const c=Mt(t.digest,r);c!==null?d.appendChild(c):d.appendChild(o("p","parle-comments-note","A Digest of these discussions will live here."));return}t.linked.some(c=>c.network===l)&&d.appendChild(Ct(n,l,t.linked,t,r,()=>g(l)))},m=o("div","parle-nav-slot"),x=l=>{m.replaceChildren(St(n,t,l,r,c=>{g(c),x(c)}))};g(p),a.appendChild(d),a.appendChild(u),e.appendChild(a),e.appendChild(m),x(p)},_t=`
:host,
.parle, .parle-pill, .parle-dock {
  --parle-font: -apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif;
  --parle-t-meta: 11px;
  --parle-t-body: 13px;
  --parle-t-lead: 15px;
  --parle-t-head: 18px;
  --parle-1: 4px;
  --parle-2: 8px;
  --parle-3: 12px;
  --parle-4: 16px;
  --parle-5: 24px;
  --parle-r: 10px;
  --parle-r-sm: 6px;
  --parle-r-full: 999px;
  --parle-bg: #ffffff;
  --parle-raise: #f4f5f7;
  --parle-ink: #14161a;
  --parle-mid: #5b6270;
  --parle-faint: #6f7683;
  --parle-line: rgba(20, 22, 26, 0.1);
  --parle-rule: rgba(20, 22, 26, 0.2);
  --parle-accent: #1a6fdb;
  --parle-on-accent: #ffffff;
  --parle-warn: #7a5200;
  --parle-stop: #99291c;
  --parle-lift: 0 1px 2px rgba(10, 12, 16, 0.06), 0 10px 32px rgba(10, 12, 16, 0.14);
  --parle-motion: cubic-bezier(0.2, 0.75, 0.3, 1);
}
@media (prefers-color-scheme: dark) {
  :host,
  .parle, .parle-pill, .parle-dock {
    --parle-bg: #101216;
    --parle-raise: #191c22;
    --parle-ink: #e8eaef;
    --parle-mid: #a2a9b6;
    --parle-faint: #8b929f;
    --parle-line: rgba(232, 234, 239, 0.11);
    --parle-rule: rgba(232, 234, 239, 0.24);
    --parle-accent: #6eb0ff;
    --parle-on-accent: #0a1628;
    --parle-warn: #e0bd76;
    --parle-stop: #f0a396;
    --parle-lift: 0 1px 2px rgba(0, 0, 0, 0.4), 0 10px 32px rgba(0, 0, 0, 0.5);
  }
}

/* the phone scale */
@media (max-width: 639px) {
  :host,
  .parle, .parle-pill, .parle-dock {
    --parle-t-meta: 12px;
    --parle-t-body: 15px;
    --parle-t-lead: 17px;
  }
}

/* reset \u2014 nothing inherits from the page this is drawn on */
.parle, .parle-pill, .parle-dock {
  all: initial;
  color-scheme: light dark;
  font-family: var(--parle-font);
  font-size: var(--parle-t-body);
  line-height: 1.5;
  color: var(--parle-ink);
  -webkit-font-smoothing: antialiased;
  box-sizing: border-box;
}
.parle *, .parle *::before, .parle *::after,
.parle-pill *, .parle-pill::before, .parle-pill::after,
.parle-dock * { box-sizing: border-box; }
.parle a { color: inherit; text-decoration: none; }
.parle :focus-visible,
.parle-pill:focus-visible, .parle-close:focus-visible, .parle-pin:focus-visible {
  outline: 2px solid var(--parle-accent);
  outline-offset: 2px;
  border-radius: var(--parle-r-sm);
}

/* the panel */
.parle { display: flex; flex-direction: column; background: var(--parle-bg); }
.parle-head { flex: none; padding: var(--parle-4) var(--parle-4) var(--parle-2); }
.parle-heading {
  margin: 0 0 2px;
  font-size: var(--parle-t-lead);
  font-weight: 600;
  letter-spacing: -0.01em;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.parle-address {
  font-size: var(--parle-t-meta);
  color: var(--parle-faint);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.parle-body {
  padding: 0 var(--parle-3) var(--parle-3);
  max-height: 420px;
  overflow-y: auto;
  overscroll-behavior: contain;
}
.parle-compact { min-height: 0; }
.parle-compact .parle-body {
  padding: 10px 16px 8px;
  flex: 1 1 auto;
  min-height: 0;
  max-height: none;
}
.parle-dock .parle { flex: 1 1 auto; min-height: 0; }
.parle-dock .parle-body {
  max-height: none;
  flex: 1 1 auto;
  min-height: 0;
  /*
   * A thin scrollbar, and its gutter reserved whether or not it is showing.
   *
   * The dock is a fixed 320-420px column, and Chrome's classic scrollbar takes
   * about 15px of it. Without a stable gutter it appears only once the content
   * overflows, so the whole column shifts left the moment a discussion is long
   * enough \u2014 and the close button, which is positioned against the dock rather
   * than against the scrolling content, does not shift with it. The result is
   * the header's controls sitting flush to the panel edge while every line
   * beneath them stops 15px short, which is exactly the misalignment visible in
   * store screenshot 01.
   */
  scrollbar-width: thin;
  scrollbar-gutter: stable;
}
.parle-dock .parle-compact { height: 100%; }
.parle-main { min-width: 0; }
.parle-extras { margin-top: var(--parle-3); }

/* discussions \u2014 Linked room vs Passing list, never blended */
.parle-group { margin: var(--parle-4) 0 0; }
.parle-group:first-child { margin-top: 0; }
.parle-group-name {
  margin: 0 0 var(--parle-2);
  font-size: var(--parle-t-meta);
  letter-spacing: 0.07em;
  text-transform: uppercase;
  font-weight: 700;
  color: var(--parle-mid);
}
.parle-group-note {
  display: block;
  margin-top: 2px;
  font-size: var(--parle-t-meta);
  color: var(--parle-faint);
  font-weight: 400;
  text-transform: none;
  letter-spacing: 0;
}
.parle-group-linked .parle-group-name { color: var(--parle-accent); }
.parle-row {
  display: block;
  padding: var(--parle-2) var(--parle-3);
  margin: 0 0 var(--parle-1);
  border-radius: var(--parle-r-sm);
  background: var(--parle-raise);
  transition: background 160ms var(--parle-motion);
}
.parle-row:hover { background: var(--parle-line); }
.parle-group-passing .parle-row { box-shadow: inset 2px 0 0 var(--parle-rule); }
.parle-title { display: block; font-weight: 500; margin-bottom: 2px; }
.parle a:hover .parle-title { text-decoration: underline; }
.parle-facts {
  display: flex;
  gap: var(--parle-2);
  flex-wrap: wrap;
  font-size: var(--parle-t-meta);
  color: var(--parle-faint);
}
.parle-network { font-weight: 600; color: var(--parle-mid); }
.parle-repeat { font-style: italic; }

/*
 * Compact open room \u2014 comments first. Network identity lives on the bottom
 * nav icon; Parle's shell stays neutral. Subtle guides only.
 */
.parle-room { margin: 0; }
.parle-room-title {
  display: -webkit-box;
  margin: 0;
  padding: 2px 0 8px;
  overflow: hidden;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 2;
  color: var(--parle-ink);
  font-size: var(--parle-t-body);
  font-weight: 650;
  line-height: 1.35;
}
.parle-room-title:hover { text-decoration: underline; }
.parle-room-repeat {
  padding: 3px 0 5px;
  border-bottom: 1px solid var(--parle-line);
  color: var(--parle-faint);
  font-size: var(--parle-t-meta);
}
.parle-thread-picks {
  display: flex;
  gap: 6px;
  overflow-x: auto;
  margin: 0 0 8px;
  scrollbar-width: none;
}
.parle-thread-picks::-webkit-scrollbar { display: none; }
.parle-thread-pick {
  flex: none;
  max-width: 10em;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  border: 0;
  border-radius: 999px;
  padding: 4px 10px;
  background: var(--parle-raise);
  color: var(--parle-mid);
  font: 600 11px/1 var(--parle-font);
  cursor: pointer;
}
.parle-thread-pick-on {
  background: var(--parle-accent);
  color: var(--parle-on-accent);
}

.parle-home .parle-comments {
  margin: 0;
  padding: 0;
  border-left: 0;
}
.parle-home .parle-comment {
  margin: 0;
  padding: 9px 0;
  border-bottom: 1px solid var(--parle-line);
  border-left: 0;
}
.parle-home .parle-comment:last-child { border-bottom: 0; }
.parle-home .parle-replies {
  margin: 7px 0 0;
  padding: 0 0 0 12px;
  border-left: 1.5px solid var(--parle-line);
}
.parle-room[data-network="hackernews"] {
  --parle-guide: #ff6600;
}
.parle-room[data-network="reddit"] {
  --parle-guide: #ff4500;
}
.parle-room[data-network="x"] {
  --parle-guide: #536471;
}
.parle-room[data-network] .parle-replies {
  border-left-color: color-mix(in srgb, var(--parle-guide) 48%, transparent);
}
.parle-room[data-network] .parle-comment-who { color: var(--parle-guide); font-weight: 700; }
.parle-room[data-network="x"] .parle-comment {
  border-left: 0;
  padding-left: 0;
}
.parle-room[data-network="x"] .parle-comment-who {
  color: var(--parle-ink);
  font-weight: 800;
}

/*
 * Adaptive nav \u2014 ~32px icon row. Counts are iOS-style badges on the icon's
 * top-right and do not add layout height. Settings sits apart on the right.
 *
 * Bottom is the default because the default has to be right on touch devices,
 * including a wide iPad. A desktop page with a precise pointing device moves
 * it above the conversation.
 *
 * There used to be a third case: browser-owned side panels carried a
 * parle-native class, because a ~400px sidebar document is desktop chrome
 * rather than a phone and width alone misclassified it. Chrome no longer has
 * one \u2014 the side panel is gone and the in-page dock is the only surface \u2014 so
 * the class and its rules went with it. The dock IS the surface desktop Safari
 * has, which is why the clearance below is not optional.
 */
.parle-nav-slot { flex: none; }
.parle-nav {
  display: flex;
  align-items: center;
  gap: 4px;
  min-height: calc(34px + env(safe-area-inset-bottom, 0px));
  padding: 3px 12px calc(3px + env(safe-area-inset-bottom, 0px));
  border-top: 1px solid var(--parle-line);
  background: var(--parle-bg);
}
.parle-nav-strip {
  display: flex;
  align-items: center;
  gap: 4px;
  flex: 1 1 auto;
  min-width: 0;
  overflow-x: auto;
  scrollbar-width: none;
}
.parle-nav-strip::-webkit-scrollbar { display: none; }
.parle-nav-item {
  position: relative;
  flex: none;
  width: 40px;
  height: 27px;
  display: inline-grid;
  place-items: center;
  border: 0;
  border-radius: 8px;
  background: transparent;
  color: var(--parle-mid);
  cursor: pointer;
  padding: 0;
}
.parle-nav-item:hover { background: var(--parle-raise); color: var(--parle-ink); }
.parle-nav-on { color: var(--parle-accent); }
.parle-nav-on::after {
  content: "";
  position: absolute;
  left: 12px;
  right: 12px;
  bottom: 0;
  height: 2px;
  border-radius: 999px;
  background: var(--parle-accent);
}
.parle-nav-icon {
  position: relative;
  display: inline-grid;
  place-items: center;
  width: 20px;
  height: 20px;
  overflow: visible;
}
.parle-nav-mark,
.parle-tab-mark {
  display: inline-grid;
  place-items: center;
  width: 20px;
  height: 20px;
  border-radius: 4px;
  overflow: hidden;
  color: inherit;
}
.parle-nav-mark svg,
.parle-tab-mark svg { display: block; width: 20px; height: 20px; }
.parle-nav-badge {
  position: absolute;
  top: -5px;
  right: -9px;
  z-index: 1;
  min-width: 12px;
  height: 12px;
  padding: 0 2.5px;
  border-radius: 999px;
  background: #ff3b30;
  color: #ffffff;
  font: 700 8px/12px var(--parle-font);
  font-variant-numeric: tabular-nums;
  text-align: center;
  box-shadow: 0 0 0 1.5px var(--parle-bg);
  pointer-events: none;
}
.parle-nav-soon {
  position: absolute;
  top: -3px;
  right: -4px;
  width: 6px;
  height: 6px;
  border-radius: 999px;
  background: var(--parle-accent);
  box-shadow: 0 0 0 1.5px var(--parle-bg);
  pointer-events: none;
}
.parle-nav-utilities {
  display: flex;
  align-items: center;
  flex: none;
  margin-left: 4px;
  padding-left: 5px;
  box-shadow: -1px 0 0 var(--parle-line);
}
.parle-nav-settings { width: 32px; color: var(--parle-mid); }
.parle-nav-settings svg { display: block; width: 16px; height: 16px; }
.parle-nav-settings::after { display: none; }

@media (min-width: 640px) and (hover: hover) and (pointer: fine) {
  .parle-compact .parle-nav-slot { order: -1; }
  .parle-compact .parle-nav {
    min-height: var(--parle-nav-h, 34px);
    padding: 3px 12px;
    border-top: 0;
    border-bottom: 1px solid var(--parle-line);
  }
  /*
   * Only inside this query does the navigation sit at the top, so only here can
   * the close button be centred on it. Outside it \u2014 touch, coarse pointer, a
   * narrow window \u2014 the row is the footer at the bottom of the column, and a
   * button positioned against the top of the dock has nothing to align with.
   * Coupling the two unconditionally made the alignment a property of the
   * viewport rather than of the stylesheet: measured on a non-matching display,
   * the same build gave close 1..33 against nav 766..800.
   */
  .parle-dock .parle-close,
  .parle-dock .parle-pin {
    top: calc(
      env(safe-area-inset-top, 0px) + (var(--parle-nav-h) - var(--parle-close-size)) / 2
    );
  }

  /*
   * The in-page dock owns an absolute close button in this corner, and the
   * clearance is derived from where that button actually is rather than from a
   * number that happened to work. When the close button moved left to clear the
   * scroll gutter, a fixed 48px left Settings overlapping it by 2px \u2014 caught by
   * the e2e box assertion, which is why that assertion exists.
   */
  .parle-dock .parle-compact .parle-nav {
    /* Two positioned buttons to clear now \u2014 the pin sits one slot left of the
       close, so the clearance is a close-width and a gap wider than it was. */
    padding-right: calc(86px + var(--parle-scroll-gutter, 0px));
  }
}

/* A Discussion's own words. */
.parle-open {
  border: 0; background: transparent; cursor: pointer; font: inherit;
  color: var(--parle-accent); padding: 0; text-decoration: underline;
}
.parle-comments {
  margin: var(--parle-1) 0 var(--parle-2) var(--parle-2);
  padding-left: var(--parle-2);
  border-left: 2px solid var(--parle-line);
}
.parle-comments-tools {
  display: flex; align-items: center; gap: var(--parle-3);
  min-height: 32px;
  margin-bottom: 0;
  border-bottom: 1px solid var(--parle-line);
}
.parle-comments-mode, .parle-comments-collapse, .parle-comment-more, .parle-comments-more,
.parle-comments-open {
  border: 0; background: transparent; cursor: pointer; font: inherit;
  color: var(--parle-accent); padding: 0; text-decoration: none;
  font-size: var(--parle-t-meta); font-weight: 600;
}
.parle-comments-mode {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  flex: none;
  color: var(--parle-ink);
}
.parle-comments-mode svg { display: block; width: 15px; height: 15px; color: var(--parle-mid); }
.parle-comments-chevron { color: var(--parle-faint); font-size: 10px; transform: translateY(-1px); }
.parle-comments-collapse { color: var(--parle-accent); font-weight: 500; }
.parle-comments-collapse:hover { color: var(--parle-ink); }
.parle-comments-spacer { flex: 1 1 auto; }
.parle-comments-open,
.parle-comments-more-actions {
  display: inline-grid;
  place-items: center;
  width: 24px;
  height: 24px;
  color: var(--parle-mid);
}
.parle-comments-open:hover,
.parle-comments-more-actions:hover { color: var(--parle-ink); }
.parle-comments-open svg,
.parle-comments-more-actions svg { display: block; width: 14px; height: 14px; }
.parle-comments-menu-wrap { position: relative; display: inline-grid; }
.parle-comments-menu {
  position: absolute;
  z-index: 2;
  top: 26px;
  right: 0;
  min-width: 150px;
  padding: 4px;
  border: 1px solid var(--parle-line);
  border-radius: 8px;
  background: var(--parle-bg);
  box-shadow: var(--parle-lift);
}
.parle-comments-menu[hidden] { display: none; }
.parle-comments-menu-item {
  display: block;
  width: 100%;
  border: 0;
  border-radius: 5px;
  padding: 6px 8px;
  background: transparent;
  color: var(--parle-ink);
  font: 500 var(--parle-t-meta)/1.3 var(--parle-font);
  text-align: left;
  cursor: pointer;
}
.parle-comments-menu-item:hover { background: var(--parle-raise); }
.parle-comments-more { margin: var(--parle-1) 0 var(--parle-2); text-decoration: underline; }
.parle-comment { margin-bottom: var(--parle-2); min-width: 0; }
.parle-comment-who { color: var(--parle-mid); font-size: var(--parle-t-meta); }
.parle-comment-age { margin-left: var(--parle-1); color: var(--parle-faint); font-weight: 400; }
.parle-comment-text {
  margin: 2px 0 0; white-space: pre-wrap; overflow-wrap: anywhere;
  line-height: 1.45;
}
.parle-comment-more {
  display: inline-flex;
  align-items: center;
  gap: 3px;
  min-height: 22px;
  margin-top: 2px;
  font-size: var(--parle-t-meta);
  color: var(--parle-mid);
}
.parle-comment-more::before {
  content: "\u203A";
  font-size: 14px;
  line-height: 1;
  color: var(--parle-guide, var(--parle-faint));
}
.parle-replies {
  margin: var(--parle-2) 0 0 var(--parle-2);
  padding-left: var(--parle-2);
  border-left: 2px solid var(--parle-line);
}
.parle-comments-note { color: var(--parle-mid); font-size: var(--parle-t-meta); margin: 0; }

/* a site's front door: what was set aside, and the one click that opens it.
   Quiet rather than warning-coloured \u2014 nothing has gone wrong here, and the
   product's own rule is that a suppression must read as a decision the reader
   can reverse rather than as an error they have to interpret. */
.parle-folded {
  margin: var(--parle-3) 0 0;
  padding: var(--parle-3);
  border-radius: var(--parle-r-sm);
  background: var(--parle-raise);
}
.parle-folded-says {
  margin: 0 0 var(--parle-2);
  font-size: var(--parle-t-meta);
  color: var(--parle-mid);
}
.parle-act-folded { font-size: var(--parle-t-meta); padding: var(--parle-1) var(--parle-3); }
.parle-folded-rows { margin-top: var(--parle-2); }
.parle-folded-rows .parle-row { background: var(--parle-bg); }

/* tones \u2014 six states, six inks, no washes (ADR 0011) */
.parle-tone-refused { color: var(--parle-stop); }
.parle-tone-garbled { color: var(--parle-warn); }
.parle-tone-withheld, .parle-tone-waiting, .parle-tone-quiet { color: var(--parle-mid); }
.parle-tone-found { color: var(--parle-accent); }
.parle-notice {
  display: flex;
  justify-content: space-between;
  gap: var(--parle-2);
  margin: var(--parle-2) 0 0;
  padding: var(--parle-2) var(--parle-3);
  border-radius: var(--parle-r-sm);
  background: var(--parle-raise);
  font-size: var(--parle-t-meta);
}
.parle-said { margin: var(--parle-3) 0; color: var(--parle-mid); }
.parle-restraint { margin: var(--parle-3) 0 var(--parle-4); color: var(--parle-mid); }
.parle-restraint-says { margin: 0 0 var(--parle-3); color: var(--parle-ink); }

/* actions \u2014 outlined, so a button is a button on whatever it sits on */
.parle-act {
  all: unset;
  display: inline-block;
  cursor: pointer;
  font-family: var(--parle-font);
  font-size: var(--parle-t-body);
  font-weight: 550;
  padding: var(--parle-2) var(--parle-4);
  border-radius: var(--parle-r-full);
  color: var(--parle-ink);
  background: var(--parle-bg);
  box-shadow: inset 0 0 0 1px var(--parle-rule);
  transition: background 160ms var(--parle-motion), opacity 160ms var(--parle-motion);
}
.parle-act:hover { background: var(--parle-raise); }
.parle-act-strong {
  background: var(--parle-accent);
  color: var(--parle-on-accent);
  box-shadow: none;
}
.parle-act-strong:hover { background: var(--parle-accent); opacity: 0.88; }
.parle-link {
  all: unset;
  cursor: pointer;
  font-family: var(--parle-font);
  font-size: var(--parle-t-meta);
  color: var(--parle-mid);
  transition: color 160ms var(--parle-motion);
}
.parle-link:hover { color: var(--parle-ink); text-decoration: underline; }
.parle-note { margin: var(--parle-4) 0 0; font-size: var(--parle-t-meta); color: var(--parle-mid); }
/* the footer \u2014 rows declared, never wrapped into */
.parle-footer {
  flex: none;
  display: flex;
  flex-direction: column;
  gap: var(--parle-2);
  border-top: 1px solid var(--parle-line);
  padding: var(--parle-3) var(--parle-4);
  font-size: var(--parle-t-meta);
  color: var(--parle-faint);
}
.parle-footer-row {
  display: flex;
  align-items: center;
  gap: var(--parle-3);
  flex-wrap: wrap;
}
.parle-footer-state { margin-right: auto; color: var(--parle-mid); }

/* the account of every place we asked \u2014 the toolbar surface's whole job */
.parle-coverage { margin: var(--parle-4) 0 0; }
.parle-coverage-name {
  margin: 0 0 var(--parle-1);
  font-size: var(--parle-t-meta);
  letter-spacing: 0.07em;
  text-transform: uppercase;
  font-weight: 700;
  color: var(--parle-faint);
}
.parle-account {
  display: flex;
  justify-content: space-between;
  gap: var(--parle-3);
  padding: var(--parle-1) 0;
  font-size: var(--parle-t-meta);
  color: var(--parle-mid);
}
.parle-account-place { color: var(--parle-mid); }
.parle-account-waiting { color: var(--parle-faint); }
.parle-account-refused { color: var(--parle-stop); }
.parle-account-garbled { color: var(--parle-warn); }
.parle-account-found { color: var(--parle-accent); }

/* digest */
.parle-digest {
  margin: var(--parle-4) 0 0;
  padding: var(--parle-3);
  border-radius: var(--parle-r);
  background: var(--parle-raise);
  color: var(--parle-mid);
}
.parle-compact .parle-digest { margin-top: 0; }
.parle-digest-title { margin: 0 0 var(--parle-2); font-size: var(--parle-t-body); font-weight: 600; color: var(--parle-ink); }
.parle-digest-says { margin: 0 0 var(--parle-2); }
.parle-digest-partial { margin: var(--parle-2) 0 0; font-size: var(--parle-t-meta); }
.parle-digest-wrote { margin: var(--parle-2) 0 0; font-size: var(--parle-t-meta); color: var(--parle-faint); }
.parle-act-digest { margin-top: var(--parle-1); }
.parle-finding { margin: 0 0 var(--parle-3); }
.parle-finding:last-of-type { margin-bottom: 0; }
.parle-finding-says { margin: 0 0 var(--parle-1); color: var(--parle-ink); }
/* disputed: the neutral ink, never the accent and never a warning (ADR 0006) */
.parle-finding-disputed { box-shadow: inset 2px 0 0 var(--parle-rule); padding-left: var(--parle-3); }
.parle-disputed {
  display: block;
  margin-bottom: 2px;
  font-size: var(--parle-t-meta);
  text-transform: uppercase;
  letter-spacing: 0.05em;
  color: var(--parle-faint);
}
/* citations: underlined always, because they are meant to be followed (ADR 0006) */
.parle-sources { display: flex; flex-wrap: wrap; gap: var(--parle-1) var(--parle-3); }
.parle a.parle-source {
  font-size: var(--parle-t-meta);
  color: var(--parle-mid);
  text-decoration: underline;
  text-underline-offset: 2px;
  text-decoration-thickness: 1px;
  cursor: pointer;
}
.parle a.parle-source:hover { color: var(--parle-ink); }
.parle-spinner {
  display: inline-block;
  width: 6px;
  height: 6px;
  border-radius: var(--parle-r-full);
  background: currentColor;
  margin-right: var(--parle-2);
  vertical-align: middle;
  animation: parle-pulse 1.4s var(--parle-motion) infinite;
}
@keyframes parle-pulse { 0%, 100% { opacity: 0.25; } 50% { opacity: 1; } }

/* the mark \u2014 parked by the reader, only when there is something, still after it arrives */
.parle-pill {
  position: fixed;
  top: var(--parle-4);
  left: auto;
  right: var(--parle-4);
  z-index: 2147483646;
  display: grid;
  place-items: center;
  min-width: 36px;
  height: 36px;
  padding: 4px;
  border: 0;
  border-radius: var(--parle-r-full);
  background: var(--parle-bg);
  color: var(--parle-ink);
  box-shadow: var(--parle-lift), inset 0 0 0 1px var(--parle-line);
  cursor: grab;
  touch-action: none;
  user-select: none;
  font-family: var(--parle-font);
  font-size: var(--parle-t-meta);
  font-weight: 650;
  transition: transform 160ms var(--parle-motion), box-shadow 160ms var(--parle-motion);
  animation: parle-arrive 420ms var(--parle-motion) both;
}
.parle-pill:hover { transform: scale(1.05); }
.parle-pill[data-dragging="1"] {
  cursor: grabbing;
  transform: scale(1.08);
  box-shadow: var(--parle-lift), inset 0 0 0 1px var(--parle-accent);
  transition: none;
}
.parle-pill[hidden], .parle-pill[data-found="0"] { display: none; }
.parle-pill svg, .parle-close svg { display: block; width: 16px; height: 16px; }
.parle-pill svg:not([fill]), .parle-close svg:not([fill]) { fill: currentColor; }
.parle-stack {
  display: flex;
  flex-direction: row;
  align-items: center;
}
.parle-stack-disc {
  display: grid;
  place-items: center;
  width: 28px;
  height: 28px;
  border-radius: var(--parle-r-full);
  background: var(--parle-bg);
  box-shadow: 0 0 0 2px var(--parle-bg);
  overflow: hidden;
}
.parle-stack-disc + .parle-stack-disc { margin-left: -10px; }
.parle-stack-disc svg { width: 28px; height: 28px; }
.parle-stack-parle {
  color: var(--parle-ink);
  background: var(--parle-raise);
}
.parle-stack-parle svg { width: 16px; height: 16px; }
.parle-pill-count {
  position: absolute;
  top: -4px;
  right: -4px;
  min-width: 18px;
  height: 18px;
  padding: 0 5px;
  border-radius: var(--parle-r-full);
  background: var(--parle-accent);
  color: var(--parle-on-accent);
  font-size: 10px;
  font-weight: 700;
  line-height: 18px;
  text-align: center;
  box-shadow: 0 0 0 2px var(--parle-bg);
}
.parle-pill-count:empty { display: none; }
/* the announcement: one ring, outward, once */
.parle-pill::after {
  content: "";
  position: absolute;
  inset: -2px;
  border-radius: var(--parle-r-full);
  border: 2px solid var(--parle-accent);
  pointer-events: none;
  animation: parle-ring 1100ms var(--parle-motion) 1 both;
}
@keyframes parle-arrive {
  from { opacity: 0; transform: translateY(-6px) scale(0.8); }
  to { opacity: 1; transform: none; }
}
@keyframes parle-ring {
  from { opacity: 0.55; transform: scale(1); }
  to { opacity: 0; transform: scale(2.1); }
}

/* the surface \u2014 full screen under 640px, docked right at and above it */
.parle-dock {
  --parle-scroll-gutter: 10px;
  --parle-nav-h: 34px;
  --parle-close-size: 32px;
  position: fixed;
  inset: 0;
  z-index: 2147483647;
  display: flex;
  flex-direction: column;
  background: var(--parle-bg);
  box-shadow: var(--parle-lift);
  overscroll-behavior: contain;
  padding-top: env(safe-area-inset-top, 0px);
  padding-bottom: env(safe-area-inset-bottom, 0px);
  animation: parle-open 180ms var(--parle-motion) both;
}
@keyframes parle-open { from { opacity: 0; } to { opacity: 1; } }
@media (min-width: 640px) {
  .parle-dock { inset: 0 0 0 auto; width: clamp(320px, 30vw, 420px); padding-bottom: 0; }
}
/* the way out of the surface, drawn as a button */
.parle-close {
  all: unset;
  position: absolute;
  /*
   * The default: a plain offset from the top of the dock.
   *
   * This button is a child of .parle-dock, not of the row it appears to sit
   * beside, so it is positioned rather than laid out \u2014 and the row it appears
   * to sit beside is not always there. Navigation is only the header inside the
   * pointer-driven desktop query below; on touch and coarse-pointer surfaces it
   * is the footer at the bottom of the column, and a button aligned to it would
   * be aligned to nothing. Centring on the row therefore lives inside that
   * query, not here.
   */
  top: calc(env(safe-area-inset-top, 0px) + var(--parle-2));
  /* Clears the scroll gutter below it so the panel has one right edge. */
  right: calc(var(--parle-2) + var(--parle-scroll-gutter, 0px));
  z-index: 1;
  display: grid;
  place-items: center;
  width: var(--parle-close-size);
  height: var(--parle-close-size);
  border-radius: var(--parle-r-full);
  background: var(--parle-raise);
  cursor: pointer;
  font-family: var(--parle-font);
  font-size: var(--parle-t-head);
  line-height: 1;
  color: var(--parle-mid);
  transition: background 160ms var(--parle-motion), color 160ms var(--parle-motion);
}
.parle-close:hover { background: var(--parle-line); color: var(--parle-ink); }
/*
 * The pin: the close button's twin, one slot to its left. It shares the close
 * button's positioning story completely \u2014 a child of the dock, positioned
 * rather than laid out, centred on the navigation row only inside the query
 * that makes that row the header \u2014 so every rule below mirrors .parle-close
 * with one more button-width of right offset.
 */
.parle-pin {
  all: unset;
  position: absolute;
  top: calc(env(safe-area-inset-top, 0px) + var(--parle-2));
  right: calc(var(--parle-2) + var(--parle-scroll-gutter, 0px) + var(--parle-close-size) + 6px);
  z-index: 1;
  display: grid;
  place-items: center;
  width: var(--parle-close-size);
  height: var(--parle-close-size);
  border-radius: var(--parle-r-full);
  background: var(--parle-raise);
  cursor: pointer;
  color: var(--parle-mid);
  transition: background 160ms var(--parle-motion), color 160ms var(--parle-motion);
}
.parle-pin:hover { background: var(--parle-line); color: var(--parle-ink); }
.parle-pin[aria-pressed="true"] { background: var(--parle-line); color: var(--parle-accent); }
.parle-pin svg { display: block; width: 15px; height: 15px; }
.parle-pin svg:not([fill]) { fill: currentColor; }
/* Two positioned controls to clear now \u2014 the pin sits one slot left of close. */
.parle-dock .parle-head { padding-right: 90px; }
@media (max-width: 639px) {
  /* The surface is the whole screen here \u2014 there is no page beside it to pin. */
  .parle-pin { display: none; }
  .parle-close {
    top: calc(env(safe-area-inset-top, 0px) + var(--parle-3));
    right: var(--parle-3);
    width: 40px;
    height: 40px;
  }
  .parle-dock .parle-head { padding-right: 64px; padding-top: var(--parle-5); }
  .parle-dock .parle-heading {
    white-space: normal;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
  }
}

@media (prefers-reduced-motion: reduce) {
  .parle, .parle *,
  .parle-pill, .parle-pill::after,
  .parle-dock, .parle-close, .parle-pin { animation: none !important; transition: none !important; }
  .parle-pill::after { opacity: 0; }
}
`,fe="__parle_pill_mounted__",G=36,zt=5,J=()=>({width:document.documentElement.clientWidth,height:document.documentElement.clientHeight}),ge=e=>{if("showPopover"in e)try{e.setAttribute("popover","manual"),e.showPopover()}catch{e.removeAttribute("popover")}},Pt=e=>`${e} discussion${e===1?"":"s"}`,Ot={matches:["http://*/*","https://*/*"],registration:"runtime",runAt:"document_idle",allFrames:!1,main:()=>{const e=window;if(e[fe]===!0)return;e[fe]=!0;let t=null,r=Te,a=null,n=null,s=null,p=null,d=null,u=null,v=null,g=!1,m=null;const x=640,l=()=>{if(window.innerWidth<x){c();return}if(u===null||!g)return;const i=u.getBoundingClientRect().width;i===0||i>=window.innerWidth||(m===null&&(m=document.documentElement.style.marginRight),document.documentElement.style.setProperty("margin-right",`${i}px`,"important"))},c=()=>{m!==null&&(m===""?document.documentElement.style.removeProperty("margin-right"):document.documentElement.style.marginRight=m,m=null)},h=()=>{if(s===null)return;const{left:i,top:b}=ze(r,G,J());s.style.left=`${i}px`,s.style.top=`${b}px`,s.style.right="auto"},f=i=>{let b=0,w=0,k=0,z=0,_=!1,H=!1;const Le=E=>{const P=E.clientX-b,Y=E.clientY-w;if(!_){if(Math.hypot(P,Y)<zt)return;_=!0,H=!0,i.dataset.dragging="1",i.setPointerCapture(E.pointerId)}const Ne=J(),Ut=Math.max(16,Ne.width-G-16),Vt=Math.max(16,Ne.height-G-16),Ht=Math.min(Ut,Math.max(16,k+P)),qt=Math.min(Vt,Math.max(16,z+Y));i.style.left=`${Ht}px`,i.style.top=`${qt}px`,i.style.right="auto"},q=E=>{if(window.removeEventListener("pointermove",Le,!0),window.removeEventListener("pointerup",q,!0),window.removeEventListener("pointercancel",q,!0),_){i.dataset.dragging="0";try{i.releasePointerCapture(E.pointerId)}catch{}const P=Number.parseFloat(i.style.left||"0"),Y=Number.parseFloat(i.style.top||"0");r=Pe(P,Y,G,J()),h(),C.say(je(r))}_=!1};i.addEventListener("pointerdown",E=>{if(E.button!==0)return;b=E.clientX,w=E.clientY;const P=i.getBoundingClientRect();k=P.left,z=P.top,H=!1,_=!1,window.addEventListener("pointermove",Le,!0),window.addEventListener("pointerup",q,!0),window.addEventListener("pointercancel",q,!0)}),i.addEventListener("click",E=>{if(H){E.preventDefault(),E.stopPropagation(),H=!1;return}$()})},S=()=>{if(a!==null)return;const i=document.createElement("div");i.style.setProperty("all","initial");const b=i.attachShadow({mode:"closed"}),w=document.createElement("style");w.textContent=_t,b.appendChild(w);const k=document.createElement("button");k.className="parle-pill",k.type="button";const z=le([]);k.appendChild(z);const _=document.createElement("span");_.className="parle-pill-count",k.appendChild(_),f(k),b.appendChild(k),document.documentElement.appendChild(i),ge(k),a=i,n=b,s=k,p=_,d=z,h()},L=()=>{a!==null&&(c(),g=!1,a.remove(),a=null,n=null,s=null,p=null,d=null,u=null,v=null)},$=()=>{u===null?y():A()},y=()=>{if(n===null||u!==null||t===null)return;const i=document.createElement("div");i.className="parle-dock",i.setAttribute("role","dialog"),i.setAttribute("aria-label","Parle");const b=document.createElement("button");b.className="parle-close",b.type="button",b.setAttribute("aria-label","Close"),b.textContent="\xD7",b.addEventListener("click",A),i.appendChild(b);const w=document.createElement("button");w.className="parle-pin",w.type="button",w.setAttribute("aria-label",g?"Unpin":"Pin beside the page"),w.setAttribute("aria-pressed",g?"true":"false"),w.innerHTML='<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M9.5 1.5 14.5 6.5 13 8l-.7-.2-2.6 2.6.3 2.1-1.2 1.2-3-3-3.6 3.6-1-1 3.6-3.6-3-3L3 5.5l2.1.3 2.6-2.6L7.5 2.5z"/></svg>',w.addEventListener("click",()=>{g=!g,w.setAttribute("aria-pressed",g?"true":"false"),w.setAttribute("aria-label",g?"Unpin":"Pin beside the page"),g?l():c()}),i.appendChild(w);const k=document.createElement("div");k.className="parle",i.appendChild(k),n.appendChild(i),ge(i),u=i,v=k,l(),me(k,t,be),b.focus({preventScroll:!0})},A=()=>{u!==null&&(c(),u.remove(),u=null,v=null,s?.focus({preventScroll:!0}))},D=i=>{if(s===null)return;const b=B([...i.linked,...i.passing]),w=le(b);d!==null?d.replaceWith(w):s.insertBefore(w,p),d=w},te=()=>{if(t===null)return;const i=K(t);if(i===0){L();return}if(S(),D(t),h(),p!==null&&(p.textContent=String(Math.min(i,99))),s!==null){s.dataset.found=String(i);const b=B([...t.linked,...t.passing]),w=b.length===0?"":` on ${b.map(z=>z==="hackernews"?"Hacker News":z==="reddit"?"Reddit":"X").join(" \xB7 ")}`,k=`Parle \u2014 ${Pt(i)}${w}`;s.setAttribute("aria-label",k),s.title=`${k}. Drag to move.`}v!==null&&me(v,t,be)},C=et(Oe,i=>{i._tag==="Standing"&&(t=i.panel,r=i.markPark,te())}),be={openOut:i=>C.say(Ie(i)),lookAnyway:()=>C.say(We()),summarise:()=>C.say(Fe()),readDiscussion:i=>C.say(Ge(i)),decide:i=>C.say(Ue(i)),openDisclosure:()=>C.say(Ve()),openSettings:()=>C.say(Ye()),pauseSite:i=>C.say(He(i)),resumeSite:i=>C.say(qe(i))},xe=i=>{u===null||i.key!=="Escape"||(i.stopPropagation(),A())};window.addEventListener("keydown",xe,!0);const we=i=>{u===null||g||a===null||i.button===0&&(i.composedPath().includes(a)||A())};window.addEventListener("pointerdown",we,!0);const ke=()=>{h(),g&&u!==null&&l()};window.addEventListener("resize",ke),C.say(Re(null),!0);const ye=()=>{C.say(De(location.href,document.title,document.referrer),!0)};ye();const Ce=i=>{const b=i.indexOf("#");return b===-1?i:i.slice(0,b)};let Se=Ce(location.href);const re=()=>{const i=Ce(location.href);i!==Se&&(Se=i,L(),ye())};window.addEventListener("popstate",re),window.addEventListener("hashchange",re);const Ae=new MutationObserver(re),Ee=document.querySelector("title");Ee!==null&&Ae.observe(Ee,{childList:!0});const Gt=rt(()=>{});window.addEventListener("pagehide",()=>{Gt(),Ae.disconnect(),window.removeEventListener("keydown",xe,!0),window.removeEventListener("pointerdown",we,!0),window.removeEventListener("resize",ke),L(),C.close()})}};function U(e,...t){}const Rt={debug:(...e)=>U(console.debug,...e),log:(...e)=>U(console.log,...e),warn:(...e)=>U(console.warn,...e),error:(...e)=>U(console.error,...e)};var ve=class Me extends Event{static EVENT_NAME=ee("wxt:locationchange");constructor(t,r){super(Me.EVENT_NAME,{}),this.newUrl=t,this.oldUrl=r}};function ee(e){return`${j?.runtime?.id}:pill:${e}`}const Dt=typeof globalThis.navigation?.addEventListener=="function";function It(e){let t,r=!1;return{run(){r||(r=!0,t=new URL(location.href),Dt?globalThis.navigation.addEventListener("navigate",a=>{const n=new URL(a.destination.url);n.href!==t.href&&(window.dispatchEvent(new ve(n,t)),t=n)},{signal:e.signal}):e.setInterval(()=>{const a=new URL(location.href);a.href!==t.href&&(window.dispatchEvent(new ve(a,t)),t=a)},1e3))}}}var Wt=class W{static SCRIPT_STARTED_MESSAGE_TYPE=ee("wxt:content-script-started");id;abortController;locationWatcher=It(this);constructor(t,r){this.contentScriptName=t,this.options=r,this.id=Math.random().toString(36).slice(2),this.abortController=new AbortController,this.stopOldScripts(),this.listenForNewerScripts()}get signal(){return this.abortController.signal}abort(t){return this.abortController.abort(t)}get isInvalid(){return j.runtime?.id==null&&this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(t){return this.signal.addEventListener("abort",t),()=>this.signal.removeEventListener("abort",t)}block(){return new Promise(()=>{})}setInterval(t,r){const a=setInterval(()=>{this.isValid&&t()},r);return this.onInvalidated(()=>clearInterval(a)),a}setTimeout(t,r){const a=setTimeout(()=>{this.isValid&&t()},r);return this.onInvalidated(()=>clearTimeout(a)),a}requestAnimationFrame(t){const r=requestAnimationFrame((...a)=>{this.isValid&&t(...a)});return this.onInvalidated(()=>cancelAnimationFrame(r)),r}requestIdleCallback(t,r){const a=requestIdleCallback((...n)=>{this.signal.aborted||t(...n)},r);return this.onInvalidated(()=>cancelIdleCallback(a)),a}addEventListener(t,r,a,n){r==="wxt:locationchange"&&this.isValid&&this.locationWatcher.run(),t.addEventListener?.(r.startsWith("wxt:")?ee(r):r,a,{...n,signal:this.signal})}notifyInvalidated(){this.abort("Content script context invalidated"),Rt.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){document.dispatchEvent(new CustomEvent(W.SCRIPT_STARTED_MESSAGE_TYPE,{detail:{contentScriptName:this.contentScriptName,messageId:this.id}})),this.options?.noScriptStartedPostMessage||window.postMessage({type:W.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:this.id},"*")}verifyScriptStartedEvent(t){const r=t.detail?.contentScriptName===this.contentScriptName,a=t.detail?.messageId===this.id;return r&&!a}listenForNewerScripts(){const t=r=>{!(r instanceof CustomEvent)||!this.verifyScriptStartedEvent(r)||this.notifyInvalidated()};document.addEventListener(W.SCRIPT_STARTED_MESSAGE_TYPE,t),this.onInvalidated(()=>document.removeEventListener(W.SCRIPT_STARTED_MESSAGE_TYPE,t))}};function Kt(){}function V(e,...t){}const Ft={debug:(...e)=>V(console.debug,...e),log:(...e)=>V(console.log,...e),warn:(...e)=>V(console.warn,...e),error:(...e)=>V(console.error,...e)};return(async()=>{try{const{main:e,...t}=Ot;return await e(new Wt("pill",t))}catch(e){throw Ft.error('The content script "pill" crashed on startup!',e),e}})()})();
