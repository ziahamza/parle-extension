import{l as ae}from"./Surface-CTSQbe9n.js";import{bc as M,dd as O,de as te,df as re,aA as oe,co as K,bd as U,cS as ne,aj as se,V as W,dg as ie,cj as T,dh as le,i as de,cg as pe,di as G,c_ as ce,dj as he,cZ as ue,dk as ye,dl as me,dm as ge,cY as ve,dn as fe,dp as be,dq as ke,dr as we,db as Ce,ds as xe}from"./standingArtifact-jXigJSsh.js";import{N as _}from"./marks-F7Rhpith.js";import{c as Ee,d as Ae,e as Pe}from"./_virtual_wxt-plugins-CJuM9Ogi.js";const Se=`
:root {
  color-scheme: light dark;

  --parle-font: -apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif;
  --parle-mono: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;

  --parle-t-meta: 12px;
  --parle-t-body: 14px;
  --parle-t-lead: 15px;
  --parle-t-head: 22px;

  --parle-1: 4px;
  --parle-2: 8px;
  --parle-3: 12px;
  --parle-4: 16px;
  --parle-5: 24px;
  --parle-6: 40px;

  --parle-r: 10px;
  --parle-r-sm: 6px;

  --parle-bg: #ffffff;
  --parle-raise: #f6f4ef;
  --parle-ink: #15130f;
  --parle-mid: #5c574e;
  --parle-faint: #726c62;
  --parle-line: rgba(21, 19, 15, 0.10);
  --parle-rule: rgba(21, 19, 15, 0.20);
  --parle-accent: #15130f;
  --parle-stop: #99291c;

  --parle-motion: cubic-bezier(0.2, 0.75, 0.3, 1);
}

@media (prefers-color-scheme: dark) {
  :root {
    --parle-bg: #0d0e11;
    --parle-raise: #16181d;
    --parle-ink: #edeef2;
    --parle-mid: #9aa0ad;
    --parle-faint: #8b93a1;
    --parle-line: rgba(237, 238, 242, 0.1);
    --parle-rule: rgba(237, 238, 242, 0.24);
    --parle-accent: #edeef2;
    --parle-stop: #f0a396;
  }
}

html, body { margin: 0; padding: 0; background: var(--parle-bg); }

.parle-settings {
  font-family: var(--parle-font);
  font-size: var(--parle-t-body);
  line-height: 1.6;
  color: var(--parle-ink);
  max-width: 42rem;
  margin: 0 auto;
  padding: var(--parle-6) var(--parle-5) 96px;
  box-sizing: border-box;
  accent-color: var(--parle-accent);
  -webkit-font-smoothing: antialiased;
}
.parle-settings *, .parle-settings *::before, .parle-settings *::after { box-sizing: border-box; }

.parle-title {
  font-size: var(--parle-t-head);
  font-weight: 650;
  letter-spacing: -0.02em;
  margin: 0 0 var(--parle-3);
}
.parle-says { margin: 0 0 var(--parle-3); }
.parle-quiet { color: var(--parle-mid); font-size: var(--parle-t-meta); margin: 0 0 var(--parle-1); }

.parle-disclosure {
  background: var(--parle-raise);
  border-radius: var(--parle-r);
  padding: var(--parle-4) var(--parle-4) var(--parle-2);
}

/*
 * The sentences a reader is entitled to hold us to: what the list cannot do,
 * what a Digest costs, where a key really lives. A rule down the left in the
 * accent and nothing else \u2014 not a warning about a fault, the lines we most
 * want read. Nothing else on the page wears it, so the mark keeps meaning
 * something.
 */
.parle-honest {
  box-shadow: inset 2px 0 0 var(--parle-accent);
  padding-left: var(--parle-3);
  color: var(--parle-ink);
}

.parle-notice-line {
  margin: var(--parle-3) 0 0;
  padding: var(--parle-2) var(--parle-3);
  border-radius: var(--parle-r-sm);
  background: var(--parle-raise);
  color: var(--parle-accent);
  font-size: var(--parle-t-meta);
}

.parle-section { margin: var(--parle-6) 0 0; }
.parle-section-title {
  font-size: var(--parle-t-meta);
  letter-spacing: 0.08em;
  text-transform: uppercase;
  font-weight: 700;
  color: var(--parle-faint);
  margin: 0 0 var(--parle-3);
}
.parle-sub-title { font-size: var(--parle-t-lead); font-weight: 650; margin: var(--parle-5) 0 var(--parle-2); }

.parle-toggle { padding: var(--parle-3) 0; }
.parle-toggle + .parle-toggle { border-top: 1px solid var(--parle-line); }
.parle-toggle-line { display: flex; align-items: center; gap: var(--parle-2); cursor: pointer; }
.parle-toggle-label { font-weight: 600; }
.parle-toggle-says {
  margin: var(--parle-1) 0 0 var(--parle-5);
  color: var(--parle-mid);
  font-size: var(--parle-t-meta);
}
.parle-toggle-off { opacity: 0.55; }
.parle-toggle-off .parle-toggle-line { cursor: default; }

/*
 * The long version of the disclosure, closed by default.
 *
 * Styled as a quiet line rather than a panel: it is the detail a reader goes
 * looking for, not something the page argues with them about. Everything in it
 * is in the DOM whether or not it is open, so find-in-page still reaches it.
 */
.parle-longer { margin: var(--parle-2) 0 var(--parle-3); }
.parle-longer summary {
  cursor: pointer;
  font-size: var(--parle-t-meta);
  color: var(--parle-mid);
}
.parle-longer summary:hover { color: var(--parle-ink); }
.parle-longer .parle-sub-title { margin: var(--parle-3) 0 var(--parle-1); }
.parle-plain { list-style: none; margin: 0; padding: 0; }
.parle-plain-item {
  padding: var(--parle-2) 0;
  color: var(--parle-mid);
  font-size: var(--parle-t-meta);
}
.parle-plain-item + .parle-plain-item { border-top: 1px solid var(--parle-line); }

.parle-rules { margin: var(--parle-3) 0 var(--parle-1); }

.parle-built-in {
  margin: var(--parle-3) 0;
  background: var(--parle-raise);
  border-radius: var(--parle-r-sm);
  padding: var(--parle-2) var(--parle-3);
}
.parle-built-in summary { cursor: pointer; font-weight: 600; }
.parle-category { margin: var(--parle-3) 0 0; }
.parle-category-title { font-size: var(--parle-t-meta); margin: 0 0 2px; font-weight: 650; }
.parle-category-domains {
  margin: 0;
  color: var(--parle-mid);
  font-size: var(--parle-t-meta);
  word-break: break-word;
}

.parle-sites { list-style: none; margin: 0 0 var(--parle-2); padding: 0; }
.parle-site {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--parle-3);
  padding: var(--parle-2) 0;
}
.parle-site + .parle-site { border-top: 1px solid var(--parle-line); }
.parle-site-name { word-break: break-all; }
.parle-empty-line { color: var(--parle-mid); margin: 0 0 var(--parle-2); font-size: var(--parle-t-meta); }

.parle-adder { margin: var(--parle-2) 0 var(--parle-1); }
.parle-adder-label { display: block; font-size: var(--parle-t-meta); font-weight: 600; }
.parle-adder-box {
  display: block;
  width: 100%;
  margin: var(--parle-2) 0 0;
  padding: var(--parle-2) var(--parle-3);
  font: inherit;
  color: var(--parle-ink);
  background: var(--parle-bg);
  border: 1px solid var(--parle-rule);
  border-radius: var(--parle-r-sm);
  transition: border-color 160ms var(--parle-motion);
}
.parle-adder-box:focus { outline: none; border-color: var(--parle-accent); }
.parle-adder-hint { margin: var(--parle-1) 0 var(--parle-2); color: var(--parle-mid); font-size: var(--parle-t-meta); }

/*
 * One action shape across the whole product.
 *
 * The panel's buttons are pills; these were 6px chips, and the first-run
 * screen's were 8px. Three radii for one gesture is three designers, and a
 * reader moving from the mark to this page should not be able to tell that two
 * stylesheets drew them.
 */
.parle-action {
  font: inherit;
  font-size: var(--parle-t-meta);
  font-weight: 550;
  padding: var(--parle-2) var(--parle-4);
  border-radius: 999px;
  border: none;
  box-shadow: inset 0 0 0 1px var(--parle-rule);
  background: var(--parle-bg);
  color: var(--parle-ink);
  cursor: pointer;
  transition: background 160ms var(--parle-motion);
}
.parle-action:hover { background: var(--parle-raise); }
.parle-action-loud { color: var(--parle-stop); }
.parle-inline-action {
  font: inherit;
  font-size: var(--parle-t-meta);
  padding: var(--parle-1) var(--parle-3);
  border-radius: 999px;
  border: none;
  background: transparent;
  color: var(--parle-mid);
  cursor: pointer;
  flex: none;
  transition: background 160ms var(--parle-motion), color 160ms var(--parle-motion);
}
.parle-inline-action:hover { color: var(--parle-ink); background: var(--parle-raise); }

.parle-settings :focus-visible {
  outline: 2px solid var(--parle-accent);
  outline-offset: 2px;
  border-radius: var(--parle-r-sm);
}

.parle-forget { padding: var(--parle-3) 0; }
.parle-forget + .parle-forget { border-top: 1px solid var(--parle-line); }

.parle-foot {
  margin: var(--parle-6) 0 0;
  padding-top: var(--parle-4);
  border-top: 1px solid var(--parle-line);
  color: var(--parle-mid);
  font-size: var(--parle-t-meta);
}

@media (prefers-reduced-motion: reduce) {
  .parle-settings *, .parle-settings { transition: none !important; animation: none !important; }
}
`,j=r=>r.length<=1?r[0]??"":`${r.slice(0,-1).join(", ")} and ${r[r.length-1]}`,I={title:"What Parle sends",sends:r=>`Parle tells ${j(r)} which page or site you are reading, to see whether anyone has discussed it. They see it. It is not anonymous.`,paragraphs:["It skips banks, mail, AI chats, health, government, adult, social and private addresses, and addresses that visibly carry a token. It never sends what comes after the #.","That is a list, so it will miss things. Read it below, add to it, override it, or turn automatic lookups off.","When you open Parle on a page it also asks archive.org whether a copy of it has been kept, and en.wikipedia.org whether any article cites it. Both see the address. Neither is asked as you browse."],build:(r,e)=>r.length===0||e.length===0?null:`In this build, the code that would ask ${j(r)} is not included at all, so it is ${j(e)} that see the addresses of the pages you read.`},F={title:"The longer version",refuses:{title:"Three things Parle will not claim",items:["Not \u201Cyour browsing is private\u201D. It is not. Every page you read that is not skipped produces requests to other companies carrying its address.","Not \u201Cwe exclude addresses carrying credentials\u201D. The rules catch several common shapes. A short share link that looks like an ordinary address cannot be detected at all.","Not \u201Cwe protect sensitive categories\u201D. A list of sites cannot cover health, internal company tools or documents, and the best lists available are measurably missing well-known providers."]},build:{title:"In this build",items:["Reddit is asked with your own Reddit cookies, because it answers nothing without them. Hacker News, Bluesky, Lemmy and Lobsters are asked with no account and no key.","There is no server run by this project. The one thing fetched from the project itself is a small static skip-list update, at most once a day, from the extension's own public code repository \u2014 the same file for every install, carrying nothing about you or your pages."]}},N={title:"The archived copy",label:"Open the archived copy instead of the page",off:"Off. Parle asks the Internet Archive about a page only when you open Parle on it, and never moves you off the page you asked for.",on:"On. The address of every page you read that is not skipped goes to archive.org as you open it, and where a recent copy has been kept Parle takes you to it instead. Skipped sites, paused sites and pages that are already archived copies are left alone."},D={title:"Automatic lookups",label:"Look pages up as I read them",on:"Pages are looked up as you open them. The toolbar button works everywhere.",off:"Nothing about the pages you read is sent as you browse; only the daily skip-list check runs. The toolbar button still looks up any web page, including skipped ones."},R={title:"Site front pages",label:"Show every Discussion, even on site front pages",off:"On a site's front page \u2014 facebook.com rather than a page on it \u2014 old Discussions are folded behind one line you can open. Anything from the last month is shown as usual.",on:"Every Discussion is shown everywhere. On a site's front page that can mean dozens of conversations about unrelated things."},x={title:"Where Parle looks",intro:"Turn any of these off and Parle stops asking it, whether or not you open the panel.",hackernews:{name:"Hacker News",says:"Searches by address. Public, no account \u2014 it costs your own connection, not anyone's key."},reddit:{name:"Reddit",says:"Searches by address, using the Reddit session already in your browser. The request goes out as you, and shares your Reddit rate limit."},x:{name:"X",says:"Searches by address, using the X session already in your browser \u2014 there is no other way to ask. It goes out as you, so if X decides it looks automated your account is rate-limited, not ours. Asked only once another site has found a discussion of this page. Never posts, likes or follows."},bluesky:{name:"Bluesky",says:"Searches by address. Public, no account \u2014 it costs your own connection, not anyone's key."},lemmy:{name:"Lemmy",says:"Asks lemmy.world, which answers for the many communities it is connected to. Public, no account."},lobsters:{name:"Lobsters",says:"Asks for everything from this page's site and picks out this page. Public, no account \u2014 and a small volunteer-run site, so it is asked sparingly."},compiledOut:"Not in this build."},p={title:"Digests",intro:"A Digest is Parle's summary of what the discussions it found actually said. It needs an AI Provider you connect. Everything else on this page works whether or not you do.",stored:"Kept on this device as ordinary text \u2014 an extension has nowhere private to put a key, so anything that can read your browser's profile can read it. Use one you can revoke.",cost:"Writing one reads the comments of the discussions found on a page and sends them to whatever you connect. So the panel asks first, every time.",choose:"What Parle should ask",none:{name:"Nothing",says:"No Digests. Discussions are still found and listed."},byok:{name:"An API key of your own",says:"OpenAI, or anything that speaks the same shape \u2014 a local model, or another company's endpoint. This one keeps working because of your agreement with whoever issued the key, not ours with anyone.",key:"API key",keySave:"Save this key",keyHint:"Kept on this device, sent only to the address below.",baseUrl:"Address to send it to",baseUrlHint:"Empty means OpenAI. A local model might be http://localhost:8080/v1.",model:"Model",modelHint:"Empty asks for a small, current one.",saved:"Key saved.",missing:"Paste a key first."},onDevice:{name:"This browser's built-in model",says:"No key, no account, and the comments never leave this machine.",absent:"This browser does not offer one.",present:"This browser has one ready."},codex:{name:"ChatGPT",says:"Bills your own ChatGPT subscription. There is no sign-in button for it yet \u2014 signing in from an extension is unresolved on Safari \u2014 so it takes a token you already have. A rough edge, labelled as one.",token:"Access token",tokenSave:"Save this token",tokenHint:"Kept on this device, exactly like an API key.",model:"Model",saved:"Token saved."},forget:"Forget this key",forgotten:"Forgotten.",chosen:r=>`Parle will ask ${r}.`},y={title:"Pages Parle skips",incomplete:"A list is incomplete by nature. It will miss services nobody has told us about, and it cannot see a private share link that looks ordinary. A floor, not a guarantee.",rules:{title:"Always skipped, by rule",says:"These need no list and cannot go out of date, because they are facts about the address: not a web page at all, on your own network, or a name that only exists inside it.",shapes:"Parle also skips addresses that visibly carry a password, a token, an email address or a long random code. That is pattern-matching, not a guarantee: a short share link that looks ordinary cannot be caught."},builtIn:{title:"The built-in list",says:"Sites Parle does not look up unless you say otherwise. Grouped by why they are here."},yours:{title:"Sites you added",empty:"None yet."},overridden:{title:"Built-in entries you turned off",says:"Looked up again, even though they are on the built-in list.",empty:"None yet."},paused:{title:"Sites you paused",says:"Paused from the panel, undone here or there. Not a judgement about the site.",empty:"None yet."},add:{label:"Add a site to skip",hint:"example.com, or example.com/private. Subdomains are covered.",action:"Skip this site",rejected:"That is not a site address."},allow:{label:"Look up a site anyway",hint:"Overrides the built-in list for one site.",action:"Look it up anyway"},remove:"Remove",resume:"Resume"},Te={banking:"Banks and financial accounts",webmail:"Mail","ai-chat":"AI chats",health:"Health",documents:"Documents and file shares",calendar:"Calendars and meetings",search:"Search engines",social:"Social sites Parle reads rather than asks",government:"Government",adult:"Adult"},C={title:"What this device remembers",everything:{action:"Forget everything",says:"Everything Parle knows about discussions it found, built from pages you had already opened. On Safari that includes the readable Recent list of pages where you opened Parle. It also clears the downloaded skip-list update, which comes back within a day."},safariRecents:"The Safari companion keeps at most 100 of those pages for 30 days, with the original page, its archived copy and every Discussion Parle found. The list stays on this device, never syncs, and can also be cleared from the companion app.",lookupRecord:{action:"Forget only the record of what was looked up",says:"The dated note of which addresses Parle asked about, kept so it does not ask twice \u2014 and which of them turned out to be a site's front page. This is the record of what you read, and it is stored scrambled."},kept:"Your settings are not affected by either.",clearing:"Clearing\u2026",done:"Done.",failed:"The browser stores were cleared, but Safari could not confirm clearing Recents. Try again."},q={title:"Standing \u2014 who says it, and under what licence",says:"Where named raters have published a judgement of a page's publisher, Parle shows what they said and who said it \u2014 that is Standing, and it is always someone else's judgement, always named. Parle judges nobody. What they said ships inside the extension, so reading it sends nothing anywhere.",stale:"It is as current as this build and no more. A judgement that changed last month is still the old one here."},Y={version:r=>`Skip list, version ${r}.`,source:"Parle is AGPL-3.0. Every choice on this page is made and kept on this device."},a=(r,e,o)=>{const l=document.createElement(r);return e!==""&&(l.className=e),o!==void 0&&(l.textContent=o),l},P=(r,e,o)=>{const l=a("button",r,e);return l.type="button",l.addEventListener("click",o),l},E=r=>{const e=a("section","parle-section");return e.appendChild(a("h2","parle-section-title",r)),e},L=(r,e,o,l,c)=>{const u=a("div",`parle-toggle${l?"":" parle-toggle-off"}`),i=a("label","parle-toggle-line"),d=document.createElement("input");return d.type="checkbox",d.checked=o,d.disabled=!l,d.addEventListener("change",()=>c(d.checked)),i.appendChild(d),i.appendChild(a("span","parle-toggle-label",r)),u.appendChild(i),u.appendChild(a("p","parle-toggle-says",e)),u},B=(r,e,o)=>{if(r.length===0)return a("p","parle-empty-line",e);const l=a("ul","parle-sites");return r.forEach((c,u)=>{const i=a("li","parle-site");i.appendChild(a("span","parle-site-name",c.label)),i.appendChild(P("parle-inline-action",c.action,()=>o(u))),l.appendChild(i)}),l},V=(r,e,o,l)=>{const c=a("div","parle-adder"),u=document.createElement("label");u.className="parle-adder-label",u.textContent=r;const i=document.createElement("input");i.type="text",i.className="parle-adder-box",i.placeholder="example.com",u.appendChild(i),c.appendChild(u),c.appendChild(a("p","parle-adder-hint",e));const d=()=>{const h=i.value;i.value="",l(h)};return i.addEventListener("keydown",h=>{h.key==="Enter"&&d()}),c.appendChild(P("parle-action",o,d)),c},H={hackernews:x.hackernews,reddit:x.reddit,x:x.x,bluesky:x.bluesky,lemmy:x.lemmy,lobsters:x.lobsters},$=(r,e,o,l,c,u)=>{const i=a("div",`parle-toggle${c?"":" parle-toggle-off"}`),d=a("label","parle-toggle-line"),h=document.createElement("input");return h.type="radio",h.name="parle-provider",h.checked=l,h.disabled=!c,h.addEventListener("change",()=>{h.checked&&u()}),d.appendChild(h),d.appendChild(a("span","parle-toggle-label",e)),i.appendChild(d),i.appendChild(a("p","parle-toggle-says",o)),i},X=(r,e,o,l,c,u)=>{const i=a("div","parle-adder"),d=document.createElement("label");d.className="parle-adder-label",d.textContent=r;const h=document.createElement("input");h.type="password",h.className="parle-adder-box",h.autocomplete="off",h.placeholder=o?"A key is saved. Type a new one to replace it.":"",d.appendChild(h),i.appendChild(d),i.appendChild(a("p","parle-adder-hint",e));const w=()=>{const m=h.value;h.value="",c(m)};return h.addEventListener("keydown",m=>{m.key==="Enter"&&w()}),i.appendChild(P("parle-action",l,w)),o&&i.appendChild(P("parle-inline-action",p.forget,u)),i},J=(r,e,o,l,c)=>{const u=a("div","parle-adder"),i=document.createElement("label");i.className="parle-adder-label",i.textContent=r;const d=document.createElement("input");d.type="text",d.className="parle-adder-box",d.value=o,d.placeholder=l,i.appendChild(d),u.appendChild(i),u.appendChild(a("p","parle-adder-hint",e));const h=()=>c(d.value);return d.addEventListener("keydown",w=>{w.key==="Enter"&&h()}),d.addEventListener("change",h),u},Oe=r=>{const e=new Map;for(const c of r.entries){const u=e.get(c.category);u===void 0?e.set(c.category,[c.domain]):u.push(c.domain)}const o=a("details","parle-built-in"),l=document.createElement("summary");l.textContent=`${y.builtIn.title} \u2014 ${r.entries.length} sites`,o.appendChild(l),o.appendChild(a("p","parle-says",y.builtIn.says));for(const[c,u]of e){const i=a("div","parle-category");i.appendChild(a("h4","parle-category-title",Te[c])),i.appendChild(a("p","parle-category-domains",u.join(", "))),o.appendChild(i)}return o},Ie=()=>{const r=a("details","parle-longer");r.id="longer";const e=document.createElement("summary");e.textContent=F.title,r.appendChild(e);for(const o of[F.refuses,F.build]){r.appendChild(a("h3","parle-sub-title",o.title));const l=a("ul","parle-plain");for(const c of o.items)l.appendChild(a("li","parle-plain-item",c));r.appendChild(l)}return r},Ne=(r,e,o)=>{r.textContent="",r.className="parle-settings";const l=a("header","parle-disclosure");l.appendChild(a("h1","parle-title",I.title));const c=_.filter(n=>!e.compiledOut.includes(n)).map(n=>H[n].name);l.appendChild(a("p","parle-says",I.sends(c)));for(const n of I.paragraphs)l.appendChild(a("p","parle-says",n));const u=I.build(e.compiledOut.map(n=>H[n].name),c);u!==null&&l.appendChild(a("p","parle-says parle-honest",u)),l.appendChild(Ie()),r.appendChild(l),e.notice!==null&&r.appendChild(a("div","parle-notice-line",e.notice));const i=E(D.title);i.appendChild(L(D.label,e.settings.automatic?D.on:D.off,e.settings.automatic,!0,n=>o.setAutomatic(n))),r.appendChild(i);const d=E(R.title);d.appendChild(L(R.label,e.settings.everyDiscussion?R.on:R.off,e.settings.everyDiscussion,!0,n=>o.setEveryDiscussion(n))),r.appendChild(d);const h=E(N.title);h.appendChild(L(N.label,e.settings.autoOpenArchive?N.on:N.off,e.settings.autoOpenArchive,!0,n=>o.setAutoOpenArchive(n))),r.appendChild(h);const w=E(x.title);w.appendChild(a("p","parle-says",x.intro));for(const n of _){const k=H[n],S=e.compiledOut.includes(n);w.appendChild(L(k.name,S?`${k.says} ${x.compiledOut}`:k.says,e.settings.networks[n]&&!S,!S,ee=>o.setNetwork(n,ee)))}r.appendChild(w);const m=E(p.title);m.appendChild(a("p","parle-says",p.intro)),m.appendChild(a("p","parle-says parle-honest",p.cost)),m.appendChild(a("h3","parle-sub-title",p.choose));const g=e.settings.provider.connection;m.appendChild($("none",p.none.name,p.none.says,g==="none",!0,()=>o.setProvider("none"))),m.appendChild($("byok",p.byok.name,p.byok.says,g==="byok",!0,()=>o.setProvider("byok"))),m.appendChild($("on-device",p.onDevice.name,e.onDevice?`${p.onDevice.says} ${p.onDevice.present}`:`${p.onDevice.says} ${p.onDevice.absent}`,g==="on-device",e.onDevice,()=>o.setProvider("on-device"))),m.appendChild($("codex",p.codex.name,p.codex.says,g==="codex",!0,()=>o.setProvider("codex"))),m.appendChild(a("p","parle-says parle-honest",p.stored)),m.appendChild(X(p.byok.key,p.byok.keyHint,M(e.settings.provider.byok.apiKey),p.byok.keySave,n=>o.setByok({apiKey:n}),()=>o.forgetProviderKey("byok"))),m.appendChild(J(p.byok.baseUrl,p.byok.baseUrlHint,e.settings.provider.byok.baseUrl,"https://api.openai.com/v1",n=>o.setByok({baseUrl:n}))),m.appendChild(J(p.byok.model,p.byok.modelHint,e.settings.provider.byok.model,"gpt-4o-mini",n=>o.setByok({model:n}))),m.appendChild(X(p.codex.token,p.codex.tokenHint,M(e.settings.provider.codex.token),p.codex.tokenSave,n=>o.setCodex({token:n}),()=>o.forgetProviderKey("codex"))),r.appendChild(m);const v=E(y.title);v.appendChild(a("p","parle-says parle-honest",y.incomplete));const b=a("div","parle-rules");b.appendChild(a("h3","parle-sub-title",y.rules.title)),b.appendChild(a("p","parle-says",y.rules.says)),b.appendChild(a("p","parle-says parle-honest",y.rules.shapes)),v.appendChild(b),v.appendChild(Oe(e.artifact)),v.appendChild(a("h3","parle-sub-title",y.yours.title)),v.appendChild(B(e.settings.excluded.map(n=>({label:O(n),action:y.remove})),y.yours.empty,n=>{const k=e.settings.excluded[n];k!==void 0&&o.removeExclusion(k)})),v.appendChild(V(y.add.label,y.add.hint,y.add.action,n=>o.addExclusion(n))),v.appendChild(a("h3","parle-sub-title",y.overridden.title)),v.appendChild(a("p","parle-says",y.overridden.says)),v.appendChild(B(e.settings.allowedAnyway.map(n=>({label:O(n),action:y.remove})),y.overridden.empty,n=>{const k=e.settings.allowedAnyway[n];k!==void 0&&o.removeAllowAnyway(k)})),v.appendChild(V(y.allow.label,y.allow.hint,y.allow.action,n=>o.allowAnyway(n))),v.appendChild(a("h3","parle-sub-title",y.paused.title)),v.appendChild(a("p","parle-says",y.paused.says)),v.appendChild(B(e.settings.paused.map(n=>({label:n,action:y.resume})),y.paused.empty,n=>{const k=e.settings.paused[n];k!==void 0&&o.resumeSite(k)})),r.appendChild(v);const t=E(C.title),s=a("div","parle-forget");s.appendChild(a("p","parle-says",C.everything.says)),s.appendChild(a("p","parle-says parle-quiet",C.safariRecents)),s.appendChild(P("parle-action parle-action-loud",C.everything.action,()=>o.forget("everything"))),t.appendChild(s);const f=a("div","parle-forget");f.appendChild(a("p","parle-says",C.lookupRecord.says)),f.appendChild(P("parle-action",C.lookupRecord.action,()=>o.forget("lookup-record"))),t.appendChild(f),t.appendChild(a("p","parle-says parle-quiet",C.kept)),r.appendChild(t);const A=te();if(A.length>0){const n=E(q.title);n.appendChild(a("p","parle-says",q.says)),n.appendChild(a("p","parle-says parle-honest",q.stale));const k=a("ul","parle-plain");for(const S of A)k.appendChild(a("li","parle-plain-item",S));n.appendChild(k),n.appendChild(a("p","parle-says parle-honest",re)),r.appendChild(n)}const z=a("footer","parle-foot");z.appendChild(a("p","parle-quiet",Y.version(e.artifact.version))),z.appendChild(a("p","parle-quiet",Y.source)),r.appendChild(z)},Q=document.createElement("style");Q.textContent=Se;document.head.appendChild(Q);const Z=document.getElementById("settings");if(Z!==null){const r=oe(K.layer.pipe(U(ne.layer),U(se.layer)));let e=null,o=null,l=0;const c=ae(Ee,t=>{t._tag!=="Forgot"||o===null||t.requestId!==o.requestId||t.scope!==o.scope||(o=null,e=t.ok?C.done:C.failed,b(),t.ok&&setTimeout(b,2e3))},()=>{o!==null&&c.say(o)}),u=["x"];let i=!1,d=T;const h=async()=>{try{const s=await(await caches.open("parle")).match(`https://parle.invalid/${encodeURIComponent(ie)}`);if(s===void 0)return T;const f=JSON.parse(await s.text()),A=le(JSON.stringify(f.artifact));return de(A)?pe(T,A.value):T}catch{return T}},w=t=>{Ne(Z,{settings:t,artifact:d,compiledOut:u,onDevice:i,notice:e},v)},m=()=>{const t=globalThis.LanguageModel;t?.availability!==void 0&&t.availability().then(s=>{s==="available"&&(i=!0,b())},()=>{})},g=(t,s=null)=>{e=s,r.runPromise(W(K,f=>f.change(t))).then(f=>{c.say(Pe()),h().then(A=>{d=A,w(f)},()=>w(f))},()=>{})},v={setNetwork:(t,s)=>g(f=>xe(f,t,s)),setAutomatic:t=>g(s=>Ce(s,t)),setEveryDiscussion:t=>g(s=>we(s,t)),setAutoOpenArchive:t=>g(s=>ke(s,t)),setProvider:t=>g(s=>ge(s,t),t==="none"?null:p.chosen(p[t==="byok"?"byok":t==="codex"?"codex":"onDevice"].name)),setByok:t=>{if(t.apiKey!==void 0&&t.apiKey.trim()===""){e=p.byok.missing,b();return}g(s=>me(s,t),t.apiKey===void 0?null:p.byok.saved)},setCodex:t=>{if(t.token!==void 0&&t.token.trim()===""){e=p.byok.missing,b();return}g(s=>ye(s,t),t.token===void 0?null:p.codex.saved)},forgetProviderKey:t=>g(s=>be(s,t),p.forgotten),addExclusion:t=>{const s=G(t);if(s===null){e=y.add.rejected,b();return}g(f=>ue(f,s),`Parle will skip ${O(s)}.`)},removeExclusion:t=>g(s=>he(s,t),`Parle will look up ${O(t)} again.`),allowAnyway:t=>{const s=G(t);if(s===null){e=y.add.rejected,b();return}g(f=>ce(f,s),`Parle will look up ${O(s)}, even though it is on the built-in list.`)},removeAllowAnyway:t=>g(s=>fe(s,t)),resumeSite:t=>g(s=>ve(s,t),`Resumed on ${t}.`),forget:t=>{if(o!==null)return;const s=Date.now();l+=1,o=Ae(t,`${s.toString(36)}-${l.toString(36)}`,s),e=C.clearing,b(),c.say(o)}},b=()=>{Promise.all([r.runPromise(W(K,t=>t.current)),h()]).then(([t,s])=>{d=s,w(t)},()=>{})};document.addEventListener("visibilitychange",()=>{document.visibilityState==="visible"&&b()}),b(),m()}
