import{l as W}from"./Surface-Bf1SyUgI.js";import{f as $}from"./Panel-BS6W8507.js";import{e as _,W as I,R as j,f as q,O as B,g as F,j as G,k as Y,l as H,L as K,m as U}from"./_virtual_wxt-plugins-B4k4brV5.js";const O="http://www.w3.org/2000/svg",L=e=>{const a=document.createElementNS(O,"svg");return a.setAttribute("viewBox",e),a.setAttribute("aria-hidden","true"),a},N=(e,a)=>{const r=document.createElementNS(O,"path");return r.setAttribute("d",e),r},A=(e,a,r,t)=>{const n=document.createElementNS(O,"circle");return n.setAttribute("cx",String(e)),n.setAttribute("cy",String(a)),n.setAttribute("r",String(r)),n.setAttribute("fill",t),n},V=()=>{const e=L("0 0 16 16"),a=N("M6.2 3.2H3.8a1 1 0 0 0-1 1v8a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V9.8");a.setAttribute("fill","none"),a.setAttribute("stroke","currentColor"),a.setAttribute("stroke-width","1.3"),a.setAttribute("stroke-linecap","round"),a.setAttribute("stroke-linejoin","round"),e.appendChild(a);const r=N("M8.2 2.8h5v5M13.1 2.9 7.4 8.6");return r.setAttribute("fill","none"),r.setAttribute("stroke","currentColor"),r.setAttribute("stroke-width","1.3"),r.setAttribute("stroke-linecap","round"),r.setAttribute("stroke-linejoin","round"),e.appendChild(r),e},Q=()=>{const e=L("0 0 16 16"),a=N("M2.5 4h8M2.5 7h10.5M5.5 10h7.5M5.5 13h5");return a.setAttribute("fill","none"),a.setAttribute("stroke","currentColor"),a.setAttribute("stroke-width","1.3"),a.setAttribute("stroke-linecap","round"),e.appendChild(a),e},J=()=>{const e=L("0 0 16 16");return e.appendChild(A(3.5,8,1,"currentColor")),e.appendChild(A(8,8,1,"currentColor")),e.appendChild(A(12.5,8,1,"currentColor")),e},X=e=>{try{const a=new URL(e);return a.protocol!=="http:"&&a.protocol!=="https:"?null:a.hostname.replace(/^www\./,"")}catch{return null}},Z=e=>e.length<=1?e[0]??"Nowhere":`${e.slice(0,-1).join(", ")} and ${e[e.length-1]}`,o=(e,a,r)=>{const t=document.createElement(e);return a!==""&&(t.className=a),r!==void 0&&(t.textContent=r),t},h=(e,a,r)=>{const t=o("button",e,a);return t.addEventListener("click",n=>{n.preventDefault(),r()}),t},E=(e,a,r,t)=>{const n=o("button",e);return n.type="button",n.setAttribute("aria-label",a),n.title=a,n.appendChild(r),n.addEventListener("click",s=>{s.preventDefault(),t()}),n},ee=e=>e===1?"also submitted once":`also submitted ${e} times`,ae=8,re=40,te=3,y=new Set,v=new Set,oe=(e,a)=>`${e.key}\0${a.id}`,ne=(e,a,r)=>{const t=o("div","parle-comments"),n=l=>{l.appendChild(o("span","parle-comments-spacer")),l.appendChild(E("parle-comments-open","Open discussion",V(),()=>a.openOut(e.permalink)));const d=o("span","parle-comments-menu-wrap"),i=o("span","parle-comments-menu");i.hidden=!0,i.appendChild(h("parle-comments-menu-item","What Parle sends",a.openDisclosure));const p=E("parle-comments-more-actions","More actions",J(),()=>{i.hidden=!i.hidden,p.setAttribute("aria-expanded",i.hidden?"false":"true")});p.setAttribute("aria-haspopup","menu"),p.setAttribute("aria-expanded","false"),d.appendChild(p),d.appendChild(i),l.appendChild(d)},s=()=>{const l=o("div","parle-comments-tools");return n(l),l};if(e.comments===null&&e.commentCount===0)return t.appendChild(s()),t.appendChild(o("p","parle-comments-note","No comments yet.")),t;if(e.comments===null||e.comments._tag==="Reading")return t.appendChild(s()),t.appendChild(o("p","parle-comments-note","Loading comments\u2026")),t;if(e.comments._tag==="Unreadable")return t.appendChild(s()),t.appendChild(o("p","parle-comments-note","Could not read this one.")),t;const m=e.comments,x=new Map(m.comments.map(l=>[l.id,l])),u=new Map;for(const l of m.comments){const d=l.parentId!==null&&l.parentId!==l.id&&x.has(l.parentId)?l.parentId:null,i=u.get(d);i===void 0?u.set(d,[l]):i.push(l)}const T=l=>{let d=0;const i=[...u.get(l.id)??[]];for(;i.length>0;){const p=i.shift();p!==void 0&&(d+=1,i.push(...u.get(p.id)??[]))}return d},M=l=>e.network!=="x"||l.startsWith("@")?l:`@${l}`,C=(l,d,i=!0)=>{const p=o("article","parle-comment"),b=o("div","parle-comment-who",M(l.author));l.age!==""&&b.appendChild(o("span","parle-comment-age",l.age)),p.appendChild(b),p.appendChild(o("p","parle-comment-text",l.text));const z=u.get(l.id)??[];if(z.length===0||!i)return p;const g=T(l);if(d>=te)return p.appendChild(h("parle-comment-more",`Continue ${g===1?"this reply":`these ${g} replies`} on the discussion`,()=>a.openOut(e.permalink))),p;const c=oe(e,l),f=v.has(c);if(p.appendChild(h("parle-comment-more",f?"Hide replies":`${g} ${g===1?"reply":"replies"}`,()=>{v.has(c)?v.delete(c):v.add(c),w()})),f){const k=o("div","parle-replies");for(const R of z)k.appendChild(C(R,d+1));p.appendChild(k)}return p},w=()=>{t.replaceChildren();const l=o("div","parle-comments-tools"),d=y.has(e.key),i=o("button","parle-comments-mode");if(i.type="button",i.setAttribute("aria-label",d?"Flat":"Nested"),i.appendChild(Q()),i.appendChild(o("span","",d?"Flat":"Nested")),i.appendChild(o("span","parle-comments-chevron","\u2304")),i.addEventListener("click",c=>{c.preventDefault(),y.has(e.key)?y.delete(e.key):y.add(e.key),w()}),i.setAttribute("aria-pressed",d?"false":"true"),l.appendChild(i),l.appendChild(h("parle-comments-collapse","Collapse all",()=>{for(const c of[...v])c.startsWith(`${e.key}\0`)&&v.delete(c);w()})),n(l),t.appendChild(l),d){const c=m.comments.slice(0,re);for(const k of c)t.appendChild(C(k,0,!1));const f=Math.max(0,m.comments.length-c.length)+m.beyond;f>0&&t.appendChild(h("parle-comments-more",`Open ${f} more on the discussion`,()=>a.openOut(e.permalink)));return}const p=u.get(null)??[],b=p.slice(0,ae);for(const c of b)t.appendChild(C(c,0));const g=p.slice(b.length).reduce((c,f)=>c+1+T(f),0)+m.beyond;g>0&&t.appendChild(h("parle-comments-more",`Open ${g} more on the discussion`,()=>a.openOut(e.permalink)))};return w(),t},le=e=>{switch(e.network){case"hackernews":return{score:`${e.score} points`,comments:`${e.commentCount} ${e.commentCount===1?"comment":"comments"}`};case"reddit":return{score:`${e.score} upvotes`,comments:`${e.commentCount} ${e.commentCount===1?"comment":"comments"}`};case"x":return{score:`${e.score} likes`,comments:`${e.commentCount} ${e.commentCount===1?"reply":"replies"}`}}},ie=(e,a)=>{const r=o("div","parle-row-holder"),t=o("div","parle-row"),n=o("a","parle-title");n.textContent=e.title,n.href=e.permalink,n.target="_blank",n.rel="noreferrer noopener",n.addEventListener("click",u=>{u.preventDefault(),a.openOut(e.permalink)}),t.appendChild(n);const s=o("div","parle-facts"),m=le(e);s.appendChild(o("span","parle-network",e.networkName)),s.appendChild(o("span","",m.score)),s.appendChild(o("span","",m.comments)),e.age!==""&&s.appendChild(o("span","",e.age)),e.alsoSubmitted>0&&s.appendChild(o("span","parle-repeat",ee(e.alsoSubmitted))),t.appendChild(s),r.appendChild(t);const x=ne(e,a);return x!==null&&r.appendChild(x),r},pe=(e,a)=>{const r=o("section","parle-folded");r.appendChild(o("p","parle-folded-says",e.says));const t=o("div","parle-folded-rows");t.hidden=!0;for(const s of e.rows)t.appendChild(ie(s,a));const n=h("parle-act parle-act-folded",e.label,()=>{t.hidden=!1,n.remove()});return r.appendChild(n),r.appendChild(t),r},se=e=>e.waitingOn.length===0?"Still looking.":`Still looking \u2014 ${e.waitingOn.join(", ")}`,de=e=>{const a=$(e);return a>0?`${a} discussion${a===1?"":"s"} on this page.`:e.stillLooking?se(e):e.folded!==null?e.folded.says:e.foundNothing?`Nobody has discussed this page. ${Z(e.answeredBy)} answered, with nothing.`:e.couldNotAsk?"Parle could not find out. Nowhere answered \u2014 which is not the same as nobody discussing it.":"Nothing has been asked about this page yet."},ce=(e,a)=>{switch(e.kind){case"not-a-web-page":return null;case"undecided":return h("parle-act parle-act-strong","Read this and choose",a.openDisclosure);case"automatic-off":return h("parle-act","Look this page up",a.lookAnyway);case"networks-off":return h("parle-act","Choose where Parle looks",a.openSettings);case"excluded":case"site-paused":case"over-budget":case"switched-off":case"front-door":return h("parle-act","Look it up anyway",a.lookAnyway)}},he=(e,a)=>{const r=o("div",`parle-restraint parle-restraint-${e.kind}`);r.appendChild(o("p","parle-restraint-says",e.says));const t=ce(e,a);return t!==null&&r.appendChild(t),r},D=(e,a)=>o("div",`${a} parle-tone-${e.tone}`,e.text),me=e=>{const a=o("section","parle-coverage");a.appendChild(o("h2","parle-coverage-name","Where Parle asked"));for(const r of e){const t=o("div","parle-account");t.appendChild(o("span","parle-account-place",r.place)),t.appendChild(o("span",`parle-account-${r.tone}`,r.standing)),a.appendChild(t)}return a},ue=(e,a)=>{const r=X(e.address);if(r===null)return null;const t=e.restraint!==null&&e.restraint.kind==="site-paused";return h("parle-link",t?`Resume on ${r}`:`Pause on ${r}`,()=>t?a.resumeSite(r):a.pauseSite(r))},ge=(e,a)=>{const r=o("footer","parle-footer"),t=o("div","parle-footer-row");t.appendChild(o("span","parle-footer-state",e.automatic?"Looking pages up automatically":"Only when you ask")),t.appendChild(h("parle-link",e.automatic?"Turn off":"Turn on",()=>a.decide(!e.automatic))),r.appendChild(t);const n=o("div","parle-footer-row"),s=ue(e,a);return s!==null&&n.appendChild(s),n.appendChild(h("parle-link","What Parle sends",a.openDisclosure)),n.appendChild(h("parle-link","Settings",a.openSettings)),r.appendChild(n),r},fe=e=>{const a=o("header","parle-head");return a.appendChild(o("h1","parle-heading",e.heading)),a.appendChild(o("div","parle-address",e.address)),a},ve=(e,a,r)=>{e.textContent="",e.className="parle",e.appendChild(fe(a));const t=o("div","parle-body");a.restraint!==null&&t.appendChild(he(a.restraint,r));const n=a.folded!==null&&$(a)===0;(a.restraint===null||$(a)>0)&&!n&&t.appendChild(o("p","parle-said",de(a))),a.folded!==null&&t.appendChild(pe(a.folded,r)),a.accounts.length>0&&t.appendChild(me(a.accounts)),a.windowed!==null&&t.appendChild(D(a.windowed,"parle-note")),a.index!==null&&t.appendChild(D(a.index,"parle-note")),e.appendChild(t),(a.restraint===null||a.restraint.kind!=="undecided")&&e.appendChild(ge(a,r))},be=`
:host,
.parle, .parle-pill, .parle-dock {
  --parle-font: -apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif;
  --parle-t-meta: 11px;
  --parle-t-body: 13px;
  --parle-t-lead: 15px;
  --parle-t-head: 18px;
  --parle-1: 4px;
  --parle-2: 8px;
  --parle-3: 12px;
  --parle-4: 16px;
  --parle-5: 24px;
  --parle-r: 10px;
  --parle-r-sm: 6px;
  --parle-r-full: 999px;
  --parle-bg: #ffffff;
  --parle-raise: #f4f5f7;
  --parle-ink: #14161a;
  --parle-mid: #5b6270;
  --parle-faint: #6f7683;
  --parle-line: rgba(20, 22, 26, 0.1);
  --parle-rule: rgba(20, 22, 26, 0.2);
  --parle-accent: #1a6fdb;
  --parle-on-accent: #ffffff;
  --parle-warn: #7a5200;
  --parle-stop: #99291c;
  --parle-lift: 0 1px 2px rgba(10, 12, 16, 0.06), 0 10px 32px rgba(10, 12, 16, 0.14);
  --parle-motion: cubic-bezier(0.2, 0.75, 0.3, 1);
}
@media (prefers-color-scheme: dark) {
  :host,
  .parle, .parle-pill, .parle-dock {
    --parle-bg: #101216;
    --parle-raise: #191c22;
    --parle-ink: #e8eaef;
    --parle-mid: #a2a9b6;
    --parle-faint: #8b929f;
    --parle-line: rgba(232, 234, 239, 0.11);
    --parle-rule: rgba(232, 234, 239, 0.24);
    --parle-accent: #6eb0ff;
    --parle-on-accent: #0a1628;
    --parle-warn: #e0bd76;
    --parle-stop: #f0a396;
    --parle-lift: 0 1px 2px rgba(0, 0, 0, 0.4), 0 10px 32px rgba(0, 0, 0, 0.5);
  }
}

/* the phone scale */
@media (max-width: 639px) {
  :host,
  .parle, .parle-pill, .parle-dock {
    --parle-t-meta: 12px;
    --parle-t-body: 15px;
    --parle-t-lead: 17px;
  }
}

/* reset \u2014 nothing inherits from the page this is drawn on */
.parle, .parle-pill, .parle-dock {
  all: initial;
  color-scheme: light dark;
  font-family: var(--parle-font);
  font-size: var(--parle-t-body);
  line-height: 1.5;
  color: var(--parle-ink);
  -webkit-font-smoothing: antialiased;
  box-sizing: border-box;
}
.parle *, .parle *::before, .parle *::after,
.parle-pill *, .parle-pill::before, .parle-pill::after,
.parle-dock * { box-sizing: border-box; }
.parle a { color: inherit; text-decoration: none; }
.parle :focus-visible,
.parle-pill:focus-visible, .parle-close:focus-visible, .parle-pin:focus-visible {
  outline: 2px solid var(--parle-accent);
  outline-offset: 2px;
  border-radius: var(--parle-r-sm);
}

/* the panel */
.parle { display: flex; flex-direction: column; background: var(--parle-bg); }
.parle-head { flex: none; padding: var(--parle-4) var(--parle-4) var(--parle-2); }
.parle-heading {
  margin: 0 0 2px;
  font-size: var(--parle-t-lead);
  font-weight: 600;
  letter-spacing: -0.01em;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.parle-address {
  font-size: var(--parle-t-meta);
  color: var(--parle-faint);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.parle-body {
  padding: 0 var(--parle-3) var(--parle-3);
  max-height: 420px;
  overflow-y: auto;
  overscroll-behavior: contain;
}
.parle-compact { min-height: 0; }
.parle-compact .parle-body {
  padding: 10px 16px 8px;
  flex: 1 1 auto;
  min-height: 0;
  max-height: none;
}
.parle-dock .parle { flex: 1 1 auto; min-height: 0; }
.parle-dock .parle-body {
  max-height: none;
  flex: 1 1 auto;
  min-height: 0;
  /*
   * A thin scrollbar, and its gutter reserved whether or not it is showing.
   *
   * The dock is a fixed 320-420px column, and Chrome's classic scrollbar takes
   * about 15px of it. Without a stable gutter it appears only once the content
   * overflows, so the whole column shifts left the moment a discussion is long
   * enough \u2014 and the close button, which is positioned against the dock rather
   * than against the scrolling content, does not shift with it. The result is
   * the header's controls sitting flush to the panel edge while every line
   * beneath them stops 15px short, which is exactly the misalignment visible in
   * store screenshot 01.
   */
  scrollbar-width: thin;
  scrollbar-gutter: stable;
}
.parle-dock .parle-compact { height: 100%; }
.parle-main { min-width: 0; }
.parle-extras { margin-top: var(--parle-3); }

/* discussions \u2014 Linked room vs Passing list, never blended */
.parle-group { margin: var(--parle-4) 0 0; }
.parle-group:first-child { margin-top: 0; }
.parle-group-name {
  margin: 0 0 var(--parle-2);
  font-size: var(--parle-t-meta);
  letter-spacing: 0.07em;
  text-transform: uppercase;
  font-weight: 700;
  color: var(--parle-mid);
}
.parle-group-note {
  display: block;
  margin-top: 2px;
  font-size: var(--parle-t-meta);
  color: var(--parle-faint);
  font-weight: 400;
  text-transform: none;
  letter-spacing: 0;
}
.parle-group-linked .parle-group-name { color: var(--parle-accent); }
.parle-row {
  display: block;
  padding: var(--parle-2) var(--parle-3);
  margin: 0 0 var(--parle-1);
  border-radius: var(--parle-r-sm);
  background: var(--parle-raise);
  transition: background 160ms var(--parle-motion);
}
.parle-row:hover { background: var(--parle-line); }
.parle-group-passing .parle-row { box-shadow: inset 2px 0 0 var(--parle-rule); }
.parle-title { display: block; font-weight: 500; margin-bottom: 2px; }
.parle a:hover .parle-title { text-decoration: underline; }
.parle-facts {
  display: flex;
  gap: var(--parle-2);
  flex-wrap: wrap;
  font-size: var(--parle-t-meta);
  color: var(--parle-faint);
}
.parle-network { font-weight: 600; color: var(--parle-mid); }
.parle-repeat { font-style: italic; }

/*
 * Compact open room \u2014 comments first. Network identity lives on the bottom
 * nav icon; Parle's shell stays neutral. Subtle guides only.
 */
.parle-room { margin: 0; }
.parle-room-title {
  display: -webkit-box;
  margin: 0;
  padding: 2px 0 8px;
  overflow: hidden;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 2;
  color: var(--parle-ink);
  font-size: var(--parle-t-body);
  font-weight: 650;
  line-height: 1.35;
}
.parle-room-title:hover { text-decoration: underline; }
.parle-room-repeat {
  padding: 3px 0 5px;
  border-bottom: 1px solid var(--parle-line);
  color: var(--parle-faint);
  font-size: var(--parle-t-meta);
}
.parle-thread-picks {
  display: flex;
  gap: 6px;
  overflow-x: auto;
  margin: 0 0 8px;
  scrollbar-width: none;
}
.parle-thread-picks::-webkit-scrollbar { display: none; }
.parle-thread-pick {
  flex: none;
  max-width: 10em;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  border: 0;
  border-radius: 999px;
  padding: 4px 10px;
  background: var(--parle-raise);
  color: var(--parle-mid);
  font: 600 11px/1 var(--parle-font);
  cursor: pointer;
}
.parle-thread-pick-on {
  background: var(--parle-accent);
  color: var(--parle-on-accent);
}

.parle-home .parle-comments {
  margin: 0;
  padding: 0;
  border-left: 0;
}
.parle-home .parle-comment {
  margin: 0;
  padding: 9px 0;
  border-bottom: 1px solid var(--parle-line);
  border-left: 0;
}
.parle-home .parle-comment:last-child { border-bottom: 0; }
.parle-home .parle-replies {
  margin: 7px 0 0;
  padding: 0 0 0 12px;
  border-left: 1.5px solid var(--parle-line);
}
.parle-room[data-network="hackernews"] {
  --parle-guide: #ff6600;
}
.parle-room[data-network="reddit"] {
  --parle-guide: #ff4500;
}
.parle-room[data-network="x"] {
  --parle-guide: #536471;
}
.parle-room[data-network] .parle-replies {
  border-left-color: color-mix(in srgb, var(--parle-guide) 48%, transparent);
}
.parle-room[data-network] .parle-comment-who { color: var(--parle-guide); font-weight: 700; }
.parle-room[data-network="x"] .parle-comment {
  border-left: 0;
  padding-left: 0;
}
.parle-room[data-network="x"] .parle-comment-who {
  color: var(--parle-ink);
  font-weight: 800;
}

/*
 * Adaptive nav \u2014 ~32px icon row. Counts are iOS-style badges on the icon's
 * top-right and do not add layout height. Settings sits apart on the right.
 *
 * Bottom is the default because the default has to be right on touch devices,
 * including a wide iPad. A desktop page with a precise pointing device moves
 * it above the conversation.
 *
 * There used to be a third case: browser-owned side panels carried a
 * parle-native class, because a ~400px sidebar document is desktop chrome
 * rather than a phone and width alone misclassified it. Chrome no longer has
 * one \u2014 the side panel is gone and the in-page dock is the only surface \u2014 so
 * the class and its rules went with it. The dock IS the surface desktop Safari
 * has, which is why the clearance below is not optional.
 */
.parle-nav-slot { flex: none; }
.parle-nav {
  display: flex;
  align-items: center;
  gap: 4px;
  min-height: calc(34px + env(safe-area-inset-bottom, 0px));
  padding: 3px 12px calc(3px + env(safe-area-inset-bottom, 0px));
  border-top: 1px solid var(--parle-line);
  background: var(--parle-bg);
}
.parle-nav-strip {
  display: flex;
  align-items: center;
  gap: 4px;
  flex: 1 1 auto;
  min-width: 0;
  overflow-x: auto;
  scrollbar-width: none;
}
.parle-nav-strip::-webkit-scrollbar { display: none; }
.parle-nav-item {
  position: relative;
  flex: none;
  width: 40px;
  height: 27px;
  display: inline-grid;
  place-items: center;
  border: 0;
  border-radius: 8px;
  background: transparent;
  color: var(--parle-mid);
  cursor: pointer;
  padding: 0;
}
.parle-nav-item:hover { background: var(--parle-raise); color: var(--parle-ink); }
.parle-nav-on { color: var(--parle-accent); }
.parle-nav-on::after {
  content: "";
  position: absolute;
  left: 12px;
  right: 12px;
  bottom: 0;
  height: 2px;
  border-radius: 999px;
  background: var(--parle-accent);
}
.parle-nav-icon {
  position: relative;
  display: inline-grid;
  place-items: center;
  width: 20px;
  height: 20px;
  overflow: visible;
}
.parle-nav-mark,
.parle-tab-mark {
  display: inline-grid;
  place-items: center;
  width: 20px;
  height: 20px;
  border-radius: 4px;
  overflow: hidden;
  color: inherit;
}
.parle-nav-mark svg,
.parle-tab-mark svg { display: block; width: 20px; height: 20px; }
.parle-nav-badge {
  position: absolute;
  top: -5px;
  right: -9px;
  z-index: 1;
  min-width: 12px;
  height: 12px;
  padding: 0 2.5px;
  border-radius: 999px;
  background: #ff3b30;
  color: #ffffff;
  font: 700 8px/12px var(--parle-font);
  font-variant-numeric: tabular-nums;
  text-align: center;
  box-shadow: 0 0 0 1.5px var(--parle-bg);
  pointer-events: none;
}
.parle-nav-soon {
  position: absolute;
  top: -3px;
  right: -4px;
  width: 6px;
  height: 6px;
  border-radius: 999px;
  background: var(--parle-accent);
  box-shadow: 0 0 0 1.5px var(--parle-bg);
  pointer-events: none;
}
.parle-nav-utilities {
  display: flex;
  align-items: center;
  flex: none;
  margin-left: 4px;
  padding-left: 5px;
  box-shadow: -1px 0 0 var(--parle-line);
}
.parle-nav-settings { width: 32px; color: var(--parle-mid); }
.parle-nav-settings svg { display: block; width: 16px; height: 16px; }
.parle-nav-settings::after { display: none; }

@media (min-width: 640px) and (hover: hover) and (pointer: fine) {
  .parle-compact .parle-nav-slot { order: -1; }
  .parle-compact .parle-nav {
    min-height: var(--parle-nav-h, 34px);
    padding: 3px 12px;
    border-top: 0;
    border-bottom: 1px solid var(--parle-line);
  }
  /*
   * Only inside this query does the navigation sit at the top, so only here can
   * the close button be centred on it. Outside it \u2014 touch, coarse pointer, a
   * narrow window \u2014 the row is the footer at the bottom of the column, and a
   * button positioned against the top of the dock has nothing to align with.
   * Coupling the two unconditionally made the alignment a property of the
   * viewport rather than of the stylesheet: measured on a non-matching display,
   * the same build gave close 1..33 against nav 766..800.
   */
  .parle-dock .parle-close,
  .parle-dock .parle-pin {
    top: calc(
      env(safe-area-inset-top, 0px) + (var(--parle-nav-h) - var(--parle-close-size)) / 2
    );
  }

  /*
   * The in-page dock owns an absolute close button in this corner, and the
   * clearance is derived from where that button actually is rather than from a
   * number that happened to work. When the close button moved left to clear the
   * scroll gutter, a fixed 48px left Settings overlapping it by 2px \u2014 caught by
   * the e2e box assertion, which is why that assertion exists.
   */
  .parle-dock .parle-compact .parle-nav {
    /* Two positioned buttons to clear now \u2014 the pin sits one slot left of the
       close, so the clearance is a close-width and a gap wider than it was. */
    padding-right: calc(86px + var(--parle-scroll-gutter, 0px));
  }
}

/* A Discussion's own words. */
.parle-open {
  border: 0; background: transparent; cursor: pointer; font: inherit;
  color: var(--parle-accent); padding: 0; text-decoration: underline;
}
.parle-comments {
  margin: var(--parle-1) 0 var(--parle-2) var(--parle-2);
  padding-left: var(--parle-2);
  border-left: 2px solid var(--parle-line);
}
.parle-comments-tools {
  display: flex; align-items: center; gap: var(--parle-3);
  min-height: 32px;
  margin-bottom: 0;
  border-bottom: 1px solid var(--parle-line);
}
.parle-comments-mode, .parle-comments-collapse, .parle-comment-more, .parle-comments-more,
.parle-comments-open {
  border: 0; background: transparent; cursor: pointer; font: inherit;
  color: var(--parle-accent); padding: 0; text-decoration: none;
  font-size: var(--parle-t-meta); font-weight: 600;
}
.parle-comments-mode {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  flex: none;
  color: var(--parle-ink);
}
.parle-comments-mode svg { display: block; width: 15px; height: 15px; color: var(--parle-mid); }
.parle-comments-chevron { color: var(--parle-faint); font-size: 10px; transform: translateY(-1px); }
.parle-comments-collapse { color: var(--parle-accent); font-weight: 500; }
.parle-comments-collapse:hover { color: var(--parle-ink); }
.parle-comments-spacer { flex: 1 1 auto; }
.parle-comments-open,
.parle-comments-more-actions {
  display: inline-grid;
  place-items: center;
  width: 24px;
  height: 24px;
  color: var(--parle-mid);
}
.parle-comments-open:hover,
.parle-comments-more-actions:hover { color: var(--parle-ink); }
.parle-comments-open svg,
.parle-comments-more-actions svg { display: block; width: 14px; height: 14px; }
.parle-comments-menu-wrap { position: relative; display: inline-grid; }
.parle-comments-menu {
  position: absolute;
  z-index: 2;
  top: 26px;
  right: 0;
  min-width: 150px;
  padding: 4px;
  border: 1px solid var(--parle-line);
  border-radius: 8px;
  background: var(--parle-bg);
  box-shadow: var(--parle-lift);
}
.parle-comments-menu[hidden] { display: none; }
.parle-comments-menu-item {
  display: block;
  width: 100%;
  border: 0;
  border-radius: 5px;
  padding: 6px 8px;
  background: transparent;
  color: var(--parle-ink);
  font: 500 var(--parle-t-meta)/1.3 var(--parle-font);
  text-align: left;
  cursor: pointer;
}
.parle-comments-menu-item:hover { background: var(--parle-raise); }
.parle-comments-more { margin: var(--parle-1) 0 var(--parle-2); text-decoration: underline; }
.parle-comment { margin-bottom: var(--parle-2); min-width: 0; }
.parle-comment-who { color: var(--parle-mid); font-size: var(--parle-t-meta); }
.parle-comment-age { margin-left: var(--parle-1); color: var(--parle-faint); font-weight: 400; }
.parle-comment-text {
  margin: 2px 0 0; white-space: pre-wrap; overflow-wrap: anywhere;
  line-height: 1.45;
}
.parle-comment-more {
  display: inline-flex;
  align-items: center;
  gap: 3px;
  min-height: 22px;
  margin-top: 2px;
  font-size: var(--parle-t-meta);
  color: var(--parle-mid);
}
.parle-comment-more::before {
  content: "\u203A";
  font-size: 14px;
  line-height: 1;
  color: var(--parle-guide, var(--parle-faint));
}
.parle-replies {
  margin: var(--parle-2) 0 0 var(--parle-2);
  padding-left: var(--parle-2);
  border-left: 2px solid var(--parle-line);
}
.parle-comments-note { color: var(--parle-mid); font-size: var(--parle-t-meta); margin: 0; }

/* a site's front door: what was set aside, and the one click that opens it.
   Quiet rather than warning-coloured \u2014 nothing has gone wrong here, and the
   product's own rule is that a suppression must read as a decision the reader
   can reverse rather than as an error they have to interpret. */
.parle-folded {
  margin: var(--parle-3) 0 0;
  padding: var(--parle-3);
  border-radius: var(--parle-r-sm);
  background: var(--parle-raise);
}
.parle-folded-says {
  margin: 0 0 var(--parle-2);
  font-size: var(--parle-t-meta);
  color: var(--parle-mid);
}
.parle-act-folded { font-size: var(--parle-t-meta); padding: var(--parle-1) var(--parle-3); }
.parle-folded-rows { margin-top: var(--parle-2); }
.parle-folded-rows .parle-row { background: var(--parle-bg); }

/* tones \u2014 six states, six inks, no washes (ADR 0011) */
.parle-tone-refused { color: var(--parle-stop); }
.parle-tone-garbled { color: var(--parle-warn); }
.parle-tone-withheld, .parle-tone-waiting, .parle-tone-quiet { color: var(--parle-mid); }
.parle-tone-found { color: var(--parle-accent); }
.parle-notice {
  display: flex;
  justify-content: space-between;
  gap: var(--parle-2);
  margin: var(--parle-2) 0 0;
  padding: var(--parle-2) var(--parle-3);
  border-radius: var(--parle-r-sm);
  background: var(--parle-raise);
  font-size: var(--parle-t-meta);
}
.parle-said { margin: var(--parle-3) 0; color: var(--parle-mid); }
.parle-restraint { margin: var(--parle-3) 0 var(--parle-4); color: var(--parle-mid); }
.parle-restraint-says { margin: 0 0 var(--parle-3); color: var(--parle-ink); }

/* actions \u2014 outlined, so a button is a button on whatever it sits on */
.parle-act {
  all: unset;
  display: inline-block;
  cursor: pointer;
  font-family: var(--parle-font);
  font-size: var(--parle-t-body);
  font-weight: 550;
  padding: var(--parle-2) var(--parle-4);
  border-radius: var(--parle-r-full);
  color: var(--parle-ink);
  background: var(--parle-bg);
  box-shadow: inset 0 0 0 1px var(--parle-rule);
  transition: background 160ms var(--parle-motion), opacity 160ms var(--parle-motion);
}
.parle-act:hover { background: var(--parle-raise); }
.parle-act-strong {
  background: var(--parle-accent);
  color: var(--parle-on-accent);
  box-shadow: none;
}
.parle-act-strong:hover { background: var(--parle-accent); opacity: 0.88; }
.parle-link {
  all: unset;
  cursor: pointer;
  font-family: var(--parle-font);
  font-size: var(--parle-t-meta);
  color: var(--parle-mid);
  transition: color 160ms var(--parle-motion);
}
.parle-link:hover { color: var(--parle-ink); text-decoration: underline; }
.parle-note { margin: var(--parle-4) 0 0; font-size: var(--parle-t-meta); color: var(--parle-mid); }
/* the footer \u2014 rows declared, never wrapped into */
.parle-footer {
  flex: none;
  display: flex;
  flex-direction: column;
  gap: var(--parle-2);
  border-top: 1px solid var(--parle-line);
  padding: var(--parle-3) var(--parle-4);
  font-size: var(--parle-t-meta);
  color: var(--parle-faint);
}
.parle-footer-row {
  display: flex;
  align-items: center;
  gap: var(--parle-3);
  flex-wrap: wrap;
}
.parle-footer-state { margin-right: auto; color: var(--parle-mid); }

/* the account of every place we asked \u2014 the toolbar surface's whole job */
.parle-coverage { margin: var(--parle-4) 0 0; }
.parle-coverage-name {
  margin: 0 0 var(--parle-1);
  font-size: var(--parle-t-meta);
  letter-spacing: 0.07em;
  text-transform: uppercase;
  font-weight: 700;
  color: var(--parle-faint);
}
.parle-account {
  display: flex;
  justify-content: space-between;
  gap: var(--parle-3);
  padding: var(--parle-1) 0;
  font-size: var(--parle-t-meta);
  color: var(--parle-mid);
}
.parle-account-place { color: var(--parle-mid); }
.parle-account-waiting { color: var(--parle-faint); }
.parle-account-refused { color: var(--parle-stop); }
.parle-account-garbled { color: var(--parle-warn); }
.parle-account-found { color: var(--parle-accent); }

/* digest */
.parle-digest {
  margin: var(--parle-4) 0 0;
  padding: var(--parle-3);
  border-radius: var(--parle-r);
  background: var(--parle-raise);
  color: var(--parle-mid);
}
.parle-compact .parle-digest { margin-top: 0; }
.parle-digest-title { margin: 0 0 var(--parle-2); font-size: var(--parle-t-body); font-weight: 600; color: var(--parle-ink); }
.parle-digest-says { margin: 0 0 var(--parle-2); }
.parle-digest-partial { margin: var(--parle-2) 0 0; font-size: var(--parle-t-meta); }
.parle-digest-wrote { margin: var(--parle-2) 0 0; font-size: var(--parle-t-meta); color: var(--parle-faint); }
.parle-act-digest { margin-top: var(--parle-1); }
.parle-finding { margin: 0 0 var(--parle-3); }
.parle-finding:last-of-type { margin-bottom: 0; }
.parle-finding-says { margin: 0 0 var(--parle-1); color: var(--parle-ink); }
/* disputed: the neutral ink, never the accent and never a warning (ADR 0006) */
.parle-finding-disputed { box-shadow: inset 2px 0 0 var(--parle-rule); padding-left: var(--parle-3); }
.parle-disputed {
  display: block;
  margin-bottom: 2px;
  font-size: var(--parle-t-meta);
  text-transform: uppercase;
  letter-spacing: 0.05em;
  color: var(--parle-faint);
}
/* citations: underlined always, because they are meant to be followed (ADR 0006) */
.parle-sources { display: flex; flex-wrap: wrap; gap: var(--parle-1) var(--parle-3); }
.parle a.parle-source {
  font-size: var(--parle-t-meta);
  color: var(--parle-mid);
  text-decoration: underline;
  text-underline-offset: 2px;
  text-decoration-thickness: 1px;
  cursor: pointer;
}
.parle a.parle-source:hover { color: var(--parle-ink); }
.parle-spinner {
  display: inline-block;
  width: 6px;
  height: 6px;
  border-radius: var(--parle-r-full);
  background: currentColor;
  margin-right: var(--parle-2);
  vertical-align: middle;
  animation: parle-pulse 1.4s var(--parle-motion) infinite;
}
@keyframes parle-pulse { 0%, 100% { opacity: 0.25; } 50% { opacity: 1; } }

/* the mark \u2014 parked by the reader, only when there is something, still after it arrives */
.parle-pill {
  position: fixed;
  top: var(--parle-4);
  left: auto;
  right: var(--parle-4);
  z-index: 2147483646;
  display: grid;
  place-items: center;
  min-width: 36px;
  height: 36px;
  padding: 4px;
  border: 0;
  border-radius: var(--parle-r-full);
  background: var(--parle-bg);
  color: var(--parle-ink);
  box-shadow: var(--parle-lift), inset 0 0 0 1px var(--parle-line);
  cursor: grab;
  touch-action: none;
  user-select: none;
  font-family: var(--parle-font);
  font-size: var(--parle-t-meta);
  font-weight: 650;
  transition: transform 160ms var(--parle-motion), box-shadow 160ms var(--parle-motion);
  animation: parle-arrive 420ms var(--parle-motion) both;
}
.parle-pill:hover { transform: scale(1.05); }
.parle-pill[data-dragging="1"] {
  cursor: grabbing;
  transform: scale(1.08);
  box-shadow: var(--parle-lift), inset 0 0 0 1px var(--parle-accent);
  transition: none;
}
.parle-pill[hidden], .parle-pill[data-found="0"] { display: none; }
.parle-pill svg, .parle-close svg { display: block; width: 16px; height: 16px; }
.parle-pill svg:not([fill]), .parle-close svg:not([fill]) { fill: currentColor; }
.parle-stack {
  display: flex;
  flex-direction: row;
  align-items: center;
}
.parle-stack-disc {
  display: grid;
  place-items: center;
  width: 28px;
  height: 28px;
  border-radius: var(--parle-r-full);
  background: var(--parle-bg);
  box-shadow: 0 0 0 2px var(--parle-bg);
  overflow: hidden;
}
.parle-stack-disc + .parle-stack-disc { margin-left: -10px; }
.parle-stack-disc svg { width: 28px; height: 28px; }
.parle-stack-parle {
  color: var(--parle-ink);
  background: var(--parle-raise);
}
.parle-stack-parle svg { width: 16px; height: 16px; }
.parle-pill-count {
  position: absolute;
  top: -4px;
  right: -4px;
  min-width: 18px;
  height: 18px;
  padding: 0 5px;
  border-radius: var(--parle-r-full);
  background: var(--parle-accent);
  color: var(--parle-on-accent);
  font-size: 10px;
  font-weight: 700;
  line-height: 18px;
  text-align: center;
  box-shadow: 0 0 0 2px var(--parle-bg);
}
.parle-pill-count:empty { display: none; }
/* the announcement: one ring, outward, once */
.parle-pill::after {
  content: "";
  position: absolute;
  inset: -2px;
  border-radius: var(--parle-r-full);
  border: 2px solid var(--parle-accent);
  pointer-events: none;
  animation: parle-ring 1100ms var(--parle-motion) 1 both;
}
@keyframes parle-arrive {
  from { opacity: 0; transform: translateY(-6px) scale(0.8); }
  to { opacity: 1; transform: none; }
}
@keyframes parle-ring {
  from { opacity: 0.55; transform: scale(1); }
  to { opacity: 0; transform: scale(2.1); }
}

/* the surface \u2014 full screen under 640px, docked right at and above it */
.parle-dock {
  --parle-scroll-gutter: 10px;
  --parle-nav-h: 34px;
  --parle-close-size: 32px;
  position: fixed;
  inset: 0;
  z-index: 2147483647;
  display: flex;
  flex-direction: column;
  background: var(--parle-bg);
  box-shadow: var(--parle-lift);
  overscroll-behavior: contain;
  padding-top: env(safe-area-inset-top, 0px);
  padding-bottom: env(safe-area-inset-bottom, 0px);
  animation: parle-open 180ms var(--parle-motion) both;
}
@keyframes parle-open { from { opacity: 0; } to { opacity: 1; } }
@media (min-width: 640px) {
  .parle-dock { inset: 0 0 0 auto; width: clamp(320px, 30vw, 420px); padding-bottom: 0; }
}
/* the way out of the surface, drawn as a button */
.parle-close {
  all: unset;
  position: absolute;
  /*
   * The default: a plain offset from the top of the dock.
   *
   * This button is a child of .parle-dock, not of the row it appears to sit
   * beside, so it is positioned rather than laid out \u2014 and the row it appears
   * to sit beside is not always there. Navigation is only the header inside the
   * pointer-driven desktop query below; on touch and coarse-pointer surfaces it
   * is the footer at the bottom of the column, and a button aligned to it would
   * be aligned to nothing. Centring on the row therefore lives inside that
   * query, not here.
   */
  top: calc(env(safe-area-inset-top, 0px) + var(--parle-2));
  /* Clears the scroll gutter below it so the panel has one right edge. */
  right: calc(var(--parle-2) + var(--parle-scroll-gutter, 0px));
  z-index: 1;
  display: grid;
  place-items: center;
  width: var(--parle-close-size);
  height: var(--parle-close-size);
  border-radius: var(--parle-r-full);
  background: var(--parle-raise);
  cursor: pointer;
  font-family: var(--parle-font);
  font-size: var(--parle-t-head);
  line-height: 1;
  color: var(--parle-mid);
  transition: background 160ms var(--parle-motion), color 160ms var(--parle-motion);
}
.parle-close:hover { background: var(--parle-line); color: var(--parle-ink); }
/*
 * The pin: the close button's twin, one slot to its left. It shares the close
 * button's positioning story completely \u2014 a child of the dock, positioned
 * rather than laid out, centred on the navigation row only inside the query
 * that makes that row the header \u2014 so every rule below mirrors .parle-close
 * with one more button-width of right offset.
 */
.parle-pin {
  all: unset;
  position: absolute;
  top: calc(env(safe-area-inset-top, 0px) + var(--parle-2));
  right: calc(var(--parle-2) + var(--parle-scroll-gutter, 0px) + var(--parle-close-size) + 6px);
  z-index: 1;
  display: grid;
  place-items: center;
  width: var(--parle-close-size);
  height: var(--parle-close-size);
  border-radius: var(--parle-r-full);
  background: var(--parle-raise);
  cursor: pointer;
  color: var(--parle-mid);
  transition: background 160ms var(--parle-motion), color 160ms var(--parle-motion);
}
.parle-pin:hover { background: var(--parle-line); color: var(--parle-ink); }
.parle-pin[aria-pressed="true"] { background: var(--parle-line); color: var(--parle-accent); }
.parle-pin svg { display: block; width: 15px; height: 15px; }
.parle-pin svg:not([fill]) { fill: currentColor; }
/* Two positioned controls to clear now \u2014 the pin sits one slot left of close. */
.parle-dock .parle-head { padding-right: 90px; }
@media (max-width: 639px) {
  /* The surface is the whole screen here \u2014 there is no page beside it to pin. */
  .parle-pin { display: none; }
  .parle-close {
    top: calc(env(safe-area-inset-top, 0px) + var(--parle-3));
    right: var(--parle-3);
    width: 40px;
    height: 40px;
  }
  .parle-dock .parle-head { padding-right: 64px; padding-top: var(--parle-5); }
  .parle-dock .parle-heading {
    white-space: normal;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
  }
}

@media (prefers-reduced-motion: reduce) {
  .parle, .parle *,
  .parle-pill, .parle-pill::after,
  .parle-dock, .parle-close, .parle-pin { animation: none !important; transition: none !important; }
  .parle-pill::after { opacity: 0; }
}
`,P=document.createElement("style");P.textContent=be;document.head.appendChild(P);const S=document.getElementById("panel");if(S!==null){let e=null;const a=()=>{e!==null&&ve(S,e,t)},r=W(_,n=>{n._tag==="Standing"&&(e=n.panel,a())}),t={openOut:n=>r.say(U(n)),lookAnyway:()=>r.say(K()),summarise:()=>r.say(H()),readDiscussion:n=>r.say(Y(n)),decide:n=>r.say(G(n)),openDisclosure:()=>r.say(F()),openSettings:()=>r.say(B()),pauseSite:n=>r.say(q(n)),resumeSite:n=>r.say(j(n))};S.textContent="Looking\u2026",r.say(I(null),!0)}
