(function(){"use strict";function Gt(e){return e}const q=globalThis.browser?.runtime?.id?globalThis.browser:globalThis.chrome,ye={x:1,y:0},te=e=>Math.min(1,Math.max(0,e)),Ce=(e,t)=>({x:te(e),y:te(t)}),Se=e=>{if(typeof e!="object"||e===null)return!1;const t=e;return typeof t.x=="number"&&Number.isFinite(t.x)&&typeof t.y=="number"&&Number.isFinite(t.y)},Ae=(e,t,r,a=16)=>{const n=Math.max(a,r.width-t-a),p=Math.max(a,r.height-t-a);return{left:Math.round(a+e.x*(n-a)),top:Math.round(a+e.y*(p-a))}},Ee=(e,t,r,a,n=16)=>{const p=Math.max(n,a.width-r-n),d=Math.max(n,a.height-r-n),i=Math.max(1,p-n),u=Math.max(1,d-n);return Ce((e-n)/i,(t-n)/u)},Ne="parle-pill",Le=e=>({_tag:"Watch",tabId:e}),Me=(e,t,r)=>({_tag:"Sighted",address:e,title:t,referrer:r}),$e=e=>({_tag:"OpenOut",address:e}),Te=()=>({_tag:"LookAnyway"}),_e=()=>({_tag:"Summarise"}),ze=e=>({_tag:"ReadDiscussion",key:e}),Oe=e=>({_tag:"Decide",automatic:e}),Pe=()=>({_tag:"OpenDisclosure"}),De=()=>({_tag:"OpenAside"}),Ie=e=>({_tag:"PauseSite",host:e}),Re=e=>({_tag:"ResumeSite",host:e}),We=()=>({_tag:"OpenSettings"}),Fe=e=>({_tag:"ParkMark",park:e}),Ge=(e,t,r,a)=>({_tag:"Standing",tabId:e,panel:t,aside:r,markPark:a}),Ve=e=>({_tag:"Told",decision:e}),Ue=e=>({_tag:"AsideVisibility",open:e}),He=e=>typeof e=="object"&&e!==null&&"_tag"in e&&typeof e._tag=="string"?e._tag:null,Ye=e=>e==="undecided"||e==="automatic"||e==="manual",je=e=>e==="native"||e==="in-page",qe=e=>{switch(He(e)){case"Standing":{const t=e;if(typeof t.tabId!="number")return null;const r=t.panel;if(typeof r!="object"||r===null||!Array.isArray(r.linked)||!Array.isArray(r.accounts)||!je(t.aside))return null;const a=Se(t.markPark)?t.markPark:{x:1,y:0};return Ge(t.tabId,r,t.aside,a)}case"Told":{const t=e.decision;return Ye(t)?Ve(t):null}case"AsideVisibility":{const t=e.open;return typeof t=="boolean"?Ue(t):null}default:return null}},Be=400,Ke=(e,t)=>{let r=null,a=!1;const n=[],p=i=>{if(r===null)return!1;try{return r.postMessage(i),!0}catch{return!1}},d=()=>{if(!a){r=q.runtime.connect({name:e}),r.onMessage.addListener(i=>{const u=qe(i);u!==null&&t(u)}),r.onDisconnect.addListener(()=>{r=null,a||setTimeout(d,Be)});for(const i of n)p(i)}};return d(),{say:(i,u=!1)=>(u&&n.push(i),p(i)),close:()=>{a=!0;try{r?.disconnect()}catch{}r=null}}},re=32,Xe=(e,t,r)=>{if(r<=t)return null;const a=e.slice(t,r);return a.trim()===""?null:{exact:a,prefix:e.slice(Math.max(0,t-re),t),suffix:e.slice(r,r+re),wasAt:t}},Qe=e=>{const t=()=>{const r=document.getSelection();if(r===null||r.isCollapsed||r.rangeCount===0)return;const a=r.toString(),n=document.body.textContent??"",p=n.indexOf(a);e(p===-1?{exact:a,prefix:"",suffix:"",wasAt:0}:Xe(n,p,p+a.length))};return document.addEventListener("selectionchange",t,{passive:!0}),()=>document.removeEventListener("selectionchange",t)},I="http://www.w3.org/2000/svg",N=e=>{const t=document.createElementNS(I,"svg");return t.setAttribute("viewBox",e),t.setAttribute("aria-hidden","true"),t},L=(e,t)=>{const r=document.createElementNS(I,"path");return r.setAttribute("d",e),t!==void 0&&r.setAttribute("fill",t),r},Ze=(e,t,r,a,n,p)=>{const d=document.createElementNS(I,"rect");return d.setAttribute("x",String(e)),d.setAttribute("y",String(t)),d.setAttribute("width",String(r)),d.setAttribute("height",String(a)),d.setAttribute("rx",String(n)),d.setAttribute("fill",p),d},P=(e,t,r,a)=>{const n=document.createElementNS(I,"circle");return n.setAttribute("cx",String(e)),n.setAttribute("cy",String(t)),n.setAttribute("r",String(r)),n.setAttribute("fill",a),n},Je=()=>{const e=N("0 0 16 16");return e.appendChild(L("M8 1.6c-3.6 0-6.5 2.3-6.5 5.2 0 1.7 1 3.2 2.5 4.1L3.3 14l3.2-1.7c.5.1 1 .1 1.5.1 3.6 0 6.5-2.3 6.5-5.2S11.6 1.6 8 1.6z")),e},et=()=>{const e=N("0 0 16 16");return e.appendChild(Ze(0,0,16,16,2.5,"#ff6600")),e.appendChild(L("M4.2 3.2h1.7l2.1 4.1 2.1-4.1h1.7L8.9 8.6V12.8H7.1V8.6L4.2 3.2z","#ffffff")),e},tt=()=>{const e=N("0 0 16 16");e.appendChild(P(8,8,8,"#ff4500"));const t=document.createElementNS(I,"text");return t.setAttribute("x","8"),t.setAttribute("y","11.2"),t.setAttribute("text-anchor","middle"),t.setAttribute("fill","#ffffff"),t.setAttribute("font-size","7.5"),t.setAttribute("font-weight","700"),t.setAttribute("font-family","Verdana, Geneva, sans-serif"),t.textContent="r/",e.appendChild(t),e},rt=()=>{const e=N("0 0 16 16");return e.appendChild(P(8,8,8,"#0f1419")),e.appendChild(L("M4.1 4.1h2.05l1.7 2.35L10.05 4.1H12l-2.85 3.55L12.2 11.9h-2.05l-1.95-2.6-2.2 2.6H4l3.1-3.7L4.1 4.1z","#ffffff")),e},ae=e=>{switch(e){case"hackernews":return et();case"reddit":return tt();case"x":return rt()}},ne={hackernews:"HN",reddit:"Reddit",x:"X"},B=e=>{const t=new Set;for(const r of e)t.add(r.network);return["hackernews","reddit","x"].filter(r=>t.has(r))},oe=e=>{const t=document.createElement("span");if(t.className="parle-stack",t.dataset.count=String(Math.max(e.length,1)),e.length===0){const r=document.createElement("span");return r.className="parle-stack-disc parle-stack-parle",r.appendChild(Je()),t.appendChild(r),t}for(const r of[...e].reverse()){const a=document.createElement("span");a.className=`parle-stack-disc parle-stack-${r}`,a.appendChild(ae(r)),t.appendChild(a)}return t},at=e=>{const t=document.createElement("span");return t.className=`parle-tab-mark parle-tab-mark-${e}`,t.appendChild(ae(e)),t},nt=()=>{const e=N("0 0 16 16");return e.appendChild(L("M8 1.2c.35 3.75 2.05 5.45 5.8 5.8-3.75.35-5.45 2.05-5.8 5.8C7.65 9.05 5.95 7.35 2.2 7 5.95 6.65 7.65 4.95 8 1.2z","currentColor")),e.appendChild(L("M13 10.4c.12 1.35.75 1.98 2.1 2.1-1.35.12-1.98.75-2.1 2.1-.12-1.35-.75-1.98-2.1-2.1 1.35-.12 1.98-.75 2.1-2.1z","currentColor")),e},ot=()=>{const e=N("0 0 16 16"),t=L("M6.4 1.8h3.2l.4 1.5 1.4-.5 1.6 1.6-.5 1.4 1.5.4v3.2l-1.5.4.5 1.4-1.6 1.6-1.4-.5-.4 1.5H6.4l-.4-1.5-1.4.5-1.6-1.6.5-1.4L1.8 9.6V6.4l1.5-.4-.5-1.4 1.6-1.6 1.4.5.4-1.5z");t.setAttribute("fill","none"),t.setAttribute("stroke","currentColor"),t.setAttribute("stroke-width","1.2"),t.setAttribute("stroke-linejoin","round"),e.appendChild(t);const r=P(8,8,2,"none");return r.setAttribute("stroke","currentColor"),r.setAttribute("stroke-width","1.2"),e.appendChild(r),e},lt=()=>{const e=N("0 0 16 16"),t=L("M6.2 3.2H3.8a1 1 0 0 0-1 1v8a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V9.8");t.setAttribute("fill","none"),t.setAttribute("stroke","currentColor"),t.setAttribute("stroke-width","1.3"),t.setAttribute("stroke-linecap","round"),t.setAttribute("stroke-linejoin","round"),e.appendChild(t);const r=L("M8.2 2.8h5v5M13.1 2.9 7.4 8.6");return r.setAttribute("fill","none"),r.setAttribute("stroke","currentColor"),r.setAttribute("stroke-width","1.3"),r.setAttribute("stroke-linecap","round"),r.setAttribute("stroke-linejoin","round"),e.appendChild(r),e},it=()=>{const e=N("0 0 16 16"),t=L("M2.5 4h8M2.5 7h10.5M5.5 10h7.5M5.5 13h5");return t.setAttribute("fill","none"),t.setAttribute("stroke","currentColor"),t.setAttribute("stroke-width","1.3"),t.setAttribute("stroke-linecap","round"),e.appendChild(t),e},st=()=>{const e=N("0 0 16 16");return e.appendChild(P(3.5,8,1,"currentColor")),e.appendChild(P(8,8,1,"currentColor")),e.appendChild(P(12.5,8,1,"currentColor")),e},K=e=>e.linked.length+e.passing.length,pt=e=>{try{const t=new URL(e);return t.protocol!=="http:"&&t.protocol!=="https:"?null:t.hostname.replace(/^www\./,"")}catch{return null}},dt=e=>e.length<=1?e[0]??"Nowhere":`${e.slice(0,-1).join(", ")} and ${e[e.length-1]}`,o=(e,t,r)=>{const a=document.createElement(e);return t!==""&&(a.className=t),r!==void 0&&(a.textContent=r),a},M=(e,t,r)=>{const a=o("button",e,t);return a.addEventListener("click",n=>{n.preventDefault(),r()}),a},X=(e,t,r,a)=>{const n=o("button",e);return n.type="button",n.setAttribute("aria-label",t),n.title=t,n.appendChild(r),n.addEventListener("click",p=>{p.preventDefault(),a()}),n},le=e=>e===1?"also submitted once":`also submitted ${e} times`,ct=8,ut=40,mt=3,W=new Set,D=new Set,ht=(e,t)=>`${e.key}\0${t.id}`,ie=(e,t,r)=>{const a=o("div","parle-comments"),n=l=>{l.appendChild(o("span","parle-comments-spacer")),l.appendChild(X("parle-comments-open","Open discussion",lt(),()=>t.openOut(e.permalink)));const c=o("span","parle-comments-menu-wrap"),m=o("span","parle-comments-menu");m.hidden=!0;const f=r===void 0?null:pt(r.address);if(f!==null&&r!==void 0){const E=r.restraint!==null&&r.restraint.kind==="site-paused";m.appendChild(M("parle-comments-menu-item",E?`Resume on ${f}`:`Pause on ${f}`,()=>E?t.resumeSite(f):t.pauseSite(f)))}m.appendChild(M("parle-comments-menu-item","What Parle sends",t.openDisclosure));const S=X("parle-comments-more-actions","More actions",st(),()=>{m.hidden=!m.hidden,S.setAttribute("aria-expanded",m.hidden?"false":"true")});S.setAttribute("aria-haspopup","menu"),S.setAttribute("aria-expanded","false"),c.appendChild(S),c.appendChild(m),l.appendChild(c)},p=()=>{const l=o("div","parle-comments-tools");return n(l),l};if(e.comments===null&&e.commentCount===0)return a.appendChild(p()),a.appendChild(o("p","parle-comments-note","No comments yet.")),a;if(e.comments===null||e.comments._tag==="Reading")return a.appendChild(p()),a.appendChild(o("p","parle-comments-note","Loading comments\u2026")),a;if(e.comments._tag==="Unreadable")return a.appendChild(p()),a.appendChild(o("p","parle-comments-note","Could not read this one.")),a;const d=e.comments,i=new Map(d.comments.map(l=>[l.id,l])),u=new Map;for(const l of d.comments){const c=l.parentId!==null&&l.parentId!==l.id&&i.has(l.parentId)?l.parentId:null,m=u.get(c);m===void 0?u.set(c,[l]):m.push(l)}const b=l=>{let c=0;const m=[...u.get(l.id)??[]];for(;m.length>0;){const f=m.shift();f!==void 0&&(c+=1,m.push(...u.get(f.id)??[]))}return c},g=l=>e.network!=="x"||l.startsWith("@")?l:`@${l}`,h=(l,c,m=!0)=>{const f=o("article","parle-comment"),S=o("div","parle-comment-who",g(l.author));l.age!==""&&S.appendChild(o("span","parle-comment-age",l.age)),f.appendChild(S),f.appendChild(o("p","parle-comment-text",l.text));const E=u.get(l.id)??[];if(E.length===0||!m)return f;const $=b(l);if(c>=mt)return f.appendChild(M("parle-comment-more",`Continue ${$===1?"this reply":`these ${$} replies`} on the discussion`,()=>t.openOut(e.permalink))),f;const k=ht(e,l),x=D.has(k);if(f.appendChild(M("parle-comment-more",x?"Hide replies":`${$} ${$===1?"reply":"replies"}`,()=>{D.has(k)?D.delete(k):D.add(k),v()})),x){const z=o("div","parle-replies");for(const U of E)z.appendChild(h(U,c+1));f.appendChild(z)}return f},v=()=>{a.replaceChildren();const l=o("div","parle-comments-tools"),c=W.has(e.key),m=o("button","parle-comments-mode");if(m.type="button",m.setAttribute("aria-label",c?"Flat":"Nested"),m.appendChild(it()),m.appendChild(o("span","",c?"Flat":"Nested")),m.appendChild(o("span","parle-comments-chevron","\u2304")),m.addEventListener("click",k=>{k.preventDefault(),W.has(e.key)?W.delete(e.key):W.add(e.key),v()}),m.setAttribute("aria-pressed",c?"false":"true"),l.appendChild(m),l.appendChild(M("parle-comments-collapse","Collapse all",()=>{for(const k of[...D])k.startsWith(`${e.key}\0`)&&D.delete(k);v()})),n(l),a.appendChild(l),c){const k=d.comments.slice(0,ut);for(const z of k)a.appendChild(h(z,0,!1));const x=Math.max(0,d.comments.length-k.length)+d.beyond;x>0&&a.appendChild(M("parle-comments-more",`Open ${x} more on the discussion`,()=>t.openOut(e.permalink)));return}const f=u.get(null)??[],S=f.slice(0,ct);for(const k of S)a.appendChild(h(k,0));const $=f.slice(S.length).reduce((k,x)=>k+1+b(x),0)+d.beyond;$>0&&a.appendChild(M("parle-comments-more",`Open ${$} more on the discussion`,()=>t.openOut(e.permalink)))};return v(),a},ft=e=>{switch(e.network){case"hackernews":return{score:`${e.score} points`,comments:`${e.commentCount} ${e.commentCount===1?"comment":"comments"}`};case"reddit":return{score:`${e.score} upvotes`,comments:`${e.commentCount} ${e.commentCount===1?"comment":"comments"}`};case"x":return{score:`${e.score} likes`,comments:`${e.commentCount} ${e.commentCount===1?"reply":"replies"}`}}},se=(e,t)=>{const r=o("div","parle-row-holder"),a=o("div","parle-row"),n=o("a","parle-title");n.textContent=e.title,n.href=e.permalink,n.target="_blank",n.rel="noreferrer noopener",n.addEventListener("click",u=>{u.preventDefault(),t.openOut(e.permalink)}),a.appendChild(n);const p=o("div","parle-facts"),d=ft(e);p.appendChild(o("span","parle-network",e.networkName)),p.appendChild(o("span","",d.score)),p.appendChild(o("span","",d.comments)),e.age!==""&&p.appendChild(o("span","",e.age)),e.alsoSubmitted>0&&p.appendChild(o("span","parle-repeat",le(e.alsoSubmitted))),a.appendChild(p),r.appendChild(a);const i=ie(e,t);return i!==null&&r.appendChild(i),r},gt=(e,t,r)=>{const a=o("div","parle-row-holder parle-home");a.dataset.network=e.network;const n=o("a","parle-room-title");n.textContent=e.title,n.href=e.permalink,n.target="_blank",n.rel="noreferrer noopener",n.addEventListener("click",d=>{d.preventDefault(),t.openOut(e.permalink)}),a.appendChild(n),e.alsoSubmitted>0&&a.appendChild(o("div","parle-repeat parle-room-repeat",le(e.alsoSubmitted)));const p=ie(e,t,r);return p!==null?a.appendChild(p):e.commentCount===0&&a.appendChild(o("p","parle-comments-note","No comments yet.")),a},Q=new Map,pe=new Map,de=new Set,vt=e=>e.reduce((t,r)=>t+r.commentCount,0),Z=e=>[...e].sort((t,r)=>r.commentCount-t.commentCount)[0],bt=(e,t,r,a,n,p)=>{const d=o("section","parle-group parle-group-linked parle-room");d.dataset.network=t,d.setAttribute("role","tabpanel");const i=r.filter(g=>g.network===t),u=Q.get(e),b=i.find(g=>g.key===u)??Z(i);if(b===void 0)return d.appendChild(o("p","parle-comments-note","Nothing here yet.")),d;if(i.length>1){const g=o("div","parle-thread-picks");g.setAttribute("role","tablist"),g.setAttribute("aria-label","Threads");for(const h of[...i].sort((v,l)=>l.commentCount-v.commentCount)){const v=o("button",h.key===b.key?"parle-thread-pick parle-thread-pick-on":"parle-thread-pick");v.type="button",v.setAttribute("role","tab"),v.setAttribute("aria-selected",h.key===b.key?"true":"false");const l=h.place!==null&&h.place!==""?`r/${h.place}`:h.title.length>28?`${h.title.slice(0,27)}\u2026`:h.title;v.textContent=l,v.title=h.title,v.addEventListener("click",()=>{Q.set(e,h.key),p()}),g.appendChild(v)}d.appendChild(g)}return d.appendChild(gt(b,n,a)),b.comments===null&&b.commentCount>0&&!de.has(b.key)&&(de.add(b.key),n.readDiscussion(b.key)),d},xt=(e,t,r,a,n)=>{const p=o("nav","parle-nav");p.setAttribute("aria-label","Discussions");const d=o("div","parle-nav-strip");d.setAttribute("role","tablist");const i=o("button",r==="summary"?"parle-nav-item parle-nav-on":"parle-nav-item");i.type="button",i.dataset.dock="summary",i.setAttribute("role","tab"),i.setAttribute("aria-selected",r==="summary"?"true":"false"),i.setAttribute("aria-label","Digest"),i.title="Digest";const u=o("span","parle-nav-mark");u.appendChild(nt());const b=o("span","parle-nav-icon");b.appendChild(u),t.digest.findings.length===0&&b.appendChild(o("span","parle-nav-soon")),i.appendChild(b),i.addEventListener("click",()=>n("summary")),d.appendChild(i);for(const h of B(t.linked)){const v=t.linked.filter(f=>f.network===h),l=vt(v),c=o("button",r===h?"parle-nav-item parle-nav-on":"parle-nav-item");c.type="button",c.dataset.network=h,c.setAttribute("role","tab"),c.setAttribute("aria-selected",r===h?"true":"false"),c.setAttribute("aria-label",`${ne[h]}, ${l} ${l===1?"comment":"comments"}`),c.title=`${ne[h]} \xB7 ${l}`;const m=o("span","parle-nav-icon");if(m.appendChild(at(h)),l>0){const f=o("span","parle-nav-badge",l>999?"999+":String(l));f.setAttribute("aria-hidden","true"),m.appendChild(f)}c.appendChild(m),c.addEventListener("click",()=>{const f=Z(v);f!==void 0&&Q.set(e,f.key),n(h)}),d.appendChild(c)}p.appendChild(d);const g=o("div","parle-nav-utilities");return g.appendChild(X("parle-nav-item parle-nav-settings","Settings",ot(),a.openSettings)),p.appendChild(g),p},wt=(e,t,r,a,n)=>{if(a.length===0)return null;const p=o("section",`parle-group parle-group-${e}`),d=o("h2","parle-group-name",`${t} `);d.appendChild(o("span","parle-group-note",r)),p.appendChild(d);for(const i of a)p.appendChild(se(i,n));return p},kt=(e,t)=>{const r=o("section","parle-folded");r.appendChild(o("p","parle-folded-says",e.says));const a=o("div","parle-folded-rows");a.hidden=!0;for(const p of e.rows)a.appendChild(se(p,t));const n=M("parle-act parle-act-folded",e.label,()=>{a.hidden=!1,n.remove()});return r.appendChild(n),r.appendChild(a),r},yt=(e,t)=>{const r=o("a","parle-source");return r.href=e.permalink,r.target="_blank",r.rel="noreferrer noopener",r.addEventListener("click",a=>{a.preventDefault(),t.openOut(e.permalink)}),r.appendChild(o("span","parle-source-label",e.comment?`${e.label} \u2014 the comment`:e.label)),r},Ct=(e,t)=>{const r=o("div",e.contested?"parle-finding parle-finding-disputed":"parle-finding");e.contested&&r.appendChild(o("span","parle-disputed","Someone there disagreed")),r.appendChild(o("p","parle-finding-says",e.statement));const a=o("div","parle-sources");for(const n of e.sources)a.appendChild(yt(n,t));return r.appendChild(a),r},St=(e,t)=>{if(e.says.text===""&&e.findings.length===0&&e.offer===null)return null;const r=o("section",`parle-digest parle-tone-${e.says.tone}`);e.says.text!==""&&r.appendChild(o("h2","parle-digest-title",e.says.text));for(const n of e.findings)r.appendChild(Ct(n,t));e.partial&&r.appendChild(o("p","parle-digest-partial","This is part of an answer \u2014 some of it could not be traced to a comment."));const a=e.offer;return a!==null&&(a.says!==""&&r.appendChild(o("p","parle-digest-says",a.says)),r.appendChild(M("parle-act parle-act-digest",a.label,a.kind==="connect"?t.openSettings:t.summarise))),e.wrote!==null&&r.appendChild(o("p","parle-digest-wrote",e.wrote)),r},ce=e=>e.waitingOn.length===0?"Still looking.":`Still looking \u2014 ${e.waitingOn.join(", ")}`,At=e=>{const t=K(e);return t>0?`${t} discussion${t===1?"":"s"} on this page.`:e.stillLooking?ce(e):e.folded!==null?e.folded.says:e.foundNothing?`Nobody has discussed this page. ${dt(e.answeredBy)} answered, with nothing.`:e.couldNotAsk?"Parle could not find out. Nowhere answered \u2014 which is not the same as nobody discussing it.":"Nothing has been asked about this page yet."},Et=(e,t)=>o("div",`${t} parle-tone-${e.tone}`,e.text),ue=(e,t,r)=>{e.textContent="",e.className="parle parle-compact";const a=o("div","parle-body"),n=t.address,p=Z(t.linked),d=pe.get(n)??(p!==void 0?p.network:"summary"),i=o("div","parle-main"),u=o("div","parle-extras"),b=wt("passing","Came up elsewhere","linked inside a conversation about something else",t.passing,r);if(b!==null&&u.appendChild(b),t.folded!==null&&u.appendChild(kt(t.folded,r)),t.windowed!==null&&u.appendChild(Et(t.windowed,"parle-note")),K(t)===0&&t.folded===null)u.appendChild(o("p","parle-said",t.restraint===null?At(t):t.restraint.says));else if(t.stillLooking){const l=o("div","parle-notice parle-tone-waiting"),c=o("span","");c.appendChild(o("span","parle-spinner")),c.appendChild(document.createTextNode(ce(t))),l.appendChild(c),u.appendChild(l)}const g=l=>{if(pe.set(n,l),i.replaceChildren(),l==="summary"){const c=St(t.digest,r);c!==null?i.appendChild(c):i.appendChild(o("p","parle-comments-note","A Digest of these discussions will live here."));return}t.linked.some(c=>c.network===l)&&i.appendChild(bt(n,l,t.linked,t,r,()=>g(l)))},h=o("div","parle-nav-slot"),v=l=>{h.replaceChildren(xt(n,t,l,r,c=>{g(c),v(c)}))};g(d),a.appendChild(i),a.appendChild(u),e.appendChild(a),e.appendChild(h),v(d)},Nt=`
:host,
.parle, .parle-pill, .parle-dock {
  --parle-font: -apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif;
  --parle-t-meta: 11px;
  --parle-t-body: 13px;
  --parle-t-lead: 15px;
  --parle-t-head: 18px;
  --parle-1: 4px;
  --parle-2: 8px;
  --parle-3: 12px;
  --parle-4: 16px;
  --parle-5: 24px;
  --parle-r: 10px;
  --parle-r-sm: 6px;
  --parle-r-full: 999px;
  --parle-bg: #ffffff;
  --parle-raise: #f4f5f7;
  --parle-ink: #14161a;
  --parle-mid: #5b6270;
  --parle-faint: #6f7683;
  --parle-line: rgba(20, 22, 26, 0.1);
  --parle-rule: rgba(20, 22, 26, 0.2);
  --parle-accent: #1a6fdb;
  --parle-on-accent: #ffffff;
  --parle-warn: #7a5200;
  --parle-stop: #99291c;
  --parle-lift: 0 1px 2px rgba(10, 12, 16, 0.06), 0 10px 32px rgba(10, 12, 16, 0.14);
  --parle-motion: cubic-bezier(0.2, 0.75, 0.3, 1);
}
@media (prefers-color-scheme: dark) {
  :host,
  .parle, .parle-pill, .parle-dock {
    --parle-bg: #101216;
    --parle-raise: #191c22;
    --parle-ink: #e8eaef;
    --parle-mid: #a2a9b6;
    --parle-faint: #8b929f;
    --parle-line: rgba(232, 234, 239, 0.11);
    --parle-rule: rgba(232, 234, 239, 0.24);
    --parle-accent: #6eb0ff;
    --parle-on-accent: #0a1628;
    --parle-warn: #e0bd76;
    --parle-stop: #f0a396;
    --parle-lift: 0 1px 2px rgba(0, 0, 0, 0.4), 0 10px 32px rgba(0, 0, 0, 0.5);
  }
}

/* the phone scale */
@media (max-width: 639px) {
  :host,
  .parle, .parle-pill, .parle-dock {
    --parle-t-meta: 12px;
    --parle-t-body: 15px;
    --parle-t-lead: 17px;
  }
}

/* reset \u2014 nothing inherits from the page this is drawn on */
.parle, .parle-pill, .parle-dock {
  all: initial;
  color-scheme: light dark;
  font-family: var(--parle-font);
  font-size: var(--parle-t-body);
  line-height: 1.5;
  color: var(--parle-ink);
  -webkit-font-smoothing: antialiased;
  box-sizing: border-box;
}
.parle *, .parle *::before, .parle *::after,
.parle-pill *, .parle-pill::before, .parle-pill::after,
.parle-dock * { box-sizing: border-box; }
.parle a { color: inherit; text-decoration: none; }
.parle :focus-visible,
.parle-pill:focus-visible, .parle-close:focus-visible {
  outline: 2px solid var(--parle-accent);
  outline-offset: 2px;
  border-radius: var(--parle-r-sm);
}

/* the panel */
.parle { display: flex; flex-direction: column; background: var(--parle-bg); }
.parle-head { flex: none; padding: var(--parle-4) var(--parle-4) var(--parle-2); }
.parle-heading {
  margin: 0 0 2px;
  font-size: var(--parle-t-lead);
  font-weight: 600;
  letter-spacing: -0.01em;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.parle-address {
  font-size: var(--parle-t-meta);
  color: var(--parle-faint);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.parle-body {
  padding: 0 var(--parle-3) var(--parle-3);
  max-height: 420px;
  overflow-y: auto;
  overscroll-behavior: contain;
}
.parle-compact { min-height: 0; }
.parle-compact .parle-body {
  padding: 10px 16px 8px;
  flex: 1 1 auto;
  min-height: 0;
  max-height: none;
}
.parle-dock .parle { flex: 1 1 auto; min-height: 0; }
.parle-dock .parle-body { max-height: none; flex: 1 1 auto; min-height: 0; }
.parle-dock .parle-compact { height: 100%; }
.parle-main { min-width: 0; }
.parle-extras { margin-top: var(--parle-3); }

/* discussions \u2014 Linked room vs Passing list, never blended */
.parle-group { margin: var(--parle-4) 0 0; }
.parle-group:first-child { margin-top: 0; }
.parle-group-name {
  margin: 0 0 var(--parle-2);
  font-size: var(--parle-t-meta);
  letter-spacing: 0.07em;
  text-transform: uppercase;
  font-weight: 700;
  color: var(--parle-mid);
}
.parle-group-note {
  display: block;
  margin-top: 2px;
  font-size: var(--parle-t-meta);
  color: var(--parle-faint);
  font-weight: 400;
  text-transform: none;
  letter-spacing: 0;
}
.parle-group-linked .parle-group-name { color: var(--parle-accent); }
.parle-row {
  display: block;
  padding: var(--parle-2) var(--parle-3);
  margin: 0 0 var(--parle-1);
  border-radius: var(--parle-r-sm);
  background: var(--parle-raise);
  transition: background 160ms var(--parle-motion);
}
.parle-row:hover { background: var(--parle-line); }
.parle-group-passing .parle-row { box-shadow: inset 2px 0 0 var(--parle-rule); }
.parle-title { display: block; font-weight: 500; margin-bottom: 2px; }
.parle a:hover .parle-title { text-decoration: underline; }
.parle-facts {
  display: flex;
  gap: var(--parle-2);
  flex-wrap: wrap;
  font-size: var(--parle-t-meta);
  color: var(--parle-faint);
}
.parle-network { font-weight: 600; color: var(--parle-mid); }
.parle-repeat { font-style: italic; }

/*
 * Compact open room \u2014 comments first. Network identity lives on the bottom
 * nav icon; Parle's shell stays neutral. Subtle guides only.
 */
.parle-room { margin: 0; }
.parle-room-title {
  display: -webkit-box;
  margin: 0;
  padding: 2px 0 8px;
  overflow: hidden;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 2;
  color: var(--parle-ink);
  font-size: var(--parle-t-body);
  font-weight: 650;
  line-height: 1.35;
}
.parle-room-title:hover { text-decoration: underline; }
.parle-room-repeat {
  padding: 3px 0 5px;
  border-bottom: 1px solid var(--parle-line);
  color: var(--parle-faint);
  font-size: var(--parle-t-meta);
}
.parle-thread-picks {
  display: flex;
  gap: 6px;
  overflow-x: auto;
  margin: 0 0 8px;
  scrollbar-width: none;
}
.parle-thread-picks::-webkit-scrollbar { display: none; }
.parle-thread-pick {
  flex: none;
  max-width: 10em;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  border: 0;
  border-radius: 999px;
  padding: 4px 10px;
  background: var(--parle-raise);
  color: var(--parle-mid);
  font: 600 11px/1 var(--parle-font);
  cursor: pointer;
}
.parle-thread-pick-on {
  background: var(--parle-accent);
  color: var(--parle-on-accent);
}

.parle-home .parle-comments {
  margin: 0;
  padding: 0;
  border-left: 0;
}
.parle-home .parle-comment {
  margin: 0;
  padding: 9px 0;
  border-bottom: 1px solid var(--parle-line);
  border-left: 0;
}
.parle-home .parle-comment:last-child { border-bottom: 0; }
.parle-home .parle-replies {
  margin: 7px 0 0;
  padding: 0 0 0 12px;
  border-left: 1.5px solid var(--parle-line);
}
.parle-room[data-network="hackernews"] {
  --parle-guide: #ff6600;
}
.parle-room[data-network="reddit"] {
  --parle-guide: #ff4500;
}
.parle-room[data-network="x"] {
  --parle-guide: #536471;
}
.parle-room[data-network] .parle-replies {
  border-left-color: color-mix(in srgb, var(--parle-guide) 48%, transparent);
}
.parle-room[data-network] .parle-comment-who { color: var(--parle-guide); font-weight: 700; }
.parle-room[data-network="x"] .parle-comment {
  border-left: 0;
  padding-left: 0;
}
.parle-room[data-network="x"] .parle-comment-who {
  color: var(--parle-ink);
  font-weight: 800;
}

/*
 * Bottom nav \u2014 ~32px icon row. Counts are iOS-style badges on the icon's
 * top-right and do not add layout height. Settings sits apart on the right.
 */
.parle-nav-slot { flex: none; }
.parle-nav {
  display: flex;
  align-items: center;
  gap: 4px;
  min-height: calc(34px + env(safe-area-inset-bottom, 0px));
  padding: 3px 12px calc(3px + env(safe-area-inset-bottom, 0px));
  border-top: 1px solid var(--parle-line);
  background: var(--parle-bg);
}
.parle-nav-strip {
  display: flex;
  align-items: center;
  gap: 4px;
  flex: 1 1 auto;
  min-width: 0;
  overflow-x: auto;
  scrollbar-width: none;
}
.parle-nav-strip::-webkit-scrollbar { display: none; }
.parle-nav-item {
  position: relative;
  flex: none;
  width: 40px;
  height: 27px;
  display: inline-grid;
  place-items: center;
  border: 0;
  border-radius: 8px;
  background: transparent;
  color: var(--parle-mid);
  cursor: pointer;
  padding: 0;
}
.parle-nav-item:hover { background: var(--parle-raise); color: var(--parle-ink); }
.parle-nav-on { color: var(--parle-accent); }
.parle-nav-on::after {
  content: "";
  position: absolute;
  left: 12px;
  right: 12px;
  bottom: 0;
  height: 2px;
  border-radius: 999px;
  background: var(--parle-accent);
}
.parle-nav-icon {
  position: relative;
  display: inline-grid;
  place-items: center;
  width: 20px;
  height: 20px;
  overflow: visible;
}
.parle-nav-mark,
.parle-tab-mark {
  display: inline-grid;
  place-items: center;
  width: 20px;
  height: 20px;
  border-radius: 4px;
  overflow: hidden;
  color: inherit;
}
.parle-nav-mark svg,
.parle-tab-mark svg { display: block; width: 20px; height: 20px; }
.parle-nav-badge {
  position: absolute;
  top: -5px;
  right: -9px;
  z-index: 1;
  min-width: 12px;
  height: 12px;
  padding: 0 2.5px;
  border-radius: 999px;
  background: #ff3b30;
  color: #ffffff;
  font: 700 8px/12px var(--parle-font);
  font-variant-numeric: tabular-nums;
  text-align: center;
  box-shadow: 0 0 0 1.5px var(--parle-bg);
  pointer-events: none;
}
.parle-nav-soon {
  position: absolute;
  top: -3px;
  right: -4px;
  width: 6px;
  height: 6px;
  border-radius: 999px;
  background: var(--parle-accent);
  box-shadow: 0 0 0 1.5px var(--parle-bg);
  pointer-events: none;
}
.parle-nav-utilities {
  display: flex;
  align-items: center;
  flex: none;
  margin-left: 4px;
  padding-left: 5px;
  box-shadow: -1px 0 0 var(--parle-line);
}
.parle-nav-settings { width: 32px; color: var(--parle-mid); }
.parle-nav-settings svg { display: block; width: 16px; height: 16px; }
.parle-nav-settings::after { display: none; }

/* A Discussion's own words. */
.parle-open {
  border: 0; background: transparent; cursor: pointer; font: inherit;
  color: var(--parle-accent); padding: 0; text-decoration: underline;
}
.parle-comments {
  margin: var(--parle-1) 0 var(--parle-2) var(--parle-2);
  padding-left: var(--parle-2);
  border-left: 2px solid var(--parle-line);
}
.parle-comments-tools {
  display: flex; align-items: center; gap: var(--parle-3);
  min-height: 32px;
  margin-bottom: 0;
  border-bottom: 1px solid var(--parle-line);
}
.parle-comments-mode, .parle-comments-collapse, .parle-comment-more, .parle-comments-more,
.parle-comments-open {
  border: 0; background: transparent; cursor: pointer; font: inherit;
  color: var(--parle-accent); padding: 0; text-decoration: none;
  font-size: var(--parle-t-meta); font-weight: 600;
}
.parle-comments-mode {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  flex: none;
  color: var(--parle-ink);
}
.parle-comments-mode svg { display: block; width: 15px; height: 15px; color: var(--parle-mid); }
.parle-comments-chevron { color: var(--parle-faint); font-size: 10px; transform: translateY(-1px); }
.parle-comments-collapse { color: var(--parle-accent); font-weight: 500; }
.parle-comments-collapse:hover { color: var(--parle-ink); }
.parle-comments-spacer { flex: 1 1 auto; }
.parle-comments-open,
.parle-comments-more-actions {
  display: inline-grid;
  place-items: center;
  width: 24px;
  height: 24px;
  color: var(--parle-mid);
}
.parle-comments-open:hover,
.parle-comments-more-actions:hover { color: var(--parle-ink); }
.parle-comments-open svg,
.parle-comments-more-actions svg { display: block; width: 14px; height: 14px; }
.parle-comments-menu-wrap { position: relative; display: inline-grid; }
.parle-comments-menu {
  position: absolute;
  z-index: 2;
  top: 26px;
  right: 0;
  min-width: 150px;
  padding: 4px;
  border: 1px solid var(--parle-line);
  border-radius: 8px;
  background: var(--parle-bg);
  box-shadow: var(--parle-lift);
}
.parle-comments-menu[hidden] { display: none; }
.parle-comments-menu-item {
  display: block;
  width: 100%;
  border: 0;
  border-radius: 5px;
  padding: 6px 8px;
  background: transparent;
  color: var(--parle-ink);
  font: 500 var(--parle-t-meta)/1.3 var(--parle-font);
  text-align: left;
  cursor: pointer;
}
.parle-comments-menu-item:hover { background: var(--parle-raise); }
.parle-comments-more { margin: var(--parle-1) 0 var(--parle-2); text-decoration: underline; }
.parle-comment { margin-bottom: var(--parle-2); min-width: 0; }
.parle-comment-who { color: var(--parle-mid); font-size: var(--parle-t-meta); }
.parle-comment-age { margin-left: var(--parle-1); color: var(--parle-faint); font-weight: 400; }
.parle-comment-text {
  margin: 2px 0 0; white-space: pre-wrap; overflow-wrap: anywhere;
  line-height: 1.45;
}
.parle-comment-more {
  display: inline-flex;
  align-items: center;
  gap: 3px;
  min-height: 22px;
  margin-top: 2px;
  font-size: var(--parle-t-meta);
  color: var(--parle-mid);
}
.parle-comment-more::before {
  content: "\u203A";
  font-size: 14px;
  line-height: 1;
  color: var(--parle-guide, var(--parle-faint));
}
.parle-replies {
  margin: var(--parle-2) 0 0 var(--parle-2);
  padding-left: var(--parle-2);
  border-left: 2px solid var(--parle-line);
}
.parle-comments-note { color: var(--parle-mid); font-size: var(--parle-t-meta); margin: 0; }

/* a site's front door: what was set aside, and the one click that opens it.
   Quiet rather than warning-coloured \u2014 nothing has gone wrong here, and the
   product's own rule is that a suppression must read as a decision the reader
   can reverse rather than as an error they have to interpret. */
.parle-folded {
  margin: var(--parle-3) 0 0;
  padding: var(--parle-3);
  border-radius: var(--parle-r-sm);
  background: var(--parle-raise);
}
.parle-folded-says {
  margin: 0 0 var(--parle-2);
  font-size: var(--parle-t-meta);
  color: var(--parle-mid);
}
.parle-act-folded { font-size: var(--parle-t-meta); padding: var(--parle-1) var(--parle-3); }
.parle-folded-rows { margin-top: var(--parle-2); }
.parle-folded-rows .parle-row { background: var(--parle-bg); }

/* tones \u2014 six states, six inks, no washes (ADR 0011) */
.parle-tone-refused { color: var(--parle-stop); }
.parle-tone-garbled { color: var(--parle-warn); }
.parle-tone-withheld, .parle-tone-waiting, .parle-tone-quiet { color: var(--parle-mid); }
.parle-tone-found { color: var(--parle-accent); }
.parle-notice {
  display: flex;
  justify-content: space-between;
  gap: var(--parle-2);
  margin: var(--parle-2) 0 0;
  padding: var(--parle-2) var(--parle-3);
  border-radius: var(--parle-r-sm);
  background: var(--parle-raise);
  font-size: var(--parle-t-meta);
}
.parle-said { margin: var(--parle-3) 0; color: var(--parle-mid); }
.parle-restraint { margin: var(--parle-3) 0 var(--parle-4); color: var(--parle-mid); }
.parle-restraint-says { margin: 0 0 var(--parle-3); color: var(--parle-ink); }

/* actions \u2014 outlined, so a button is a button on whatever it sits on */
.parle-act {
  all: unset;
  display: inline-block;
  cursor: pointer;
  font-family: var(--parle-font);
  font-size: var(--parle-t-body);
  font-weight: 550;
  padding: var(--parle-2) var(--parle-4);
  border-radius: var(--parle-r-full);
  color: var(--parle-ink);
  background: var(--parle-bg);
  box-shadow: inset 0 0 0 1px var(--parle-rule);
  transition: background 160ms var(--parle-motion), opacity 160ms var(--parle-motion);
}
.parle-act:hover { background: var(--parle-raise); }
.parle-act-strong {
  background: var(--parle-accent);
  color: var(--parle-on-accent);
  box-shadow: none;
}
.parle-act-strong:hover { background: var(--parle-accent); opacity: 0.88; }
.parle-link {
  all: unset;
  cursor: pointer;
  font-family: var(--parle-font);
  font-size: var(--parle-t-meta);
  color: var(--parle-mid);
  transition: color 160ms var(--parle-motion);
}
.parle-link:hover { color: var(--parle-ink); text-decoration: underline; }
.parle-note { margin: var(--parle-4) 0 0; font-size: var(--parle-t-meta); color: var(--parle-mid); }
/* the footer \u2014 rows declared, never wrapped into */
.parle-footer {
  flex: none;
  display: flex;
  flex-direction: column;
  gap: var(--parle-2);
  border-top: 1px solid var(--parle-line);
  padding: var(--parle-3) var(--parle-4);
  font-size: var(--parle-t-meta);
  color: var(--parle-faint);
}
.parle-footer-row {
  display: flex;
  align-items: center;
  gap: var(--parle-3);
  flex-wrap: wrap;
}
.parle-footer-state { margin-right: auto; color: var(--parle-mid); }

/* the account of every place we asked \u2014 the toolbar surface's whole job */
.parle-coverage { margin: var(--parle-4) 0 0; }
.parle-coverage-name {
  margin: 0 0 var(--parle-1);
  font-size: var(--parle-t-meta);
  letter-spacing: 0.07em;
  text-transform: uppercase;
  font-weight: 700;
  color: var(--parle-faint);
}
.parle-account {
  display: flex;
  justify-content: space-between;
  gap: var(--parle-3);
  padding: var(--parle-1) 0;
  font-size: var(--parle-t-meta);
  color: var(--parle-mid);
}
.parle-account-place { color: var(--parle-mid); }
.parle-account-waiting { color: var(--parle-faint); }
.parle-account-refused { color: var(--parle-stop); }
.parle-account-garbled { color: var(--parle-warn); }
.parle-account-found { color: var(--parle-accent); }

/* digest */
.parle-digest {
  margin: var(--parle-4) 0 0;
  padding: var(--parle-3);
  border-radius: var(--parle-r);
  background: var(--parle-raise);
  color: var(--parle-mid);
}
.parle-compact .parle-digest { margin-top: 0; }
.parle-digest-title { margin: 0 0 var(--parle-2); font-size: var(--parle-t-body); font-weight: 600; color: var(--parle-ink); }
.parle-digest-says { margin: 0 0 var(--parle-2); }
.parle-digest-partial { margin: var(--parle-2) 0 0; font-size: var(--parle-t-meta); }
.parle-digest-wrote { margin: var(--parle-2) 0 0; font-size: var(--parle-t-meta); color: var(--parle-faint); }
.parle-act-digest { margin-top: var(--parle-1); }
.parle-finding { margin: 0 0 var(--parle-3); }
.parle-finding:last-of-type { margin-bottom: 0; }
.parle-finding-says { margin: 0 0 var(--parle-1); color: var(--parle-ink); }
/* disputed: the neutral ink, never the accent and never a warning (ADR 0006) */
.parle-finding-disputed { box-shadow: inset 2px 0 0 var(--parle-rule); padding-left: var(--parle-3); }
.parle-disputed {
  display: block;
  margin-bottom: 2px;
  font-size: var(--parle-t-meta);
  text-transform: uppercase;
  letter-spacing: 0.05em;
  color: var(--parle-faint);
}
/* citations: underlined always, because they are meant to be followed (ADR 0006) */
.parle-sources { display: flex; flex-wrap: wrap; gap: var(--parle-1) var(--parle-3); }
.parle a.parle-source {
  font-size: var(--parle-t-meta);
  color: var(--parle-mid);
  text-decoration: underline;
  text-underline-offset: 2px;
  text-decoration-thickness: 1px;
  cursor: pointer;
}
.parle a.parle-source:hover { color: var(--parle-ink); }
.parle-spinner {
  display: inline-block;
  width: 6px;
  height: 6px;
  border-radius: var(--parle-r-full);
  background: currentColor;
  margin-right: var(--parle-2);
  vertical-align: middle;
  animation: parle-pulse 1.4s var(--parle-motion) infinite;
}
@keyframes parle-pulse { 0%, 100% { opacity: 0.25; } 50% { opacity: 1; } }

/* the mark \u2014 parked by the reader, only when there is something, still after it arrives */
.parle-pill {
  position: fixed;
  top: var(--parle-4);
  left: auto;
  right: var(--parle-4);
  z-index: 2147483646;
  display: grid;
  place-items: center;
  min-width: 36px;
  height: 36px;
  padding: 4px;
  border: 0;
  border-radius: var(--parle-r-full);
  background: var(--parle-bg);
  color: var(--parle-ink);
  box-shadow: var(--parle-lift), inset 0 0 0 1px var(--parle-line);
  cursor: grab;
  touch-action: none;
  user-select: none;
  font-family: var(--parle-font);
  font-size: var(--parle-t-meta);
  font-weight: 650;
  transition: transform 160ms var(--parle-motion), box-shadow 160ms var(--parle-motion);
  animation: parle-arrive 420ms var(--parle-motion) both;
}
.parle-pill:hover { transform: scale(1.05); }
.parle-pill[data-dragging="1"] {
  cursor: grabbing;
  transform: scale(1.08);
  box-shadow: var(--parle-lift), inset 0 0 0 1px var(--parle-accent);
  transition: none;
}
.parle-pill[hidden], .parle-pill[data-found="0"] { display: none; }
.parle-pill svg, .parle-close svg { display: block; width: 16px; height: 16px; }
.parle-pill svg:not([fill]), .parle-close svg:not([fill]) { fill: currentColor; }
.parle-stack {
  display: flex;
  flex-direction: row;
  align-items: center;
}
.parle-stack-disc {
  display: grid;
  place-items: center;
  width: 28px;
  height: 28px;
  border-radius: var(--parle-r-full);
  background: var(--parle-bg);
  box-shadow: 0 0 0 2px var(--parle-bg);
  overflow: hidden;
}
.parle-stack-disc + .parle-stack-disc { margin-left: -10px; }
.parle-stack-disc svg { width: 28px; height: 28px; }
.parle-stack-parle {
  color: var(--parle-ink);
  background: var(--parle-raise);
}
.parle-stack-parle svg { width: 16px; height: 16px; }
.parle-pill-count {
  position: absolute;
  top: -4px;
  right: -4px;
  min-width: 18px;
  height: 18px;
  padding: 0 5px;
  border-radius: var(--parle-r-full);
  background: var(--parle-accent);
  color: var(--parle-on-accent);
  font-size: 10px;
  font-weight: 700;
  line-height: 18px;
  text-align: center;
  box-shadow: 0 0 0 2px var(--parle-bg);
}
.parle-pill-count:empty { display: none; }
/* the announcement: one ring, outward, once */
.parle-pill::after {
  content: "";
  position: absolute;
  inset: -2px;
  border-radius: var(--parle-r-full);
  border: 2px solid var(--parle-accent);
  pointer-events: none;
  animation: parle-ring 1100ms var(--parle-motion) 1 both;
}
@keyframes parle-arrive {
  from { opacity: 0; transform: translateY(-6px) scale(0.8); }
  to { opacity: 1; transform: none; }
}
@keyframes parle-ring {
  from { opacity: 0.55; transform: scale(1); }
  to { opacity: 0; transform: scale(2.1); }
}

/* the surface \u2014 full screen under 640px, docked right at and above it */
.parle-dock {
  position: fixed;
  inset: 0;
  z-index: 2147483647;
  display: flex;
  flex-direction: column;
  background: var(--parle-bg);
  box-shadow: var(--parle-lift);
  overscroll-behavior: contain;
  padding-top: env(safe-area-inset-top, 0px);
  padding-bottom: env(safe-area-inset-bottom, 0px);
  animation: parle-open 180ms var(--parle-motion) both;
}
@keyframes parle-open { from { opacity: 0; } to { opacity: 1; } }
@media (min-width: 640px) {
  .parle-dock { inset: 0 0 0 auto; width: clamp(320px, 30vw, 420px); padding-bottom: 0; }
}
/* the way out of the surface, drawn as a button */
.parle-close {
  all: unset;
  position: absolute;
  top: calc(env(safe-area-inset-top, 0px) + var(--parle-2));
  right: var(--parle-2);
  z-index: 1;
  display: grid;
  place-items: center;
  width: 32px;
  height: 32px;
  border-radius: var(--parle-r-full);
  background: var(--parle-raise);
  cursor: pointer;
  font-family: var(--parle-font);
  font-size: var(--parle-t-head);
  line-height: 1;
  color: var(--parle-mid);
  transition: background 160ms var(--parle-motion), color 160ms var(--parle-motion);
}
.parle-close:hover { background: var(--parle-line); color: var(--parle-ink); }
.parle-dock .parle-head { padding-right: 52px; }
@media (max-width: 639px) {
  .parle-close {
    top: calc(env(safe-area-inset-top, 0px) + var(--parle-3));
    right: var(--parle-3);
    width: 40px;
    height: 40px;
  }
  .parle-dock .parle-head { padding-right: 64px; padding-top: var(--parle-5); }
  .parle-dock .parle-heading {
    white-space: normal;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
  }
}

@media (prefers-reduced-motion: reduce) {
  .parle, .parle *,
  .parle-pill, .parle-pill::after,
  .parle-dock, .parle-close { animation: none !important; transition: none !important; }
  .parle-pill::after { opacity: 0; }
}
`,me="__parle_pill_mounted__",F=36,Lt=5,he=e=>{if("showPopover"in e)try{e.setAttribute("popover","manual"),e.showPopover()}catch{e.removeAttribute("popover")}},Mt=e=>`${e} discussion${e===1?"":"s"}`,$t={matches:["http://*/*","https://*/*"],registration:"runtime",runAt:"document_idle",allFrames:!1,main:()=>{const e=window;if(e[me]===!0)return;e[me]=!0;let t=null,r="in-page",a=!1,n=ye,p=null,d=null,i=null,u=null,b=null,g=null,h=null;const v=()=>{if(i===null)return;const{left:s,top:w}=Ae(n,F,{width:window.innerWidth,height:window.innerHeight});i.style.left=`${s}px`,i.style.top=`${w}px`,i.style.right="auto"},l=s=>{let w=0,y=0,C=0,_=0,T=!1,H=!1;const we=A=>{const O=A.clientX-w,j=A.clientY-y;if(!T){if(Math.hypot(O,j)<Lt)return;T=!0,H=!0,s.dataset.dragging="1",s.setPointerCapture(A.pointerId)}const It=Math.max(16,window.innerWidth-F-16),Rt=Math.max(16,window.innerHeight-F-16),Wt=Math.min(It,Math.max(16,C+O)),Ft=Math.min(Rt,Math.max(16,_+j));s.style.left=`${Wt}px`,s.style.top=`${Ft}px`,s.style.right="auto"},Y=A=>{if(window.removeEventListener("pointermove",we,!0),window.removeEventListener("pointerup",Y,!0),window.removeEventListener("pointercancel",Y,!0),T){s.dataset.dragging="0";try{s.releasePointerCapture(A.pointerId)}catch{}const O=Number.parseFloat(s.style.left||"0"),j=Number.parseFloat(s.style.top||"0");n=Ee(O,j,F,{width:window.innerWidth,height:window.innerHeight}),v(),x.say(Fe(n))}T=!1};s.addEventListener("pointerdown",A=>{if(A.button!==0)return;w=A.clientX,y=A.clientY;const O=s.getBoundingClientRect();C=O.left,_=O.top,H=!1,T=!1,window.addEventListener("pointermove",we,!0),window.addEventListener("pointerup",Y,!0),window.addEventListener("pointercancel",Y,!0)}),s.addEventListener("click",A=>{if(H){A.preventDefault(),A.stopPropagation(),H=!1;return}f()})},c=()=>{if(p!==null)return;const s=document.createElement("div");s.style.setProperty("all","initial");const w=s.attachShadow({mode:"closed"}),y=document.createElement("style");y.textContent=Nt,w.appendChild(y);const C=document.createElement("button");C.className="parle-pill",C.type="button";const _=oe([]);C.appendChild(_);const T=document.createElement("span");T.className="parle-pill-count",C.appendChild(T),l(C),w.appendChild(C),document.documentElement.appendChild(s),he(C),p=s,d=w,i=C,u=T,b=_,v()},m=()=>{p!==null&&(p.remove(),p=null,d=null,i=null,u=null,b=null,g=null,h=null)},f=()=>{if(r==="native"){i!==null&&(i.hidden=!0),x.say(De()),window.setTimeout(()=>{!a&&i!==null&&(i.hidden=!1)},1e3);return}g===null?S():E()},S=()=>{if(d===null||g!==null||t===null)return;const s=document.createElement("div");s.className="parle-dock",s.setAttribute("role","dialog"),s.setAttribute("aria-label","Parle");const w=document.createElement("button");w.className="parle-close",w.type="button",w.setAttribute("aria-label","Close"),w.textContent="\xD7",w.addEventListener("click",E),s.appendChild(w);const y=document.createElement("div");y.className="parle",s.appendChild(y),d.appendChild(s),he(s),g=s,h=y,ue(y,t,z),w.focus({preventScroll:!0})},E=()=>{g!==null&&(g.remove(),g=null,h=null,i?.focus({preventScroll:!0}))},$=s=>{if(i===null)return;const w=B([...s.linked,...s.passing]),y=oe(w);b!==null?b.replaceWith(y):i.insertBefore(y,u),b=y},k=()=>{if(t===null)return;const s=K(t);if(s===0){m();return}if(c(),$(t),v(),u!==null&&(u.textContent=String(Math.min(s,99))),i!==null){i.hidden=r==="native"&&a,i.dataset.found=String(s);const w=B([...t.linked,...t.passing]),y=w.length===0?"":` on ${w.map(_=>_==="hackernews"?"Hacker News":_==="reddit"?"Reddit":"X").join(" \xB7 ")}`,C=`Parle \u2014 ${Mt(s)}${y}`;i.setAttribute("aria-label",C),i.title=`${C}. Drag to move.`}h!==null&&ue(h,t,z)},x=Ke(Ne,s=>{if(s._tag==="AsideVisibility"){a=s.open,i!==null&&(i.hidden=r==="native"&&a);return}s._tag==="Standing"&&(t=s.panel,r=s.aside,n=s.markPark,k())}),z={openOut:s=>x.say($e(s)),lookAnyway:()=>x.say(Te()),summarise:()=>x.say(_e()),readDiscussion:s=>x.say(ze(s)),decide:s=>x.say(Oe(s)),openDisclosure:()=>x.say(Pe()),openSettings:()=>x.say(We()),pauseSite:s=>x.say(Ie(s)),resumeSite:s=>x.say(Re(s))},U=s=>{g===null||s.key!=="Escape"||(s.stopPropagation(),E())};window.addEventListener("keydown",U,!0),window.addEventListener("resize",v),x.say(Le(null),!0);const ge=()=>{x.say(Me(location.href,document.title,document.referrer),!0)};ge();let ve=location.href;const ee=()=>{location.href!==ve&&(ve=location.href,m(),ge())};window.addEventListener("popstate",ee),window.addEventListener("hashchange",ee);const be=new MutationObserver(ee),xe=document.querySelector("title");xe!==null&&be.observe(xe,{childList:!0});const Dt=Qe(()=>{});window.addEventListener("pagehide",()=>{Dt(),be.disconnect(),window.removeEventListener("keydown",U,!0),window.removeEventListener("resize",v),m(),x.close()})}};function G(e,...t){}const Tt={debug:(...e)=>G(console.debug,...e),log:(...e)=>G(console.log,...e),warn:(...e)=>G(console.warn,...e),error:(...e)=>G(console.error,...e)};var fe=class ke extends Event{static EVENT_NAME=J("wxt:locationchange");constructor(t,r){super(ke.EVENT_NAME,{}),this.newUrl=t,this.oldUrl=r}};function J(e){return`${q?.runtime?.id}:pill:${e}`}const _t=typeof globalThis.navigation?.addEventListener=="function";function zt(e){let t,r=!1;return{run(){r||(r=!0,t=new URL(location.href),_t?globalThis.navigation.addEventListener("navigate",a=>{const n=new URL(a.destination.url);n.href!==t.href&&(window.dispatchEvent(new fe(n,t)),t=n)},{signal:e.signal}):e.setInterval(()=>{const a=new URL(location.href);a.href!==t.href&&(window.dispatchEvent(new fe(a,t)),t=a)},1e3))}}}var Ot=class R{static SCRIPT_STARTED_MESSAGE_TYPE=J("wxt:content-script-started");id;abortController;locationWatcher=zt(this);constructor(t,r){this.contentScriptName=t,this.options=r,this.id=Math.random().toString(36).slice(2),this.abortController=new AbortController,this.stopOldScripts(),this.listenForNewerScripts()}get signal(){return this.abortController.signal}abort(t){return this.abortController.abort(t)}get isInvalid(){return q.runtime?.id==null&&this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(t){return this.signal.addEventListener("abort",t),()=>this.signal.removeEventListener("abort",t)}block(){return new Promise(()=>{})}setInterval(t,r){const a=setInterval(()=>{this.isValid&&t()},r);return this.onInvalidated(()=>clearInterval(a)),a}setTimeout(t,r){const a=setTimeout(()=>{this.isValid&&t()},r);return this.onInvalidated(()=>clearTimeout(a)),a}requestAnimationFrame(t){const r=requestAnimationFrame((...a)=>{this.isValid&&t(...a)});return this.onInvalidated(()=>cancelAnimationFrame(r)),r}requestIdleCallback(t,r){const a=requestIdleCallback((...n)=>{this.signal.aborted||t(...n)},r);return this.onInvalidated(()=>cancelIdleCallback(a)),a}addEventListener(t,r,a,n){r==="wxt:locationchange"&&this.isValid&&this.locationWatcher.run(),t.addEventListener?.(r.startsWith("wxt:")?J(r):r,a,{...n,signal:this.signal})}notifyInvalidated(){this.abort("Content script context invalidated"),Tt.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){document.dispatchEvent(new CustomEvent(R.SCRIPT_STARTED_MESSAGE_TYPE,{detail:{contentScriptName:this.contentScriptName,messageId:this.id}})),this.options?.noScriptStartedPostMessage||window.postMessage({type:R.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:this.id},"*")}verifyScriptStartedEvent(t){const r=t.detail?.contentScriptName===this.contentScriptName,a=t.detail?.messageId===this.id;return r&&!a}listenForNewerScripts(){const t=r=>{!(r instanceof CustomEvent)||!this.verifyScriptStartedEvent(r)||this.notifyInvalidated()};document.addEventListener(R.SCRIPT_STARTED_MESSAGE_TYPE,t),this.onInvalidated(()=>document.removeEventListener(R.SCRIPT_STARTED_MESSAGE_TYPE,t))}};function Ht(){}function V(e,...t){}const Pt={debug:(...e)=>V(console.debug,...e),log:(...e)=>V(console.log,...e),warn:(...e)=>V(console.warn,...e),error:(...e)=>V(console.error,...e)};return(async()=>{try{const{main:e,...t}=$t;return await e(new Ot("pill",t))}catch(e){throw Pt.error('The content script "pill" crashed on startup!',e),e}})()})();
