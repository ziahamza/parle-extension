import{f as z}from"./Panel-BS6W8507.js";const L="http://www.w3.org/2000/svg",y=e=>{const r=document.createElementNS(L,"svg");return r.setAttribute("viewBox",e),r.setAttribute("aria-hidden","true"),r},w=(e,r)=>{const a=document.createElementNS(L,"path");return a.setAttribute("d",e),r!==void 0&&a.setAttribute("fill",r),a},Y=(e,r,a,t,o,s)=>{const p=document.createElementNS(L,"rect");return p.setAttribute("x",String(e)),p.setAttribute("y",String(r)),p.setAttribute("width",String(a)),p.setAttribute("height",String(t)),p.setAttribute("rx",String(o)),p.setAttribute("fill",s),p},$=(e,r,a,t)=>{const o=document.createElementNS(L,"circle");return o.setAttribute("cx",String(e)),o.setAttribute("cy",String(r)),o.setAttribute("r",String(a)),o.setAttribute("fill",t),o},q=()=>{const e=y("0 0 16 16");return e.appendChild(Y(0,0,16,16,2.5,"#ff6600")),e.appendChild(w("M4.2 3.2h1.7l2.1 4.1 2.1-4.1h1.7L8.9 8.6V12.8H7.1V8.6L4.2 3.2z","#ffffff")),e},U=()=>{const e=y("0 0 16 16");e.appendChild($(8,8,8,"#ff4500"));const r=document.createElementNS(L,"text");return r.setAttribute("x","8"),r.setAttribute("y","11.2"),r.setAttribute("text-anchor","middle"),r.setAttribute("fill","#ffffff"),r.setAttribute("font-size","7.5"),r.setAttribute("font-weight","700"),r.setAttribute("font-family","Verdana, Geneva, sans-serif"),r.textContent="r/",e.appendChild(r),e},Q=()=>{const e=y("0 0 16 16");return e.appendChild($(8,8,8,"#0f1419")),e.appendChild(w("M4.1 4.1h2.05l1.7 2.35L10.05 4.1H12l-2.85 3.55L12.2 11.9h-2.05l-1.95-2.6-2.2 2.6H4l3.1-3.7L4.1 4.1z","#ffffff")),e},X=e=>{switch(e){case"hackernews":return q();case"reddit":return U();case"x":return Q()}},P={hackernews:"HN",reddit:"Reddit",x:"X"},J=e=>{const r=new Set;for(const a of e)r.add(a.network);return["hackernews","reddit","x"].filter(a=>r.has(a))},Z=e=>{const r=document.createElement("span");return r.className=`parle-tab-mark parle-tab-mark-${e}`,r.appendChild(X(e)),r},ee=()=>{const e=y("0 0 16 16");return e.appendChild(w("M8 1.2c.35 3.75 2.05 5.45 5.8 5.8-3.75.35-5.45 2.05-5.8 5.8C7.65 9.05 5.95 7.35 2.2 7 5.95 6.65 7.65 4.95 8 1.2z","currentColor")),e.appendChild(w("M13 10.4c.12 1.35.75 1.98 2.1 2.1-1.35.12-1.98.75-2.1 2.1-.12-1.35-.75-1.98-2.1-2.1 1.35-.12 1.98-.75 2.1-2.1z","currentColor")),e},re=()=>{const e=y("0 0 16 16"),r=w("M6.4 1.8h3.2l.4 1.5 1.4-.5 1.6 1.6-.5 1.4 1.5.4v3.2l-1.5.4.5 1.4-1.6 1.6-1.4-.5-.4 1.5H6.4l-.4-1.5-1.4.5-1.6-1.6.5-1.4L1.8 9.6V6.4l1.5-.4-.5-1.4 1.6-1.6 1.4.5.4-1.5z");r.setAttribute("fill","none"),r.setAttribute("stroke","currentColor"),r.setAttribute("stroke-width","1.2"),r.setAttribute("stroke-linejoin","round"),e.appendChild(r);const a=$(8,8,2,"none");return a.setAttribute("stroke","currentColor"),a.setAttribute("stroke-width","1.2"),e.appendChild(a),e},ae=()=>{const e=y("0 0 16 16"),r=w("M6.2 3.2H3.8a1 1 0 0 0-1 1v8a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V9.8");r.setAttribute("fill","none"),r.setAttribute("stroke","currentColor"),r.setAttribute("stroke-width","1.3"),r.setAttribute("stroke-linecap","round"),r.setAttribute("stroke-linejoin","round"),e.appendChild(r);const a=w("M8.2 2.8h5v5M13.1 2.9 7.4 8.6");return a.setAttribute("fill","none"),a.setAttribute("stroke","currentColor"),a.setAttribute("stroke-width","1.3"),a.setAttribute("stroke-linecap","round"),a.setAttribute("stroke-linejoin","round"),e.appendChild(a),e},te=()=>{const e=y("0 0 16 16"),r=w("M2.5 4h8M2.5 7h10.5M5.5 10h7.5M5.5 13h5");return r.setAttribute("fill","none"),r.setAttribute("stroke","currentColor"),r.setAttribute("stroke-width","1.3"),r.setAttribute("stroke-linecap","round"),e.appendChild(r),e},ne=()=>{const e=y("0 0 16 16");return e.appendChild($(3.5,8,1,"currentColor")),e.appendChild($(8,8,1,"currentColor")),e.appendChild($(12.5,8,1,"currentColor")),e},W=e=>{try{const r=new URL(e);return r.protocol!=="http:"&&r.protocol!=="https:"?null:r.hostname.replace(/^www\./,"")}catch{return null}},oe=e=>e.length<=1?e[0]??"Nowhere":`${e.slice(0,-1).join(", ")} and ${e[e.length-1]}`,n=(e,r,a)=>{const t=document.createElement(e);return r!==""&&(t.className=r),a!==void 0&&(t.textContent=a),t},b=(e,r,a)=>{const t=n("button",e,r);return t.addEventListener("click",o=>{o.preventDefault(),a()}),t},O=(e,r,a,t)=>{const o=n("button",e);return o.type="button",o.setAttribute("aria-label",r),o.title=r,o.appendChild(a),o.addEventListener("click",s=>{s.preventDefault(),t()}),o},H=e=>e===1?"also submitted once":`also submitted ${e} times`,le=8,ie=40,pe=3,M=new Set,N=new Set,se=(e,r)=>`${e.key}\0${r.id}`,j=(e,r,a)=>{const t=n("div","parle-comments"),o=l=>{l.appendChild(n("span","parle-comments-spacer")),l.appendChild(O("parle-comments-open","Open discussion",ae(),()=>r.openOut(e.permalink)));const i=n("span","parle-comments-menu-wrap"),d=n("span","parle-comments-menu");d.hidden=!0;const c=a===void 0?null:W(a.address);if(c!==null&&a!==void 0){const S=a.restraint!==null&&a.restraint.kind==="site-paused";d.appendChild(b("parle-comments-menu-item",S?`Resume on ${c}`:`Pause on ${c}`,()=>S?r.resumeSite(c):r.pauseSite(c)))}d.appendChild(b("parle-comments-menu-item","What Parle sends",r.openDisclosure));const k=O("parle-comments-more-actions","More actions",ne(),()=>{d.hidden=!d.hidden,k.setAttribute("aria-expanded",d.hidden?"false":"true")});k.setAttribute("aria-haspopup","menu"),k.setAttribute("aria-expanded","false"),i.appendChild(k),i.appendChild(d),l.appendChild(i)},s=()=>{const l=n("div","parle-comments-tools");return o(l),l};if(e.comments===null&&e.commentCount===0)return t.appendChild(s()),t.appendChild(n("p","parle-comments-note","No comments yet.")),t;if(e.comments===null||e.comments._tag==="Reading")return t.appendChild(s()),t.appendChild(n("p","parle-comments-note","Loading comments\u2026")),t;if(e.comments._tag==="Unreadable")return t.appendChild(s()),t.appendChild(n("p","parle-comments-note","Could not read this one.")),t;const p=e.comments,m=new Map(p.comments.map(l=>[l.id,l])),h=new Map;for(const l of p.comments){const i=l.parentId!==null&&l.parentId!==l.id&&m.has(l.parentId)?l.parentId:null,d=h.get(i);d===void 0?h.set(i,[l]):d.push(l)}const v=l=>{let i=0;const d=[...h.get(l.id)??[]];for(;d.length>0;){const c=d.shift();c!==void 0&&(i+=1,d.push(...h.get(c.id)??[]))}return i},g=l=>e.network!=="x"||l.startsWith("@")?l:`@${l}`,u=(l,i,d=!0)=>{const c=n("article","parle-comment"),k=n("div","parle-comment-who",g(l.author));l.age!==""&&k.appendChild(n("span","parle-comment-age",l.age)),c.appendChild(k),c.appendChild(n("p","parle-comment-text",l.text));const S=h.get(l.id)??[];if(S.length===0||!d)return c;const C=v(l);if(i>=pe)return c.appendChild(b("parle-comment-more",`Continue ${C===1?"this reply":`these ${C} replies`} on the discussion`,()=>r.openOut(e.permalink))),c;const x=se(e,l),A=N.has(x);if(c.appendChild(b("parle-comment-more",A?"Hide replies":`${C} ${C===1?"reply":"replies"}`,()=>{N.has(x)?N.delete(x):N.add(x),f()})),A){const E=n("div","parle-replies");for(const K of S)E.appendChild(u(K,i+1));c.appendChild(E)}return c},f=()=>{t.replaceChildren();const l=n("div","parle-comments-tools"),i=M.has(e.key),d=n("button","parle-comments-mode");if(d.type="button",d.setAttribute("aria-label",i?"Flat":"Nested"),d.appendChild(te()),d.appendChild(n("span","",i?"Flat":"Nested")),d.appendChild(n("span","parle-comments-chevron","\u2304")),d.addEventListener("click",x=>{x.preventDefault(),M.has(e.key)?M.delete(e.key):M.add(e.key),f()}),d.setAttribute("aria-pressed",i?"false":"true"),l.appendChild(d),l.appendChild(b("parle-comments-collapse","Collapse all",()=>{for(const x of[...N])x.startsWith(`${e.key}\0`)&&N.delete(x);f()})),o(l),t.appendChild(l),i){const x=p.comments.slice(0,ie);for(const E of x)t.appendChild(u(E,0,!1));const A=Math.max(0,p.comments.length-x.length)+p.beyond;A>0&&t.appendChild(b("parle-comments-more",`Open ${A} more on the discussion`,()=>r.openOut(e.permalink)));return}const c=h.get(null)??[],k=c.slice(0,le);for(const x of k)t.appendChild(u(x,0));const C=c.slice(k.length).reduce((x,A)=>x+1+v(A),0)+p.beyond;C>0&&t.appendChild(b("parle-comments-more",`Open ${C} more on the discussion`,()=>r.openOut(e.permalink)))};return f(),t},de=e=>{switch(e.network){case"hackernews":return{score:`${e.score} points`,comments:`${e.commentCount} ${e.commentCount===1?"comment":"comments"}`};case"reddit":return{score:`${e.score} upvotes`,comments:`${e.commentCount} ${e.commentCount===1?"comment":"comments"}`};case"x":return{score:`${e.score} likes`,comments:`${e.commentCount} ${e.commentCount===1?"reply":"replies"}`}}},I=(e,r)=>{const a=n("div","parle-row-holder"),t=n("div","parle-row"),o=n("a","parle-title");o.textContent=e.title,o.href=e.permalink,o.target="_blank",o.rel="noreferrer noopener",o.addEventListener("click",h=>{h.preventDefault(),r.openOut(e.permalink)}),t.appendChild(o);const s=n("div","parle-facts"),p=de(e);s.appendChild(n("span","parle-network",e.networkName)),s.appendChild(n("span","",p.score)),s.appendChild(n("span","",p.comments)),e.age!==""&&s.appendChild(n("span","",e.age)),e.alsoSubmitted>0&&s.appendChild(n("span","parle-repeat",H(e.alsoSubmitted))),t.appendChild(s),a.appendChild(t);const m=j(e,r);return m!==null&&a.appendChild(m),a},ce=(e,r,a)=>{const t=n("div","parle-row-holder parle-home");t.dataset.network=e.network;const o=n("a","parle-room-title");o.textContent=e.title,o.href=e.permalink,o.target="_blank",o.rel="noreferrer noopener",o.addEventListener("click",p=>{p.preventDefault(),r.openOut(e.permalink)}),t.appendChild(o),e.alsoSubmitted>0&&t.appendChild(n("div","parle-repeat parle-room-repeat",H(e.alsoSubmitted)));const s=j(e,r,a);return s!==null?t.appendChild(s):e.commentCount===0&&t.appendChild(n("p","parle-comments-note","No comments yet.")),t},D=new Map,_=new Map,G=new Set,me=e=>e.reduce((r,a)=>r+a.commentCount,0),T=e=>[...e].sort((r,a)=>a.commentCount-r.commentCount)[0],ue=(e,r,a,t,o,s)=>{const p=n("section","parle-group parle-group-linked parle-room");p.dataset.network=r,p.setAttribute("role","tabpanel");const m=a.filter(g=>g.network===r),h=D.get(e),v=m.find(g=>g.key===h)??T(m);if(v===void 0)return p.appendChild(n("p","parle-comments-note","Nothing here yet.")),p;if(m.length>1){const g=n("div","parle-thread-picks");g.setAttribute("role","tablist"),g.setAttribute("aria-label","Threads");for(const u of[...m].sort((f,l)=>l.commentCount-f.commentCount)){const f=n("button",u.key===v.key?"parle-thread-pick parle-thread-pick-on":"parle-thread-pick");f.type="button",f.setAttribute("role","tab"),f.setAttribute("aria-selected",u.key===v.key?"true":"false");const l=u.place!==null&&u.place!==""?`r/${u.place}`:u.title.length>28?`${u.title.slice(0,27)}\u2026`:u.title;f.textContent=l,f.title=u.title,f.addEventListener("click",()=>{D.set(e,u.key),s()}),g.appendChild(f)}p.appendChild(g)}return p.appendChild(ce(v,o,t)),v.comments===null&&v.commentCount>0&&!G.has(v.key)&&(G.add(v.key),o.readDiscussion(v.key)),p},he=(e,r,a,t,o)=>{const s=n("nav","parle-nav");s.setAttribute("aria-label","Discussions");const p=n("div","parle-nav-strip");p.setAttribute("role","tablist");const m=n("button",a==="summary"?"parle-nav-item parle-nav-on":"parle-nav-item");m.type="button",m.dataset.dock="summary",m.setAttribute("role","tab"),m.setAttribute("aria-selected",a==="summary"?"true":"false"),m.setAttribute("aria-label","Digest"),m.title="Digest";const h=n("span","parle-nav-mark");h.appendChild(ee());const v=n("span","parle-nav-icon");v.appendChild(h),r.digest.findings.length===0&&v.appendChild(n("span","parle-nav-soon")),m.appendChild(v),m.addEventListener("click",()=>o("summary")),p.appendChild(m);for(const u of J(r.linked)){const f=r.linked.filter(c=>c.network===u),l=me(f),i=n("button",a===u?"parle-nav-item parle-nav-on":"parle-nav-item");i.type="button",i.dataset.network=u,i.setAttribute("role","tab"),i.setAttribute("aria-selected",a===u?"true":"false"),i.setAttribute("aria-label",`${P[u]}, ${l} ${l===1?"comment":"comments"}`),i.title=`${P[u]} \xB7 ${l}`;const d=n("span","parle-nav-icon");if(d.appendChild(Z(u)),l>0){const c=n("span","parle-nav-badge",l>999?"999+":String(l));c.setAttribute("aria-hidden","true"),d.appendChild(c)}i.appendChild(d),i.addEventListener("click",()=>{const c=T(f);c!==void 0&&D.set(e,c.key),o(u)}),p.appendChild(i)}s.appendChild(p);const g=n("div","parle-nav-utilities");return g.appendChild(O("parle-nav-item parle-nav-settings","Settings",re(),t.openSettings)),s.appendChild(g),s},fe=(e,r,a,t,o)=>{if(t.length===0)return null;const s=n("section",`parle-group parle-group-${e}`),p=n("h2","parle-group-name",`${r} `);p.appendChild(n("span","parle-group-note",a)),s.appendChild(p);for(const m of t)s.appendChild(I(m,o));return s},V=(e,r)=>{const a=n("section","parle-folded");a.appendChild(n("p","parle-folded-says",e.says));const t=n("div","parle-folded-rows");t.hidden=!0;for(const s of e.rows)t.appendChild(I(s,r));const o=b("parle-act parle-act-folded",e.label,()=>{t.hidden=!1,o.remove()});return a.appendChild(o),a.appendChild(t),a},ve=(e,r)=>{const a=n("a","parle-source");return a.href=e.permalink,a.target="_blank",a.rel="noreferrer noopener",a.addEventListener("click",t=>{t.preventDefault(),r.openOut(e.permalink)}),a.appendChild(n("span","parle-source-label",e.comment?`${e.label} \u2014 the comment`:e.label)),a},ge=(e,r)=>{const a=n("div",e.contested?"parle-finding parle-finding-disputed":"parle-finding");e.contested&&a.appendChild(n("span","parle-disputed","Someone there disagreed")),a.appendChild(n("p","parle-finding-says",e.statement));const t=n("div","parle-sources");for(const o of e.sources)t.appendChild(ve(o,r));return a.appendChild(t),a},be=(e,r)=>{if(e.says.text===""&&e.findings.length===0&&e.offer===null)return null;const a=n("section",`parle-digest parle-tone-${e.says.tone}`);e.says.text!==""&&a.appendChild(n("h2","parle-digest-title",e.says.text));for(const o of e.findings)a.appendChild(ge(o,r));e.partial&&a.appendChild(n("p","parle-digest-partial","This is part of an answer \u2014 some of it could not be traced to a comment."));const t=e.offer;return t!==null&&(t.says!==""&&a.appendChild(n("p","parle-digest-says",t.says)),a.appendChild(b("parle-act parle-act-digest",t.label,t.kind==="connect"?r.openSettings:r.summarise))),e.wrote!==null&&a.appendChild(n("p","parle-digest-wrote",e.wrote)),a},B=e=>e.waitingOn.length===0?"Still looking.":`Still looking \u2014 ${e.waitingOn.join(", ")}`,F=e=>{const r=z(e);return r>0?`${r} discussion${r===1?"":"s"} on this page.`:e.stillLooking?B(e):e.folded!==null?e.folded.says:e.foundNothing?`Nobody has discussed this page. ${oe(e.answeredBy)} answered, with nothing.`:e.couldNotAsk?"Parle could not find out. Nowhere answered \u2014 which is not the same as nobody discussing it.":"Nothing has been asked about this page yet."},xe=(e,r)=>{switch(e.kind){case"not-a-web-page":return null;case"undecided":return b("parle-act parle-act-strong","Read this and choose",r.openDisclosure);case"automatic-off":return b("parle-act","Look this page up",r.lookAnyway);case"networks-off":return b("parle-act","Choose where Parle looks",r.openSettings);case"excluded":case"site-paused":case"over-budget":case"switched-off":case"front-door":return b("parle-act","Look it up anyway",r.lookAnyway)}},ke=(e,r)=>{const a=n("div",`parle-restraint parle-restraint-${e.kind}`);a.appendChild(n("p","parle-restraint-says",e.says));const t=xe(e,r);return t!==null&&a.appendChild(t),a},R=(e,r)=>n("div",`${r} parle-tone-${e.tone}`,e.text),we=e=>{const r=n("section","parle-coverage");r.appendChild(n("h2","parle-coverage-name","Where Parle asked"));for(const a of e){const t=n("div","parle-account");t.appendChild(n("span","parle-account-place",a.place)),t.appendChild(n("span",`parle-account-${a.tone}`,a.standing)),r.appendChild(t)}return r},ye=(e,r)=>{const a=W(e.address);if(a===null)return null;const t=e.restraint!==null&&e.restraint.kind==="site-paused";return b("parle-link",t?`Resume on ${a}`:`Pause on ${a}`,()=>t?r.resumeSite(a):r.pauseSite(a))},Ce=(e,r)=>{const a=n("footer","parle-footer"),t=n("div","parle-footer-row");t.appendChild(n("span","parle-footer-state",e.automatic?"Looking pages up automatically":"Only when you ask")),t.appendChild(b("parle-link",e.automatic?"Turn off":"Turn on",()=>r.decide(!e.automatic))),a.appendChild(t);const o=n("div","parle-footer-row"),s=ye(e,r);return s!==null&&o.appendChild(s),o.appendChild(b("parle-link","What Parle sends",r.openDisclosure)),o.appendChild(b("parle-link","Settings",r.openSettings)),a.appendChild(o),a},Ae=e=>{const r=n("header","parle-head");return r.appendChild(n("h1","parle-heading",e.heading)),r.appendChild(n("div","parle-address",e.address)),r},Se=(e,r,a)=>{e.textContent="",e.className="parle parle-compact";const t=n("div","parle-body"),o=r.address,s=T(r.linked),p=_.get(o)??(s!==void 0?s.network:"summary"),m=n("div","parle-main"),h=n("div","parle-extras"),v=fe("passing","Came up elsewhere","linked inside a conversation about something else",r.passing,a);if(v!==null&&h.appendChild(v),r.folded!==null&&h.appendChild(V(r.folded,a)),r.windowed!==null&&h.appendChild(R(r.windowed,"parle-note")),z(r)===0&&r.folded===null)h.appendChild(n("p","parle-said",r.restraint===null?F(r):r.restraint.says));else if(r.stillLooking){const l=n("div","parle-notice parle-tone-waiting"),i=n("span","");i.appendChild(n("span","parle-spinner")),i.appendChild(document.createTextNode(B(r))),l.appendChild(i),h.appendChild(l)}const g=l=>{if(_.set(o,l),m.replaceChildren(),l==="summary"){const i=be(r.digest,a);i!==null?m.appendChild(i):m.appendChild(n("p","parle-comments-note","A Digest of these discussions will live here."));return}r.linked.some(i=>i.network===l)&&m.appendChild(ue(o,l,r.linked,r,a,()=>g(l)))},u=n("div","parle-nav-slot"),f=l=>{u.replaceChildren(he(o,r,l,a,i=>{g(i),f(i)}))};g(p),t.appendChild(m),t.appendChild(h),e.appendChild(t),e.appendChild(u),f(p)},Ne=(e,r,a)=>{e.textContent="",e.className="parle",e.appendChild(Ae(r));const t=n("div","parle-body");r.restraint!==null&&t.appendChild(ke(r.restraint,a));const o=r.folded!==null&&z(r)===0;(r.restraint===null||z(r)>0)&&!o&&t.appendChild(n("p","parle-said",F(r))),r.folded!==null&&t.appendChild(V(r.folded,a)),r.accounts.length>0&&t.appendChild(we(r.accounts)),r.windowed!==null&&t.appendChild(R(r.windowed,"parle-note")),r.index!==null&&t.appendChild(R(r.index,"parle-note")),e.appendChild(t),(r.restraint===null||r.restraint.kind!=="undecided")&&e.appendChild(Ce(r,a))},ze=(e,r,a)=>{if(z(r)===0){Ne(e,r,a);return}Se(e,r,a)},Le=`
:host,
.parle, .parle-pill, .parle-dock {
  --parle-font: -apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif;
  --parle-t-meta: 11px;
  --parle-t-body: 13px;
  --parle-t-lead: 15px;
  --parle-t-head: 18px;
  --parle-1: 4px;
  --parle-2: 8px;
  --parle-3: 12px;
  --parle-4: 16px;
  --parle-5: 24px;
  --parle-r: 10px;
  --parle-r-sm: 6px;
  --parle-r-full: 999px;
  --parle-bg: #ffffff;
  --parle-raise: #f4f5f7;
  --parle-ink: #14161a;
  --parle-mid: #5b6270;
  --parle-faint: #6f7683;
  --parle-line: rgba(20, 22, 26, 0.1);
  --parle-rule: rgba(20, 22, 26, 0.2);
  --parle-accent: #1a6fdb;
  --parle-on-accent: #ffffff;
  --parle-warn: #7a5200;
  --parle-stop: #99291c;
  --parle-lift: 0 1px 2px rgba(10, 12, 16, 0.06), 0 10px 32px rgba(10, 12, 16, 0.14);
  --parle-motion: cubic-bezier(0.2, 0.75, 0.3, 1);
}
@media (prefers-color-scheme: dark) {
  :host,
  .parle, .parle-pill, .parle-dock {
    --parle-bg: #101216;
    --parle-raise: #191c22;
    --parle-ink: #e8eaef;
    --parle-mid: #a2a9b6;
    --parle-faint: #8b929f;
    --parle-line: rgba(232, 234, 239, 0.11);
    --parle-rule: rgba(232, 234, 239, 0.24);
    --parle-accent: #6eb0ff;
    --parle-on-accent: #0a1628;
    --parle-warn: #e0bd76;
    --parle-stop: #f0a396;
    --parle-lift: 0 1px 2px rgba(0, 0, 0, 0.4), 0 10px 32px rgba(0, 0, 0, 0.5);
  }
}

/* the phone scale */
@media (max-width: 639px) {
  :host,
  .parle, .parle-pill, .parle-dock {
    --parle-t-meta: 12px;
    --parle-t-body: 15px;
    --parle-t-lead: 17px;
  }
}

/* reset \u2014 nothing inherits from the page this is drawn on */
.parle, .parle-pill, .parle-dock {
  all: initial;
  color-scheme: light dark;
  font-family: var(--parle-font);
  font-size: var(--parle-t-body);
  line-height: 1.5;
  color: var(--parle-ink);
  -webkit-font-smoothing: antialiased;
  box-sizing: border-box;
}
.parle *, .parle *::before, .parle *::after,
.parle-pill *, .parle-pill::before, .parle-pill::after,
.parle-dock * { box-sizing: border-box; }
.parle a { color: inherit; text-decoration: none; }
.parle :focus-visible,
.parle-pill:focus-visible, .parle-close:focus-visible {
  outline: 2px solid var(--parle-accent);
  outline-offset: 2px;
  border-radius: var(--parle-r-sm);
}

/* the panel */
.parle { display: flex; flex-direction: column; background: var(--parle-bg); }
.parle-head { flex: none; padding: var(--parle-4) var(--parle-4) var(--parle-2); }
.parle-heading {
  margin: 0 0 2px;
  font-size: var(--parle-t-lead);
  font-weight: 600;
  letter-spacing: -0.01em;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.parle-address {
  font-size: var(--parle-t-meta);
  color: var(--parle-faint);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.parle-body {
  padding: 0 var(--parle-3) var(--parle-3);
  max-height: 420px;
  overflow-y: auto;
  overscroll-behavior: contain;
}
.parle-compact { min-height: 0; }
.parle-compact .parle-body {
  padding: 10px 16px 8px;
  flex: 1 1 auto;
  min-height: 0;
  max-height: none;
}
.parle-dock .parle { flex: 1 1 auto; min-height: 0; }
.parle-dock .parle-body { max-height: none; flex: 1 1 auto; min-height: 0; }
.parle-dock .parle-compact { height: 100%; }
.parle-main { min-width: 0; }
.parle-extras { margin-top: var(--parle-3); }

/* discussions \u2014 Linked room vs Passing list, never blended */
.parle-group { margin: var(--parle-4) 0 0; }
.parle-group:first-child { margin-top: 0; }
.parle-group-name {
  margin: 0 0 var(--parle-2);
  font-size: var(--parle-t-meta);
  letter-spacing: 0.07em;
  text-transform: uppercase;
  font-weight: 700;
  color: var(--parle-mid);
}
.parle-group-note {
  display: block;
  margin-top: 2px;
  font-size: var(--parle-t-meta);
  color: var(--parle-faint);
  font-weight: 400;
  text-transform: none;
  letter-spacing: 0;
}
.parle-group-linked .parle-group-name { color: var(--parle-accent); }
.parle-row {
  display: block;
  padding: var(--parle-2) var(--parle-3);
  margin: 0 0 var(--parle-1);
  border-radius: var(--parle-r-sm);
  background: var(--parle-raise);
  transition: background 160ms var(--parle-motion);
}
.parle-row:hover { background: var(--parle-line); }
.parle-group-passing .parle-row { box-shadow: inset 2px 0 0 var(--parle-rule); }
.parle-title { display: block; font-weight: 500; margin-bottom: 2px; }
.parle a:hover .parle-title { text-decoration: underline; }
.parle-facts {
  display: flex;
  gap: var(--parle-2);
  flex-wrap: wrap;
  font-size: var(--parle-t-meta);
  color: var(--parle-faint);
}
.parle-network { font-weight: 600; color: var(--parle-mid); }
.parle-repeat { font-style: italic; }

/*
 * Compact open room \u2014 comments first. Network identity lives on the bottom
 * nav icon; Parle's shell stays neutral. Subtle guides only.
 */
.parle-room { margin: 0; }
.parle-room-title {
  display: -webkit-box;
  margin: 0;
  padding: 2px 0 8px;
  overflow: hidden;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 2;
  color: var(--parle-ink);
  font-size: var(--parle-t-body);
  font-weight: 650;
  line-height: 1.35;
}
.parle-room-title:hover { text-decoration: underline; }
.parle-room-repeat {
  padding: 3px 0 5px;
  border-bottom: 1px solid var(--parle-line);
  color: var(--parle-faint);
  font-size: var(--parle-t-meta);
}
.parle-thread-picks {
  display: flex;
  gap: 6px;
  overflow-x: auto;
  margin: 0 0 8px;
  scrollbar-width: none;
}
.parle-thread-picks::-webkit-scrollbar { display: none; }
.parle-thread-pick {
  flex: none;
  max-width: 10em;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  border: 0;
  border-radius: 999px;
  padding: 4px 10px;
  background: var(--parle-raise);
  color: var(--parle-mid);
  font: 600 11px/1 var(--parle-font);
  cursor: pointer;
}
.parle-thread-pick-on {
  background: var(--parle-accent);
  color: var(--parle-on-accent);
}

.parle-home .parle-comments {
  margin: 0;
  padding: 0;
  border-left: 0;
}
.parle-home .parle-comment {
  margin: 0;
  padding: 9px 0;
  border-bottom: 1px solid var(--parle-line);
  border-left: 0;
}
.parle-home .parle-comment:last-child { border-bottom: 0; }
.parle-home .parle-replies {
  margin: 7px 0 0;
  padding: 0 0 0 12px;
  border-left: 1.5px solid var(--parle-line);
}
.parle-room[data-network="hackernews"] {
  --parle-guide: #ff6600;
}
.parle-room[data-network="reddit"] {
  --parle-guide: #ff4500;
}
.parle-room[data-network="x"] {
  --parle-guide: #536471;
}
.parle-room[data-network] .parle-replies {
  border-left-color: color-mix(in srgb, var(--parle-guide) 48%, transparent);
}
.parle-room[data-network] .parle-comment-who { color: var(--parle-guide); font-weight: 700; }
.parle-room[data-network="x"] .parle-comment {
  border-left: 0;
  padding-left: 0;
}
.parle-room[data-network="x"] .parle-comment-who {
  color: var(--parle-ink);
  font-weight: 800;
}

/*
 * Bottom nav \u2014 ~32px icon row. Counts are iOS-style badges on the icon's
 * top-right and do not add layout height. Settings sits apart on the right.
 */
.parle-nav-slot { flex: none; }
.parle-nav {
  display: flex;
  align-items: center;
  gap: 4px;
  min-height: calc(34px + env(safe-area-inset-bottom, 0px));
  padding: 3px 12px calc(3px + env(safe-area-inset-bottom, 0px));
  border-top: 1px solid var(--parle-line);
  background: var(--parle-bg);
}
.parle-nav-strip {
  display: flex;
  align-items: center;
  gap: 4px;
  flex: 1 1 auto;
  min-width: 0;
  overflow-x: auto;
  scrollbar-width: none;
}
.parle-nav-strip::-webkit-scrollbar { display: none; }
.parle-nav-item {
  position: relative;
  flex: none;
  width: 40px;
  height: 27px;
  display: inline-grid;
  place-items: center;
  border: 0;
  border-radius: 8px;
  background: transparent;
  color: var(--parle-mid);
  cursor: pointer;
  padding: 0;
}
.parle-nav-item:hover { background: var(--parle-raise); color: var(--parle-ink); }
.parle-nav-on { color: var(--parle-accent); }
.parle-nav-on::after {
  content: "";
  position: absolute;
  left: 12px;
  right: 12px;
  bottom: 0;
  height: 2px;
  border-radius: 999px;
  background: var(--parle-accent);
}
.parle-nav-icon {
  position: relative;
  display: inline-grid;
  place-items: center;
  width: 20px;
  height: 20px;
  overflow: visible;
}
.parle-nav-mark,
.parle-tab-mark {
  display: inline-grid;
  place-items: center;
  width: 20px;
  height: 20px;
  border-radius: 4px;
  overflow: hidden;
  color: inherit;
}
.parle-nav-mark svg,
.parle-tab-mark svg { display: block; width: 20px; height: 20px; }
.parle-nav-badge {
  position: absolute;
  top: -5px;
  right: -9px;
  z-index: 1;
  min-width: 12px;
  height: 12px;
  padding: 0 2.5px;
  border-radius: 999px;
  background: #ff3b30;
  color: #ffffff;
  font: 700 8px/12px var(--parle-font);
  font-variant-numeric: tabular-nums;
  text-align: center;
  box-shadow: 0 0 0 1.5px var(--parle-bg);
  pointer-events: none;
}
.parle-nav-soon {
  position: absolute;
  top: -3px;
  right: -4px;
  width: 6px;
  height: 6px;
  border-radius: 999px;
  background: var(--parle-accent);
  box-shadow: 0 0 0 1.5px var(--parle-bg);
  pointer-events: none;
}
.parle-nav-utilities {
  display: flex;
  align-items: center;
  flex: none;
  margin-left: 4px;
  padding-left: 5px;
  box-shadow: -1px 0 0 var(--parle-line);
}
.parle-nav-settings { width: 32px; color: var(--parle-mid); }
.parle-nav-settings svg { display: block; width: 16px; height: 16px; }
.parle-nav-settings::after { display: none; }

/* A Discussion's own words. */
.parle-open {
  border: 0; background: transparent; cursor: pointer; font: inherit;
  color: var(--parle-accent); padding: 0; text-decoration: underline;
}
.parle-comments {
  margin: var(--parle-1) 0 var(--parle-2) var(--parle-2);
  padding-left: var(--parle-2);
  border-left: 2px solid var(--parle-line);
}
.parle-comments-tools {
  display: flex; align-items: center; gap: var(--parle-3);
  min-height: 32px;
  margin-bottom: 0;
  border-bottom: 1px solid var(--parle-line);
}
.parle-comments-mode, .parle-comments-collapse, .parle-comment-more, .parle-comments-more,
.parle-comments-open {
  border: 0; background: transparent; cursor: pointer; font: inherit;
  color: var(--parle-accent); padding: 0; text-decoration: none;
  font-size: var(--parle-t-meta); font-weight: 600;
}
.parle-comments-mode {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  flex: none;
  color: var(--parle-ink);
}
.parle-comments-mode svg { display: block; width: 15px; height: 15px; color: var(--parle-mid); }
.parle-comments-chevron { color: var(--parle-faint); font-size: 10px; transform: translateY(-1px); }
.parle-comments-collapse { color: var(--parle-accent); font-weight: 500; }
.parle-comments-collapse:hover { color: var(--parle-ink); }
.parle-comments-spacer { flex: 1 1 auto; }
.parle-comments-open,
.parle-comments-more-actions {
  display: inline-grid;
  place-items: center;
  width: 24px;
  height: 24px;
  color: var(--parle-mid);
}
.parle-comments-open:hover,
.parle-comments-more-actions:hover { color: var(--parle-ink); }
.parle-comments-open svg,
.parle-comments-more-actions svg { display: block; width: 14px; height: 14px; }
.parle-comments-menu-wrap { position: relative; display: inline-grid; }
.parle-comments-menu {
  position: absolute;
  z-index: 2;
  top: 26px;
  right: 0;
  min-width: 150px;
  padding: 4px;
  border: 1px solid var(--parle-line);
  border-radius: 8px;
  background: var(--parle-bg);
  box-shadow: var(--parle-lift);
}
.parle-comments-menu[hidden] { display: none; }
.parle-comments-menu-item {
  display: block;
  width: 100%;
  border: 0;
  border-radius: 5px;
  padding: 6px 8px;
  background: transparent;
  color: var(--parle-ink);
  font: 500 var(--parle-t-meta)/1.3 var(--parle-font);
  text-align: left;
  cursor: pointer;
}
.parle-comments-menu-item:hover { background: var(--parle-raise); }
.parle-comments-more { margin: var(--parle-1) 0 var(--parle-2); text-decoration: underline; }
.parle-comment { margin-bottom: var(--parle-2); min-width: 0; }
.parle-comment-who { color: var(--parle-mid); font-size: var(--parle-t-meta); }
.parle-comment-age { margin-left: var(--parle-1); color: var(--parle-faint); font-weight: 400; }
.parle-comment-text {
  margin: 2px 0 0; white-space: pre-wrap; overflow-wrap: anywhere;
  line-height: 1.45;
}
.parle-comment-more {
  display: inline-flex;
  align-items: center;
  gap: 3px;
  min-height: 22px;
  margin-top: 2px;
  font-size: var(--parle-t-meta);
  color: var(--parle-mid);
}
.parle-comment-more::before {
  content: "\u203A";
  font-size: 14px;
  line-height: 1;
  color: var(--parle-guide, var(--parle-faint));
}
.parle-replies {
  margin: var(--parle-2) 0 0 var(--parle-2);
  padding-left: var(--parle-2);
  border-left: 2px solid var(--parle-line);
}
.parle-comments-note { color: var(--parle-mid); font-size: var(--parle-t-meta); margin: 0; }

/* a site's front door: what was set aside, and the one click that opens it.
   Quiet rather than warning-coloured \u2014 nothing has gone wrong here, and the
   product's own rule is that a suppression must read as a decision the reader
   can reverse rather than as an error they have to interpret. */
.parle-folded {
  margin: var(--parle-3) 0 0;
  padding: var(--parle-3);
  border-radius: var(--parle-r-sm);
  background: var(--parle-raise);
}
.parle-folded-says {
  margin: 0 0 var(--parle-2);
  font-size: var(--parle-t-meta);
  color: var(--parle-mid);
}
.parle-act-folded { font-size: var(--parle-t-meta); padding: var(--parle-1) var(--parle-3); }
.parle-folded-rows { margin-top: var(--parle-2); }
.parle-folded-rows .parle-row { background: var(--parle-bg); }

/* tones \u2014 six states, six inks, no washes (ADR 0011) */
.parle-tone-refused { color: var(--parle-stop); }
.parle-tone-garbled { color: var(--parle-warn); }
.parle-tone-withheld, .parle-tone-waiting, .parle-tone-quiet { color: var(--parle-mid); }
.parle-tone-found { color: var(--parle-accent); }
.parle-notice {
  display: flex;
  justify-content: space-between;
  gap: var(--parle-2);
  margin: var(--parle-2) 0 0;
  padding: var(--parle-2) var(--parle-3);
  border-radius: var(--parle-r-sm);
  background: var(--parle-raise);
  font-size: var(--parle-t-meta);
}
.parle-said { margin: var(--parle-3) 0; color: var(--parle-mid); }
.parle-restraint { margin: var(--parle-3) 0 var(--parle-4); color: var(--parle-mid); }
.parle-restraint-says { margin: 0 0 var(--parle-3); color: var(--parle-ink); }

/* actions \u2014 outlined, so a button is a button on whatever it sits on */
.parle-act {
  all: unset;
  display: inline-block;
  cursor: pointer;
  font-family: var(--parle-font);
  font-size: var(--parle-t-body);
  font-weight: 550;
  padding: var(--parle-2) var(--parle-4);
  border-radius: var(--parle-r-full);
  color: var(--parle-ink);
  background: var(--parle-bg);
  box-shadow: inset 0 0 0 1px var(--parle-rule);
  transition: background 160ms var(--parle-motion), opacity 160ms var(--parle-motion);
}
.parle-act:hover { background: var(--parle-raise); }
.parle-act-strong {
  background: var(--parle-accent);
  color: var(--parle-on-accent);
  box-shadow: none;
}
.parle-act-strong:hover { background: var(--parle-accent); opacity: 0.88; }
.parle-link {
  all: unset;
  cursor: pointer;
  font-family: var(--parle-font);
  font-size: var(--parle-t-meta);
  color: var(--parle-mid);
  transition: color 160ms var(--parle-motion);
}
.parle-link:hover { color: var(--parle-ink); text-decoration: underline; }
.parle-note { margin: var(--parle-4) 0 0; font-size: var(--parle-t-meta); color: var(--parle-mid); }
/* the footer \u2014 rows declared, never wrapped into */
.parle-footer {
  flex: none;
  display: flex;
  flex-direction: column;
  gap: var(--parle-2);
  border-top: 1px solid var(--parle-line);
  padding: var(--parle-3) var(--parle-4);
  font-size: var(--parle-t-meta);
  color: var(--parle-faint);
}
.parle-footer-row {
  display: flex;
  align-items: center;
  gap: var(--parle-3);
  flex-wrap: wrap;
}
.parle-footer-state { margin-right: auto; color: var(--parle-mid); }

/* the account of every place we asked \u2014 the toolbar surface's whole job */
.parle-coverage { margin: var(--parle-4) 0 0; }
.parle-coverage-name {
  margin: 0 0 var(--parle-1);
  font-size: var(--parle-t-meta);
  letter-spacing: 0.07em;
  text-transform: uppercase;
  font-weight: 700;
  color: var(--parle-faint);
}
.parle-account {
  display: flex;
  justify-content: space-between;
  gap: var(--parle-3);
  padding: var(--parle-1) 0;
  font-size: var(--parle-t-meta);
  color: var(--parle-mid);
}
.parle-account-place { color: var(--parle-mid); }
.parle-account-waiting { color: var(--parle-faint); }
.parle-account-refused { color: var(--parle-stop); }
.parle-account-garbled { color: var(--parle-warn); }
.parle-account-found { color: var(--parle-accent); }

/* digest */
.parle-digest {
  margin: var(--parle-4) 0 0;
  padding: var(--parle-3);
  border-radius: var(--parle-r);
  background: var(--parle-raise);
  color: var(--parle-mid);
}
.parle-compact .parle-digest { margin-top: 0; }
.parle-digest-title { margin: 0 0 var(--parle-2); font-size: var(--parle-t-body); font-weight: 600; color: var(--parle-ink); }
.parle-digest-says { margin: 0 0 var(--parle-2); }
.parle-digest-partial { margin: var(--parle-2) 0 0; font-size: var(--parle-t-meta); }
.parle-digest-wrote { margin: var(--parle-2) 0 0; font-size: var(--parle-t-meta); color: var(--parle-faint); }
.parle-act-digest { margin-top: var(--parle-1); }
.parle-finding { margin: 0 0 var(--parle-3); }
.parle-finding:last-of-type { margin-bottom: 0; }
.parle-finding-says { margin: 0 0 var(--parle-1); color: var(--parle-ink); }
/* disputed: the neutral ink, never the accent and never a warning (ADR 0006) */
.parle-finding-disputed { box-shadow: inset 2px 0 0 var(--parle-rule); padding-left: var(--parle-3); }
.parle-disputed {
  display: block;
  margin-bottom: 2px;
  font-size: var(--parle-t-meta);
  text-transform: uppercase;
  letter-spacing: 0.05em;
  color: var(--parle-faint);
}
/* citations: underlined always, because they are meant to be followed (ADR 0006) */
.parle-sources { display: flex; flex-wrap: wrap; gap: var(--parle-1) var(--parle-3); }
.parle a.parle-source {
  font-size: var(--parle-t-meta);
  color: var(--parle-mid);
  text-decoration: underline;
  text-underline-offset: 2px;
  text-decoration-thickness: 1px;
  cursor: pointer;
}
.parle a.parle-source:hover { color: var(--parle-ink); }
.parle-spinner {
  display: inline-block;
  width: 6px;
  height: 6px;
  border-radius: var(--parle-r-full);
  background: currentColor;
  margin-right: var(--parle-2);
  vertical-align: middle;
  animation: parle-pulse 1.4s var(--parle-motion) infinite;
}
@keyframes parle-pulse { 0%, 100% { opacity: 0.25; } 50% { opacity: 1; } }

/* the mark \u2014 parked by the reader, only when there is something, still after it arrives */
.parle-pill {
  position: fixed;
  top: var(--parle-4);
  left: auto;
  right: var(--parle-4);
  z-index: 2147483646;
  display: grid;
  place-items: center;
  min-width: 36px;
  height: 36px;
  padding: 4px;
  border: 0;
  border-radius: var(--parle-r-full);
  background: var(--parle-bg);
  color: var(--parle-ink);
  box-shadow: var(--parle-lift), inset 0 0 0 1px var(--parle-line);
  cursor: grab;
  touch-action: none;
  user-select: none;
  font-family: var(--parle-font);
  font-size: var(--parle-t-meta);
  font-weight: 650;
  transition: transform 160ms var(--parle-motion), box-shadow 160ms var(--parle-motion);
  animation: parle-arrive 420ms var(--parle-motion) both;
}
.parle-pill:hover { transform: scale(1.05); }
.parle-pill[data-dragging="1"] {
  cursor: grabbing;
  transform: scale(1.08);
  box-shadow: var(--parle-lift), inset 0 0 0 1px var(--parle-accent);
  transition: none;
}
.parle-pill[hidden], .parle-pill[data-found="0"] { display: none; }
.parle-pill svg, .parle-close svg { display: block; width: 16px; height: 16px; }
.parle-pill svg:not([fill]), .parle-close svg:not([fill]) { fill: currentColor; }
.parle-stack {
  display: flex;
  flex-direction: row;
  align-items: center;
}
.parle-stack-disc {
  display: grid;
  place-items: center;
  width: 28px;
  height: 28px;
  border-radius: var(--parle-r-full);
  background: var(--parle-bg);
  box-shadow: 0 0 0 2px var(--parle-bg);
  overflow: hidden;
}
.parle-stack-disc + .parle-stack-disc { margin-left: -10px; }
.parle-stack-disc svg { width: 28px; height: 28px; }
.parle-stack-parle {
  color: var(--parle-ink);
  background: var(--parle-raise);
}
.parle-stack-parle svg { width: 16px; height: 16px; }
.parle-pill-count {
  position: absolute;
  top: -4px;
  right: -4px;
  min-width: 18px;
  height: 18px;
  padding: 0 5px;
  border-radius: var(--parle-r-full);
  background: var(--parle-accent);
  color: var(--parle-on-accent);
  font-size: 10px;
  font-weight: 700;
  line-height: 18px;
  text-align: center;
  box-shadow: 0 0 0 2px var(--parle-bg);
}
.parle-pill-count:empty { display: none; }
/* the announcement: one ring, outward, once */
.parle-pill::after {
  content: "";
  position: absolute;
  inset: -2px;
  border-radius: var(--parle-r-full);
  border: 2px solid var(--parle-accent);
  pointer-events: none;
  animation: parle-ring 1100ms var(--parle-motion) 1 both;
}
@keyframes parle-arrive {
  from { opacity: 0; transform: translateY(-6px) scale(0.8); }
  to { opacity: 1; transform: none; }
}
@keyframes parle-ring {
  from { opacity: 0.55; transform: scale(1); }
  to { opacity: 0; transform: scale(2.1); }
}

/* the surface \u2014 full screen under 640px, docked right at and above it */
.parle-dock {
  position: fixed;
  inset: 0;
  z-index: 2147483647;
  display: flex;
  flex-direction: column;
  background: var(--parle-bg);
  box-shadow: var(--parle-lift);
  overscroll-behavior: contain;
  padding-top: env(safe-area-inset-top, 0px);
  padding-bottom: env(safe-area-inset-bottom, 0px);
  animation: parle-open 180ms var(--parle-motion) both;
}
@keyframes parle-open { from { opacity: 0; } to { opacity: 1; } }
@media (min-width: 640px) {
  .parle-dock { inset: 0 0 0 auto; width: clamp(320px, 30vw, 420px); padding-bottom: 0; }
}
/* the way out of the surface, drawn as a button */
.parle-close {
  all: unset;
  position: absolute;
  top: calc(env(safe-area-inset-top, 0px) + var(--parle-2));
  right: var(--parle-2);
  z-index: 1;
  display: grid;
  place-items: center;
  width: 32px;
  height: 32px;
  border-radius: var(--parle-r-full);
  background: var(--parle-raise);
  cursor: pointer;
  font-family: var(--parle-font);
  font-size: var(--parle-t-head);
  line-height: 1;
  color: var(--parle-mid);
  transition: background 160ms var(--parle-motion), color 160ms var(--parle-motion);
}
.parle-close:hover { background: var(--parle-line); color: var(--parle-ink); }
.parle-dock .parle-head { padding-right: 52px; }
@media (max-width: 639px) {
  .parle-close {
    top: calc(env(safe-area-inset-top, 0px) + var(--parle-3));
    right: var(--parle-3);
    width: 40px;
    height: 40px;
  }
  .parle-dock .parle-head { padding-right: 64px; padding-top: var(--parle-5); }
  .parle-dock .parle-heading {
    white-space: normal;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
  }
}

@media (prefers-reduced-motion: reduce) {
  .parle, .parle *,
  .parle-pill, .parle-pill::after,
  .parle-dock, .parle-close { animation: none !important; transition: none !important; }
  .parle-pill::after { opacity: 0; }
}
`;export{Le as P,ze as a,Ne as r};
